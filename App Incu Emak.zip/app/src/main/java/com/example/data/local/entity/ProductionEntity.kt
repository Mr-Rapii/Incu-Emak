package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "productions")
data class ProductionEntity(
  @PrimaryKey(autoGenerate = true)
  val id: Long = 0,
  val productId: Long,
  val productName: String,
  val dateMillis: Long,
  val dayName: String,
  val formattedDate: String,
  val formattedTime: String,
  val qty: Int,
  val pricePerUnit: Double,
  val costPerUnit: Double,
  val potentialRevenue: Double,
  val totalCost: Double,
  val notes: String = "",
  val photoUri: String? = null,
  val createdAt: Long = System.currentTimeMillis()
)
