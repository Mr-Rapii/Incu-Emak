package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.RemoveShoppingCart
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.local.entity.ProductEntity
import com.example.ui.components.ConfirmationDialog
import com.example.ui.components.PhotoAttachmentSelector
import com.example.ui.theme.ExpenseRed
import com.example.ui.theme.PrimaryWarm
import com.example.ui.theme.ProfitGreen
import com.example.ui.theme.SecondaryGolden
import com.example.ui.theme.WarningAmber
import com.example.ui.util.FormatUtils
import com.example.ui.viewmodel.MainViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StockScreen(
  viewModel: MainViewModel,
  onNavigateToProduction: () -> Unit,
  modifier: Modifier = Modifier
) {
  val products by viewModel.products.collectAsStateWithLifecycle()
  val stockAdjustments by viewModel.stockAdjustments.collectAsStateWithLifecycle()

  var showAddProductDialog by remember { mutableStateOf(false) }
  var productToEdit by remember { mutableStateOf<ProductEntity?>(null) }
  var productToAdjust by remember { mutableStateOf<ProductEntity?>(null) }
  var productToDelete by remember { mutableStateOf<ProductEntity?>(null) }
  var showHistoryDialog by remember { mutableStateOf(false) }

  val totalStock = products.sumOf { it.currentStock }
  val lowStockCount = products.count { it.currentStock <= it.minStockAlert }

  Scaffold(
    modifier = modifier.fillMaxSize().testTag("stock_screen"),
    floatingActionButton = {
      FloatingActionButton(
        onClick = { showAddProductDialog = true },
        containerColor = SecondaryGolden,
        contentColor = Color.White,
        modifier = Modifier.testTag("add_product_fab")
      ) {
        Icon(Icons.Default.Add, contentDescription = "Tambah Produk Baru")
      }
    }
  ) { innerPadding ->
    LazyColumn(
      modifier = Modifier
        .fillMaxSize()
        .padding(innerPadding)
        .background(MaterialTheme.colorScheme.background),
      contentPadding = PaddingValues(16.dp),
      verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
      // 1. Header Summary Card
      item {
        Card(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(20.dp),
          colors = CardDefaults.cardColors(containerColor = SecondaryGolden.copy(alpha = 0.1f))
        ) {
          Column(modifier = Modifier.padding(16.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Column {
                Text(
                  text = "Sistem & Kontrol Stok Produk",
                  style = MaterialTheme.typography.titleMedium,
                  fontWeight = FontWeight.ExtraBold,
                  color = SecondaryGolden
                )
                Text(
                  text = "Stok Akhir = Stok Awal + Produksi - Terjual - Rusak",
                  style = MaterialTheme.typography.bodySmall,
                  color = MaterialTheme.colorScheme.onSurfaceVariant
                )
              }
              IconButton(onClick = { showHistoryDialog = true }) {
                Icon(Icons.Default.History, contentDescription = "Riwayat Penyesuaian", tint = SecondaryGolden)
              }
            }

            Spacer(modifier = Modifier.height(14.dp))

            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Column {
                Text("Total Stok Fisik", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text("$totalStock pcs", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = PrimaryWarm)
              }
              Column(horizontalAlignment = Alignment.End) {
                Text("Status Stok", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(
                  text = if (lowStockCount > 0) "$lowStockCount Menipis ⚠️" else "Semua Aman ✓",
                  style = MaterialTheme.typography.titleMedium,
                  fontWeight = FontWeight.Bold,
                  color = if (lowStockCount > 0) WarningAmber else ProfitGreen
                )
              }
            }
          }
        }
      }

      // 2. Product Items List
      items(products, key = { it.id }) { product ->
        ProductInventoryCard(
          product = product,
          onEditClick = { productToEdit = product },
          onAdjustClick = { productToAdjust = product },
          onDeleteClick = { productToDelete = product }
        )
      }
    }
  }

  // Add Product Dialog
  if (showAddProductDialog) {
    AddOrEditProductDialog(
      product = null,
      onDismiss = { showAddProductDialog = false },
      onSave = { name, cat, price, cost, stock, minStock, unit, desc, photoUri ->
        viewModel.addProduct(name, cat, price, cost, stock, minStock, unit, desc, photoUri)
        showAddProductDialog = false
      }
    )
  }

  // Edit Product Dialog
  productToEdit?.let { prod ->
    AddOrEditProductDialog(
      product = prod,
      onDismiss = { productToEdit = null },
      onSave = { name, cat, price, cost, stock, minStock, unit, desc, photoUri ->
        viewModel.updateProduct(
          prod.copy(
            name = name,
            category = cat,
            defaultPrice = price,
            defaultCost = cost,
            currentStock = stock,
            minStockAlert = minStock,
            unit = unit,
            description = desc,
            photoUri = photoUri
          )
        )
        productToEdit = null
      }
    )
  }

  // Adjust Stock Dialog (Damaged/Spoilage/Manual Count)
  productToAdjust?.let { prod ->
    StockAdjustmentDialog(
      product = prod,
      onDismiss = { productToAdjust = null },
      onConfirm = { qtyDelta, type, reason ->
        viewModel.adjustStockManual(prod.id, prod.name, qtyDelta, type, reason)
        productToAdjust = null
      }
    )
  }

  // Delete Confirmation Dialog
  productToDelete?.let { prod ->
    ConfirmationDialog(
      title = "Hapus Produk ${prod.name}?",
      message = "Menghapus produk ini akan menghilangkannya dari daftar katalog.",
      onConfirm = {
        viewModel.deleteProduct(prod)
        productToDelete = null
      },
      onDismiss = { productToDelete = null }
    )
  }

  // History Log Dialog
  if (showHistoryDialog) {
    StockHistoryDialog(
      adjustments = stockAdjustments,
      onDismiss = { showHistoryDialog = false }
    )
  }
}

@Composable
private fun ProductInventoryCard(
  product: ProductEntity,
  onEditClick: () -> Unit,
  onAdjustClick: () -> Unit,
  onDeleteClick: () -> Unit
) {
  val isLow = product.currentStock <= product.minStockAlert

  Card(
    modifier = Modifier.fillMaxWidth(),
    shape = RoundedCornerShape(18.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
  ) {
    Column(modifier = Modifier.padding(16.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text(
            text = product.name,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold
          )
          Text(
            text = product.category,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }

        Surface(
          color = if (isLow) WarningAmber.copy(alpha = 0.15f) else ProfitGreen.copy(alpha = 0.15f),
          shape = RoundedCornerShape(12.dp)
        ) {
          Text(
            text = if (isLow) "⚠️ Hampir Habis" else "✓ Stok Aman",
            style = MaterialTheme.typography.labelSmall,
            color = if (isLow) WarningAmber else ProfitGreen,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
          )
        }
      }

      Spacer(modifier = Modifier.height(12.dp))

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text("Stok Saat Ini", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
          Text(
            text = "${product.currentStock} ${product.unit}",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.ExtraBold,
            color = if (isLow) ExpenseRed else MaterialTheme.colorScheme.onSurface
          )
        }
        Column {
          Text("Harga Jual", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
          Text(FormatUtils.formatRupiah(product.defaultPrice), style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
        }
        Column(horizontalAlignment = Alignment.End) {
          Text("Modal/HPP", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
          Text(FormatUtils.formatRupiah(product.defaultCost), style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
        }
      }

      Spacer(modifier = Modifier.height(12.dp))

      // Action Row
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.End,
        verticalAlignment = Alignment.CenterVertically
      ) {
        OutlinedButton(
          onClick = onAdjustClick,
          shape = RoundedCornerShape(10.dp),
          contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
        ) {
          Icon(Icons.Default.RemoveShoppingCart, contentDescription = null, modifier = Modifier.size(14.dp))
          Spacer(modifier = Modifier.width(4.dp))
          Text("Catat Rusak/Koreksi", fontSize = 11.sp)
        }

        Spacer(modifier = Modifier.width(8.dp))

        IconButton(onClick = onEditClick, modifier = Modifier.size(34.dp)) {
          Icon(Icons.Default.Edit, contentDescription = "Edit", tint = PrimaryWarm, modifier = Modifier.size(18.dp))
        }

        IconButton(onClick = onDeleteClick, modifier = Modifier.size(34.dp)) {
          Icon(Icons.Default.Delete, contentDescription = "Hapus", tint = ExpenseRed.copy(alpha = 0.7f), modifier = Modifier.size(18.dp))
        }
      }
    }
  }
}

@Composable
private fun AddOrEditProductDialog(
  product: ProductEntity?,
  onDismiss: () -> Unit,
  onSave: (String, String, Double, Double, Int, Int, String, String, String?) -> Unit
) {
  var name by remember { mutableStateOf(product?.name ?: "") }
  var category by remember { mutableStateOf(product?.category ?: "Makanan Ringan") }
  var priceText by remember { mutableStateOf(product?.defaultPrice?.toInt()?.toString() ?: "5000") }
  var costText by remember { mutableStateOf(product?.defaultCost?.toInt()?.toString() ?: "2500") }
  var stockText by remember { mutableStateOf(product?.currentStock?.toString() ?: "30") }
  var minStockText by remember { mutableStateOf(product?.minStockAlert?.toString() ?: "10") }
  var unit by remember { mutableStateOf(product?.unit ?: "pcs") }
  var desc by remember { mutableStateOf(product?.description ?: "") }
  var photoUri by remember { mutableStateOf<String?>(product?.photoUri) }

  val price = priceText.toDoubleOrNull() ?: 0.0
  val cost = costText.toDoubleOrNull() ?: 0.0
  val stock = stockText.toIntOrNull() ?: 0
  val minStock = minStockText.toIntOrNull() ?: 10

  AlertDialog(
    onDismissRequest = onDismiss,
    title = { Text(if (product == null) "Tambah Produk Baru" else "Edit Produk", fontWeight = FontWeight.Bold) },
    text = {
      Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        OutlinedTextField(
          value = name,
          onValueChange = { name = it },
          label = { Text("Nama Produk (e.g. Makaroni)") },
          modifier = Modifier.fillMaxWidth(),
          singleLine = true
        )

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          OutlinedTextField(
            value = priceText,
            onValueChange = { priceText = it },
            label = { Text("Harga Jual (Rp)") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier.weight(1f)
          )
          OutlinedTextField(
            value = costText,
            onValueChange = { costText = it },
            label = { Text("Modal HPP (Rp)") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier.weight(1f)
          )
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          OutlinedTextField(
            value = stockText,
            onValueChange = { stockText = it },
            label = { Text("Stok Awal") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier.weight(1f)
          )
          OutlinedTextField(
            value = minStockText,
            onValueChange = { minStockText = it },
            label = { Text("Batas Peringatan") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier.weight(1f)
          )
        }

        OutlinedTextField(
          value = desc,
          onValueChange = { desc = it },
          label = { Text("Deskripsi / Varian Rasa") },
          modifier = Modifier.fillMaxWidth(),
          singleLine = true
        )

        PhotoAttachmentSelector(
          selectedPhotoUri = photoUri,
          onPhotoSelected = { photoUri = it },
          label = "Foto Produk"
        )
      }
    },
    confirmButton = {
      Button(
        onClick = {
          if (name.isNotBlank()) {
            onSave(name, category, price, cost, stock, minStock, unit, desc, photoUri)
          }
        },
        enabled = name.isNotBlank(),
        colors = ButtonDefaults.buttonColors(containerColor = PrimaryWarm)
      ) {
        Text("Simpan", color = Color.White)
      }
    },
    dismissButton = {
      TextButton(onClick = onDismiss) { Text("Batal") }
    }
  )
}

@Composable
private fun StockAdjustmentDialog(
  product: ProductEntity,
  onDismiss: () -> Unit,
  onConfirm: (Int, String, String) -> Unit
) {
  var qtyText by remember { mutableStateOf("2") }
  var type by remember { mutableStateOf("RUSAK") } // "RUSAK" or "KOREKSI"
  var reason by remember { mutableStateOf("Kemasan sobek / melempem") }

  val qty = qtyText.toIntOrNull() ?: 0

  AlertDialog(
    onDismissRequest = onDismiss,
    title = { Text("Penyesuaian Stok: ${product.name}", fontWeight = FontWeight.Bold) },
    text = {
      Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        Text("Stok sekarang: ${product.currentStock} pcs", style = MaterialTheme.typography.bodyMedium)

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          Button(
            onClick = { type = "RUSAK" },
            colors = ButtonDefaults.buttonColors(
              containerColor = if (type == "RUSAK") ExpenseRed else MaterialTheme.colorScheme.surfaceVariant,
              contentColor = if (type == "RUSAK") Color.White else MaterialTheme.colorScheme.onSurface
            ),
            modifier = Modifier.weight(1f)
          ) {
            Text("Produk Rusak (-)")
          }
          Button(
            onClick = { type = "KOREKSI" },
            colors = ButtonDefaults.buttonColors(
              containerColor = if (type == "KOREKSI") PrimaryWarm else MaterialTheme.colorScheme.surfaceVariant,
              contentColor = if (type == "KOREKSI") Color.White else MaterialTheme.colorScheme.onSurface
            ),
            modifier = Modifier.weight(1f)
          ) {
            Text("Koreksi (+/-)")
          }
        }

        OutlinedTextField(
          value = qtyText,
          onValueChange = { qtyText = it },
          label = { Text("Jumlah (pcs)") },
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
          modifier = Modifier.fillMaxWidth()
        )

        OutlinedTextField(
          value = reason,
          onValueChange = { reason = it },
          label = { Text("Alasan Penyesuaian") },
          modifier = Modifier.fillMaxWidth()
        )
      }
    },
    confirmButton = {
      Button(
        onClick = {
          if (qty > 0) {
            val delta = if (type == "RUSAK") -qty else -qty
            onConfirm(delta, type, reason)
          }
        },
        colors = ButtonDefaults.buttonColors(containerColor = ExpenseRed)
      ) {
        Text("Simpan Perubahan", color = Color.White)
      }
    },
    dismissButton = {
      TextButton(onClick = onDismiss) { Text("Batal") }
    }
  )
}

@Composable
private fun StockHistoryDialog(
  adjustments: List<com.example.data.local.entity.StockAdjustmentEntity>,
  onDismiss: () -> Unit
) {
  AlertDialog(
    onDismissRequest = onDismiss,
    title = { Text("Riwayat Penyesuaian Stok", fontWeight = FontWeight.Bold) },
    text = {
      if (adjustments.isEmpty()) {
        Text("Belum ada riwayat penyesuaian stok.")
      } else {
        LazyColumn(
          modifier = Modifier
            .fillMaxWidth()
            .height(280.dp),
          verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          items(adjustments) { adj ->
            Surface(
              color = MaterialTheme.colorScheme.surfaceVariant,
              shape = RoundedCornerShape(10.dp),
              modifier = Modifier.fillMaxWidth()
            ) {
              Row(
                modifier = Modifier.padding(10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Column(modifier = Modifier.weight(1f)) {
                  Text(adj.productName, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                  Text("${adj.formattedDate} • ${adj.reason}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Text(
                  text = "${if (adj.qtyChange > 0) "+" else ""}${adj.qtyChange} pcs",
                  fontWeight = FontWeight.ExtraBold,
                  color = if (adj.qtyChange > 0) ProfitGreen else ExpenseRed
                )
              }
            }
          }
        }
      }
    },
    confirmButton = {
      Button(onClick = onDismiss) { Text("Tutup") }
    }
  )
}
