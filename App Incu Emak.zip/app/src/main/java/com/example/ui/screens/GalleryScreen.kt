package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Image
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.example.ui.components.ImageViewerDialog
import com.example.ui.theme.PrimaryWarm
import com.example.ui.viewmodel.MainViewModel

data class GalleryItem(
  val id: Long,
  val type: String, // Produksi, Penjualan, Belanja, Produk
  val title: String,
  val subtitle: String,
  val photoUri: String
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GalleryScreen(
  viewModel: MainViewModel,
  modifier: Modifier = Modifier
) {
  val productions by viewModel.productions.collectAsStateWithLifecycle()
  val sales by viewModel.sales.collectAsStateWithLifecycle()
  val expenses by viewModel.expenses.collectAsStateWithLifecycle()
  val products by viewModel.products.collectAsStateWithLifecycle()

  var selectedFilter by remember { mutableStateOf("Semua") }
  var selectedImage by remember { mutableStateOf<GalleryItem?>(null) }

  val filters = listOf("Semua", "Produk", "Produksi", "Penjualan", "Belanja")

  val allItems = mutableListOf<GalleryItem>().apply {
    products.filter { !it.photoUri.isNullOrBlank() }.forEach {
      add(GalleryItem(it.id, "Produk", it.name, "Katalog Produk", it.photoUri!!))
    }
    productions.filter { !it.photoUri.isNullOrBlank() }.forEach {
      add(GalleryItem(it.id, "Produksi", "Produksi ${it.productName}", "${it.formattedDate} • ${it.qty} pcs", it.photoUri!!))
    }
    sales.filter { !it.photoUri.isNullOrBlank() }.forEach {
      add(GalleryItem(it.id, "Penjualan", "Penjualan #${it.id}", "${it.formattedDate} • ${it.customerName.ifBlank { "Pelanggan" }}", it.photoUri!!))
    }
    expenses.filter { !it.receiptPhotoUri.isNullOrBlank() }.forEach {
      add(GalleryItem(it.id, "Belanja", "Nota ${it.itemName}", "${it.formattedDate} • ${it.category}", it.receiptPhotoUri!!))
    }
  }

  val filteredItems = if (selectedFilter == "Semua") {
    allItems
  } else {
    allItems.filter { it.type.equals(selectedFilter, ignoreCase = true) }
  }

  Column(
    modifier = modifier
      .fillMaxSize()
      .background(MaterialTheme.colorScheme.background)
      .padding(16.dp)
      .testTag("gallery_screen")
  ) {
    Text(
      text = "Dokumentasi & Galeri Foto",
      style = MaterialTheme.typography.titleMedium,
      fontWeight = FontWeight.Bold
    )
    Text(
      text = "Semua foto produk, produksi, struk penjualan, dan nota belanja",
      style = MaterialTheme.typography.bodySmall,
      color = MaterialTheme.colorScheme.onSurfaceVariant
    )

    Spacer(modifier = Modifier.height(12.dp))

    // Filter Chips
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
      filters.forEach { filter ->
        FilterChip(
          selected = selectedFilter == filter,
          onClick = { selectedFilter = filter },
          label = { Text(filter, fontSize = 12.sp) },
          colors = FilterChipDefaults.filterChipColors(
            selectedContainerColor = PrimaryWarm.copy(alpha = 0.15f),
            selectedLabelColor = PrimaryWarm
          )
        )
      }
    }

    Spacer(modifier = Modifier.height(14.dp))

    if (filteredItems.isEmpty()) {
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .weight(1f),
        contentAlignment = Alignment.Center
      ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
          Icon(Icons.Default.Image, contentDescription = null, modifier = Modifier.size(56.dp), tint = MaterialTheme.colorScheme.outline)
          Spacer(modifier = Modifier.height(8.dp))
          Text("Belum ada foto dalam kategori ini", fontWeight = FontWeight.Bold)
          Text("Lampirkan foto saat mencatat produksi, penjualan, atau belanja", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
      }
    } else {
      LazyVerticalGrid(
        columns = GridCells.Fixed(2),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.weight(1f)
      ) {
        items(filteredItems, key = { "${it.type}_${it.id}" }) { item ->
          Card(
            modifier = Modifier
              .fillMaxWidth()
              .clip(RoundedCornerShape(16.dp))
              .clickable { selectedImage = item },
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
          ) {
            Column {
              Box(
                modifier = Modifier
                  .fillMaxWidth()
                  .aspectRatio(1f)
                  .background(MaterialTheme.colorScheme.surfaceVariant)
              ) {
                AsyncImage(
                  model = item.photoUri,
                  contentDescription = item.title,
                  modifier = Modifier.fillMaxSize(),
                  contentScale = ContentScale.Crop
                )

                Surface(
                  color = Color.Black.copy(alpha = 0.6f),
                  shape = RoundedCornerShape(8.dp),
                  modifier = Modifier
                    .padding(8.dp)
                    .align(Alignment.TopStart)
                ) {
                  Text(
                    text = item.type,
                    color = Color.White,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                  )
                }
              }

              Column(modifier = Modifier.padding(10.dp)) {
                Text(
                  text = item.title,
                  style = MaterialTheme.typography.bodySmall,
                  fontWeight = FontWeight.Bold,
                  maxLines = 1
                )
                Text(
                  text = item.subtitle,
                  style = MaterialTheme.typography.labelSmall,
                  color = MaterialTheme.colorScheme.onSurfaceVariant,
                  maxLines = 1
                )
              }
            }
          }
        }
      }
    }
  }

  // Full Screen Preview Dialog
  selectedImage?.let { item ->
    ImageViewerDialog(
      photoUri = item.photoUri,
      title = item.title,
      subtitle = "${item.type} • ${item.subtitle}",
      onDismiss = { selectedImage = null }
    )
  }
}
