package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.local.dao.BusinessTargetDao
import com.example.data.local.dao.ExpenseDao
import com.example.data.local.dao.ProductDao
import com.example.data.local.dao.ProductionDao
import com.example.data.local.dao.SaleDao
import com.example.data.local.dao.StockAdjustmentDao
import com.example.data.local.entity.BusinessTargetEntity
import com.example.data.local.entity.ExpenseEntity
import com.example.data.local.entity.ProductEntity
import com.example.data.local.entity.ProductionEntity
import com.example.data.local.entity.SaleEntity
import com.example.data.local.entity.SaleItemEntity
import com.example.data.local.entity.StockAdjustmentEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
  entities = [
    ProductEntity::class,
    ProductionEntity::class,
    SaleEntity::class,
    SaleItemEntity::class,
    ExpenseEntity::class,
    StockAdjustmentEntity::class,
    BusinessTargetEntity::class
  ],
  version = 1,
  exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
  abstract fun productDao(): ProductDao
  abstract fun productionDao(): ProductionDao
  abstract fun saleDao(): SaleDao
  abstract fun expenseDao(): ExpenseDao
  abstract fun stockAdjustmentDao(): StockAdjustmentDao
  abstract fun businessTargetDao(): BusinessTargetDao

  companion object {
    @Volatile
    private var INSTANCE: AppDatabase? = null

    fun getDatabase(context: Context, scope: CoroutineScope): AppDatabase {
      return INSTANCE ?: synchronized(this) {
        val instance = Room.databaseBuilder(
          context.applicationContext,
          AppDatabase::class.java,
          "incu_emak_business.db"
        )
          .fallbackToDestructiveMigration()
          .addCallback(DatabaseCallback(scope))
          .build()
        INSTANCE = instance
        instance
      }
    }

    private class DatabaseCallback(
      private val scope: CoroutineScope
    ) : RoomDatabase.Callback() {
      override fun onCreate(db: SupportSQLiteDatabase) {
        super.onCreate(db)
        INSTANCE?.let { database ->
          scope.launch(Dispatchers.IO) {
            populateInitialData(database)
          }
        }
      }
    }

    suspend fun populateInitialData(database: AppDatabase) {
      val productDao = database.productDao()
      val productionDao = database.productionDao()
      val saleDao = database.saleDao()
      val expenseDao = database.expenseDao()
      val targetDao = database.businessTargetDao()

      // 1. Initial Products
      val p1Id = productDao.insertProduct(
        ProductEntity(
          name = "Makaroni",
          category = "Makanan Ringan",
          defaultPrice = 5000.0,
          defaultCost = 2500.0,
          currentStock = 20,
          minStockAlert = 10,
          unit = "pcs",
          description = "Makaroni renyah gurih pedas khas Incu Emak"
        )
      )
      val p2Id = productDao.insertProduct(
        ProductEntity(
          name = "Basreng",
          category = "Makanan Ringan",
          defaultPrice = 5000.0,
          defaultCost = 2800.0,
          currentStock = 22,
          minStockAlert = 10,
          unit = "pcs",
          description = "Basreng stik renyah daun jeruk bumbu pedas"
        )
      )
      val p3Id = productDao.insertProduct(
        ProductEntity(
          name = "Kerupuk Seblak",
          category = "Makanan Ringan",
          defaultPrice = 5000.0,
          defaultCost = 2400.0,
          currentStock = 25,
          minStockAlert = 10,
          unit = "pcs",
          description = "Kerupuk seblak bantet pedas kencur gurih"
        )
      )

      // 2. Targets
      targetDao.saveTarget(
        BusinessTargetEntity(
          id = 1,
          dailyTarget = 150000.0,
          weeklyTarget = 1000000.0,
          monthlyTarget = 4000000.0
        )
      )

      // 3. Initial Sample Production (Minggu, 16 Agustus 2026 / current timestamp)
      val now = System.currentTimeMillis()
      val oneDay = 86400000L

      productionDao.insertProduction(
        ProductionEntity(
          productId = p1Id,
          productName = "Makaroni",
          dateMillis = now,
          dayName = "Minggu",
          formattedDate = "16 Agustus 2026",
          formattedTime = "07:30",
          qty = 30,
          pricePerUnit = 5000.0,
          costPerUnit = 2500.0,
          potentialRevenue = 150000.0,
          totalCost = 75000.0,
          notes = "Produksi pagi batch 1"
        )
      )
      productionDao.insertProduction(
        ProductionEntity(
          productId = p2Id,
          productName = "Basreng",
          dateMillis = now,
          dayName = "Minggu",
          formattedDate = "16 Agustus 2026",
          formattedTime = "08:15",
          qty = 30,
          pricePerUnit = 5000.0,
          costPerUnit = 2800.0,
          potentialRevenue = 150000.0,
          totalCost = 84000.0,
          notes = "Basreng daun jeruk ekstra pedas"
        )
      )
      productionDao.insertProduction(
        ProductionEntity(
          productId = p3Id,
          productName = "Kerupuk Seblak",
          dateMillis = now,
          dayName = "Minggu",
          formattedDate = "16 Agustus 2026",
          formattedTime = "09:00",
          qty = 30,
          pricePerUnit = 5000.0,
          costPerUnit = 2400.0,
          potentialRevenue = 150000.0,
          totalCost = 72000.0,
          notes = "Kerupuk seblak gurih kencur"
        )
      )

      // 4. Initial Sample Sales (10 Makaroni, 8 Basreng, 5 Kerupuk Seblak)
      val sale1Id = saleDao.insertSale(
        SaleEntity(
          dateMillis = now,
          dayName = "Minggu",
          formattedDate = "16 Agustus 2026",
          formattedTime = "10:30",
          customerName = "Bu Siti",
          paymentMethod = "Tunai",
          totalAmount = 50000.0,
          totalCost = 25000.0,
          netProfit = 25000.0,
          notes = "Beli makaroni untuk arisan",
          itemsSummary = "10x Makaroni",
          totalQty = 10
        )
      )
      saleDao.insertSaleItems(
        listOf(
          SaleItemEntity(
            saleId = sale1Id,
            productId = p1Id,
            productName = "Makaroni",
            qty = 10,
            pricePerUnit = 5000.0,
            costPerUnit = 2500.0,
            subtotal = 50000.0
          )
        )
      )

      val sale2Id = saleDao.insertSale(
        SaleEntity(
          dateMillis = now,
          dayName = "Minggu",
          formattedDate = "16 Agustus 2026",
          formattedTime = "13:45",
          customerName = "Kang Asep",
          paymentMethod = "QRIS",
          totalAmount = 40000.0,
          totalCost = 22400.0,
          netProfit = 17600.0,
          notes = "Basreng pedas level 3",
          itemsSummary = "8x Basreng",
          totalQty = 8
        )
      )
      saleDao.insertSaleItems(
        listOf(
          SaleItemEntity(
            saleId = sale2Id,
            productId = p2Id,
            productName = "Basreng",
            qty = 8,
            pricePerUnit = 5000.0,
            costPerUnit = 2800.0,
            subtotal = 40000.0
          )
        )
      )

      val sale3Id = saleDao.insertSale(
        SaleEntity(
          dateMillis = now,
          dayName = "Minggu",
          formattedDate = "16 Agustus 2026",
          formattedTime = "15:20",
          customerName = "Neng Rina",
          paymentMethod = "Tunai",
          totalAmount = 25000.0,
          totalCost = 12000.0,
          netProfit = 13000.0,
          notes = "Kerupuk seblak pedas manis",
          itemsSummary = "5x Kerupuk Seblak",
          totalQty = 5
        )
      )
      saleDao.insertSaleItems(
        listOf(
          SaleItemEntity(
            saleId = sale3Id,
            productId = p3Id,
            productName = "Kerupuk Seblak",
            qty = 5,
            pricePerUnit = 5000.0,
            costPerUnit = 2400.0,
            subtotal = 25000.0
          )
        )
      )

      // 5. Initial Expenses (Minyak, Plastik, Bumbu = Rp70.000)
      expenseDao.insertExpense(
        ExpenseEntity(
          dateMillis = now,
          dayName = "Minggu",
          formattedDate = "16 Agustus 2026",
          formattedTime = "06:45",
          itemName = "Minyak Goreng",
          category = "Bahan Baku",
          qty = 2.0,
          unit = "Liter",
          unitPrice = 20000.0,
          totalAmount = 40000.0,
          placeOrStore = "Pasar Subuh",
          notes = "Minyak kemasan 2 liter untuk penggorengan"
        )
      )
      expenseDao.insertExpense(
        ExpenseEntity(
          dateMillis = now,
          dayName = "Minggu",
          formattedDate = "16 Agustus 2026",
          formattedTime = "07:00",
          itemName = "Plastik Standing Pouch & Klip",
          category = "Kemasan & Label",
          qty = 1.0,
          unit = "Pack",
          unitPrice = 15000.0,
          totalAmount = 15000.0,
          placeOrStore = "Toko Plastik Makmur",
          notes = "Plastik tebal 12x20cm isi 50 lembar"
        )
      )
      expenseDao.insertExpense(
        ExpenseEntity(
          dateMillis = now,
          dayName = "Minggu",
          formattedDate = "16 Agustus 2026",
          formattedTime = "07:15",
          itemName = "Bumbu Tabur Pedas & Asin",
          category = "Bahan Baku",
          qty = 3.0,
          unit = "Pack",
          unitPrice = 5000.0,
          totalAmount = 15000.0,
          placeOrStore = "Toko Bumbu Barokah",
          notes = "Bumbu bubuk balado dan cabai bubuk aida"
        )
      )
    }
  }
}
