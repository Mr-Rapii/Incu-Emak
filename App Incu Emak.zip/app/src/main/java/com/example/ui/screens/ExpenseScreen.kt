package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.local.entity.ExpenseEntity
import com.example.ui.components.ConfirmationDialog
import com.example.ui.components.ImageViewerDialog
import com.example.ui.components.PhotoAttachmentSelector
import com.example.ui.theme.ExpenseRed
import com.example.ui.theme.SecondaryGolden
import com.example.ui.util.FormatUtils
import com.example.ui.viewmodel.MainViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExpenseScreen(
  viewModel: MainViewModel,
  modifier: Modifier = Modifier
) {
  val expenses by viewModel.expenses.collectAsStateWithLifecycle()

  var searchQuery by remember { mutableStateOf("") }
  var selectedCategory by remember { mutableStateOf("Semua") }
  var showAddDialog by remember { mutableStateOf(false) }
  var selectedImageDialog by remember { mutableStateOf<ExpenseEntity?>(null) }
  var itemToDelete by remember { mutableStateOf<ExpenseEntity?>(null) }

  val categories = listOf("Semua", "Bahan Baku", "Kemasan & Label", "Gas & Operasional", "Transport / Ongkir", "Lain-lain")

  val filteredExpenses = expenses.filter {
    (selectedCategory == "Semua" || it.category == selectedCategory) &&
        (it.itemName.contains(searchQuery, ignoreCase = true) ||
            it.placeOrStore.contains(searchQuery, ignoreCase = true) ||
            it.notes.contains(searchQuery, ignoreCase = true) ||
            it.formattedDate.contains(searchQuery, ignoreCase = true))
  }

  val totalBelanja = filteredExpenses.sumOf { it.totalAmount }

  Scaffold(
    modifier = modifier.fillMaxSize().testTag("expense_screen"),
    floatingActionButton = {
      FloatingActionButton(
        onClick = { showAddDialog = true },
        containerColor = ExpenseRed,
        contentColor = Color.White,
        modifier = Modifier.testTag("add_expense_fab")
      ) {
        Icon(Icons.Default.Add, contentDescription = "Catat Belanja")
      }
    }
  ) { innerPadding ->
    LazyColumn(
      modifier = Modifier
        .fillMaxSize()
        .padding(innerPadding)
        .background(MaterialTheme.colorScheme.background),
      contentPadding = PaddingValues(16.dp),
      verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
      // 1. Header Summary Card
      item {
        Card(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(20.dp),
          colors = CardDefaults.cardColors(containerColor = ExpenseRed.copy(alpha = 0.1f))
        ) {
          Column(modifier = Modifier.padding(16.dp)) {
            Text(
              text = "Data Belanja & Pengeluaran",
              style = MaterialTheme.typography.titleMedium,
              fontWeight = FontWeight.ExtraBold,
              color = ExpenseRed
            )
            Text(
              text = "Semua pembelian bahan baku, kemasan, dan operasional dijumlahkan otomatis",
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(14.dp))

            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Column {
                Text("Total Pengeluaran", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(FormatUtils.formatRupiah(totalBelanja), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = ExpenseRed)
              }
              Surface(
                color = MaterialTheme.colorScheme.surface,
                shape = RoundedCornerShape(12.dp)
              ) {
                Text(
                  text = "${filteredExpenses.size} transaksi",
                  style = MaterialTheme.typography.labelMedium,
                  fontWeight = FontWeight.Bold,
                  modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                )
              }
            }
          }
        }
      }

      // 2. Category Filter Chips
      item {
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          items(categories) { cat ->
            FilterChip(
              selected = selectedCategory == cat,
              onClick = { selectedCategory = cat },
              label = { Text(cat, fontSize = 12.sp) },
              colors = FilterChipDefaults.filterChipColors(
                selectedContainerColor = ExpenseRed.copy(alpha = 0.15f),
                selectedLabelColor = ExpenseRed
              )
            )
          }
        }
      }

      // 3. Search Bar
      item {
        OutlinedTextField(
          value = searchQuery,
          onValueChange = { searchQuery = it },
          modifier = Modifier.fillMaxWidth(),
          placeholder = { Text("Cari barang belanja, toko, tanggal...") },
          leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
          shape = RoundedCornerShape(14.dp),
          singleLine = true
        )
      }

      // 4. Expense List
      if (filteredExpenses.isEmpty()) {
        item {
          Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
          ) {
            Column(
              modifier = Modifier
                .fillMaxWidth()
                .padding(32.dp),
              horizontalAlignment = Alignment.CenterHorizontally
            ) {
              Icon(Icons.Default.ReceiptLong, contentDescription = null, modifier = Modifier.size(48.dp), tint = ExpenseRed.copy(alpha = 0.4f))
              Spacer(modifier = Modifier.height(8.dp))
              Text("Belum ada data pengeluaran", fontWeight = FontWeight.Bold)
              Text("Tekan tombol + di bawah untuk mencatat nota belanja", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
          }
        }
      } else {
        items(filteredExpenses, key = { it.id }) { exp ->
          ExpenseCard(
            expense = exp,
            onImageClick = { selectedImageDialog = exp },
            onDeleteClick = { itemToDelete = exp }
          )
        }
      }
    }
  }

  // Add Expense Dialog
  if (showAddDialog) {
    AddExpenseDialog(
      onDismiss = { showAddDialog = false },
      onSave = { name, cat, qty, unit, price, dateMillis, store, notes, photoUri ->
        viewModel.addExpense(name, cat, qty, unit, price, dateMillis, store, notes, photoUri)
        showAddDialog = false
      }
    )
  }

  // Delete Confirmation Dialog
  itemToDelete?.let { exp ->
    ConfirmationDialog(
      title = "Hapus Pengeluaran?",
      message = "Yakin ingin menghapus catatan belanja ${exp.itemName} senilai ${FormatUtils.formatRupiah(exp.totalAmount)}?",
      onConfirm = {
        viewModel.deleteExpense(exp)
        itemToDelete = null
      },
      onDismiss = { itemToDelete = null }
    )
  }

  // Image Viewer Dialog
  selectedImageDialog?.let { exp ->
    ImageViewerDialog(
      photoUri = exp.receiptPhotoUri ?: "",
      title = "Nota Belanja ${exp.itemName}",
      subtitle = "${exp.category} • ${FormatUtils.formatRupiah(exp.totalAmount)}",
      onDismiss = { selectedImageDialog = null }
    )
  }
}

@Composable
private fun ExpenseCard(
  expense: ExpenseEntity,
  onImageClick: () -> Unit,
  onDeleteClick: () -> Unit
) {
  Card(
    modifier = Modifier.fillMaxWidth(),
    shape = RoundedCornerShape(18.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
  ) {
    Column(modifier = Modifier.padding(16.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Box(
            modifier = Modifier
              .size(40.dp)
              .background(ExpenseRed.copy(alpha = 0.12f), CircleShape),
            contentAlignment = Alignment.Center
          ) {
            Icon(Icons.Default.ReceiptLong, contentDescription = null, tint = ExpenseRed, modifier = Modifier.size(20.dp))
          }
          Spacer(modifier = Modifier.width(12.dp))
          Column {
            Text(
              text = expense.itemName,
              style = MaterialTheme.typography.titleMedium,
              fontWeight = FontWeight.Bold
            )
            Text(
              text = "${expense.dayName}, ${expense.formattedDate} • ${expense.formattedTime}",
              style = MaterialTheme.typography.labelSmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }
        }

        IconButton(onClick = onDeleteClick) {
          Icon(Icons.Default.Delete, contentDescription = "Hapus", tint = ExpenseRed.copy(alpha = 0.7f), modifier = Modifier.size(20.dp))
        }
      }

      Spacer(modifier = Modifier.height(12.dp))

      Surface(
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(12.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Text(
              text = "${expense.qty} ${expense.unit} × ${FormatUtils.formatRupiah(expense.unitPrice)}",
              style = MaterialTheme.typography.bodyMedium,
              fontWeight = FontWeight.SemiBold
            )
            Text(
              text = FormatUtils.formatRupiah(expense.totalAmount),
              style = MaterialTheme.typography.titleMedium,
              fontWeight = FontWeight.ExtraBold,
              color = ExpenseRed
            )
          }

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Text(
              text = "Kategori: ${expense.category}",
              style = MaterialTheme.typography.labelSmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            if (expense.placeOrStore.isNotBlank()) {
              Text(
                text = "Toko: ${expense.placeOrStore}",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }
          }
        }
      }

      if (expense.notes.isNotBlank()) {
        Spacer(modifier = Modifier.height(8.dp))
        Text(
          text = "Catatan: ${expense.notes}",
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
      }

      if (!expense.receiptPhotoUri.isNullOrBlank()) {
        Spacer(modifier = Modifier.height(10.dp))
        Row(
          modifier = Modifier
            .clip(RoundedCornerShape(10.dp))
            .clickable { onImageClick() }
            .background(SecondaryGolden.copy(alpha = 0.1f))
            .padding(horizontal = 10.dp, vertical = 6.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Icon(Icons.Default.Image, contentDescription = null, tint = SecondaryGolden, modifier = Modifier.size(16.dp))
          Spacer(modifier = Modifier.width(6.dp))
          Text("Lihat Foto Nota Belanja", style = MaterialTheme.typography.labelSmall, color = SecondaryGolden, fontWeight = FontWeight.Bold)
        }
      }
    }
  }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AddExpenseDialog(
  onDismiss: () -> Unit,
  onSave: (String, String, Double, String, Double, Long, String, String, String?) -> Unit
) {
  var itemName by remember { mutableStateOf("") }
  var category by remember { mutableStateOf("Bahan Baku") }
  var qtyText by remember { mutableStateOf("1") }
  var unit by remember { mutableStateOf("pack") }
  var unitPriceText by remember { mutableStateOf("15000") }
  var placeOrStore by remember { mutableStateOf("Pasar Subuh") }
  var notes by remember { mutableStateOf("") }
  var photoUri by remember { mutableStateOf<String?>(null) }
  var categoryExpanded by remember { mutableStateOf(false) }

  val categories = listOf("Bahan Baku", "Kemasan & Label", "Gas & Operasional", "Transport / Ongkir", "Lain-lain")
  val dateMillis = System.currentTimeMillis()

  val qty = qtyText.toDoubleOrNull() ?: 0.0
  val unitPrice = unitPriceText.toDoubleOrNull() ?: 0.0
  val total = qty * unitPrice

  AlertDialog(
    onDismissRequest = onDismiss,
    title = { Text("Catat Pengeluaran / Belanja", fontWeight = FontWeight.Bold) },
    text = {
      Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        OutlinedTextField(
          value = itemName,
          onValueChange = { itemName = it },
          label = { Text("Nama Barang (e.g. Minyak, Plastik, Bumbu)") },
          modifier = Modifier.fillMaxWidth(),
          singleLine = true
        )

        ExposedDropdownMenuBox(
          expanded = categoryExpanded,
          onExpandedChange = { categoryExpanded = !categoryExpanded }
        ) {
          OutlinedTextField(
            value = category,
            onValueChange = {},
            readOnly = true,
            label = { Text("Kategori") },
            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = categoryExpanded) },
            modifier = Modifier.menuAnchor().fillMaxWidth()
          )
          ExposedDropdownMenu(
            expanded = categoryExpanded,
            onDismissRequest = { categoryExpanded = false }
          ) {
            categories.forEach { cat ->
              DropdownMenuItem(
                text = { Text(cat) },
                onClick = {
                  category = cat
                  categoryExpanded = false
                }
              )
            }
          }
        }

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          OutlinedTextField(
            value = qtyText,
            onValueChange = { qtyText = it },
            label = { Text("Jumlah") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier.weight(1f)
          )
          OutlinedTextField(
            value = unit,
            onValueChange = { unit = it },
            label = { Text("Satuan (kg/pack/liter)") },
            modifier = Modifier.weight(1f)
          )
        }

        OutlinedTextField(
          value = unitPriceText,
          onValueChange = { unitPriceText = it },
          label = { Text("Harga Satuan (Rp)") },
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
          modifier = Modifier.fillMaxWidth()
        )

        Surface(
          color = ExpenseRed.copy(alpha = 0.1f),
          shape = RoundedCornerShape(12.dp),
          modifier = Modifier.fillMaxWidth()
        ) {
          Row(
            modifier = Modifier.padding(10.dp),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Text("Total Belanja:", fontSize = 12.sp)
            Text(FormatUtils.formatRupiah(total), fontWeight = FontWeight.ExtraBold, color = ExpenseRed)
          }
        }

        OutlinedTextField(
          value = placeOrStore,
          onValueChange = { placeOrStore = it },
          label = { Text("Tempat Membeli (Toko/Pasar)") },
          modifier = Modifier.fillMaxWidth(),
          singleLine = true
        )

        OutlinedTextField(
          value = notes,
          onValueChange = { notes = it },
          label = { Text("Catatan") },
          modifier = Modifier.fillMaxWidth(),
          singleLine = true
        )

        PhotoAttachmentSelector(
          selectedPhotoUri = photoUri,
          onPhotoSelected = { photoUri = it },
          label = "Foto Nota / Struk Belanja"
        )
      }
    },
    confirmButton = {
      Button(
        onClick = {
          if (itemName.isNotBlank() && total > 0) {
            onSave(itemName, category, qty, unit, unitPrice, dateMillis, placeOrStore, notes, photoUri)
          }
        },
        enabled = itemName.isNotBlank() && total > 0,
        colors = ButtonDefaults.buttonColors(containerColor = ExpenseRed)
      ) {
        Text("Simpan Belanja", color = Color.White)
      }
    },
    dismissButton = {
      TextButton(onClick = onDismiss) { Text("Batal") }
    }
  )
}
