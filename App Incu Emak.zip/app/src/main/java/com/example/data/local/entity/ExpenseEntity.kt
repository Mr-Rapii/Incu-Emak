package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "expenses")
data class ExpenseEntity(
  @PrimaryKey(autoGenerate = true)
  val id: Long = 0,
  val dateMillis: Long,
  val dayName: String,
  val formattedDate: String,
  val formattedTime: String,
  val itemName: String,
  val category: String = "Bahan Baku", // Bahan Baku, Kemasan & Label, Gas & Operasional, Transport / Ongkir, Lain-lain
  val qty: Double = 1.0,
  val unit: String = "pack", // kg, liter, pack, pcs, tabung, lembar
  val unitPrice: Double,
  val totalAmount: Double,
  val placeOrStore: String = "",
  val notes: String = "",
  val receiptPhotoUri: String? = null,
  val createdAt: Long = System.currentTimeMillis()
)
