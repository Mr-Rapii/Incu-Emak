package com.example.ui.util

import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

object DateUtils {
  private val indonesianLocale = Locale("id", "ID")

  val dayNames = arrayOf("Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu")
  val monthNames = arrayOf(
    "Januari", "Februari", "Maret", "April", "Mei", "Juni",
    "Juli", "Agustus", "September", "Oktober", "November", "Desember"
  )

  fun getDayName(timeMillis: Long): String {
    val cal = Calendar.getInstance().apply { timeInMillis = timeMillis }
    val dayOfWeek = cal.get(Calendar.DAY_OF_WEEK) // 1 = Sunday, 2 = Monday, ...
    return dayNames[dayOfWeek - 1]
  }

  fun getFormattedDate(timeMillis: Long): String {
    val cal = Calendar.getInstance().apply { timeInMillis = timeMillis }
    val day = cal.get(Calendar.DAY_OF_MONTH)
    val month = monthNames[cal.get(Calendar.MONTH)]
    val year = cal.get(Calendar.YEAR)
    return "$day $month $year"
  }

  fun getFullFormattedDateWithDay(timeMillis: Long): String {
    return "${getDayName(timeMillis)}, ${getFormattedDate(timeMillis)}"
  }

  fun getFormattedTime(timeMillis: Long): String {
    val sdf = SimpleDateFormat("HH:mm", indonesianLocale)
    return sdf.format(Date(timeMillis))
  }

  fun getStartOfDay(timeMillis: Long): Long {
    val cal = Calendar.getInstance().apply {
      timeInMillis = timeMillis
      set(Calendar.HOUR_OF_DAY, 0)
      set(Calendar.MINUTE, 0)
      set(Calendar.SECOND, 0)
      set(Calendar.MILLISECOND, 0)
    }
    return cal.timeInMillis
  }

  fun getEndOfDay(timeMillis: Long): Long {
    val cal = Calendar.getInstance().apply {
      timeInMillis = timeMillis
      set(Calendar.HOUR_OF_DAY, 23)
      set(Calendar.MINUTE, 59)
      set(Calendar.SECOND, 59)
      set(Calendar.MILLISECOND, 999)
    }
    return cal.timeInMillis
  }

  fun getStartOfWeek(timeMillis: Long): Long {
    val cal = Calendar.getInstance().apply {
      timeInMillis = timeMillis
      firstDayOfWeek = Calendar.MONDAY
      set(Calendar.DAY_OF_WEEK, Calendar.MONDAY)
      set(Calendar.HOUR_OF_DAY, 0)
      set(Calendar.MINUTE, 0)
      set(Calendar.SECOND, 0)
      set(Calendar.MILLISECOND, 0)
    }
    return cal.timeInMillis
  }

  fun getEndOfWeek(timeMillis: Long): Long {
    val start = getStartOfWeek(timeMillis)
    val cal = Calendar.getInstance().apply {
      timeInMillis = start
      add(Calendar.DAY_OF_YEAR, 6)
      set(Calendar.HOUR_OF_DAY, 23)
      set(Calendar.MINUTE, 59)
      set(Calendar.SECOND, 59)
      set(Calendar.MILLISECOND, 999)
    }
    return cal.timeInMillis
  }

  fun getStartOfMonth(timeMillis: Long): Long {
    val cal = Calendar.getInstance().apply {
      timeInMillis = timeMillis
      set(Calendar.DAY_OF_MONTH, 1)
      set(Calendar.HOUR_OF_DAY, 0)
      set(Calendar.MINUTE, 0)
      set(Calendar.SECOND, 0)
      set(Calendar.MILLISECOND, 0)
    }
    return cal.timeInMillis
  }

  fun getEndOfMonth(timeMillis: Long): Long {
    val cal = Calendar.getInstance().apply {
      timeInMillis = timeMillis
      set(Calendar.DAY_OF_MONTH, getActualMaximum(Calendar.DAY_OF_MONTH))
      set(Calendar.HOUR_OF_DAY, 23)
      set(Calendar.MINUTE, 59)
      set(Calendar.SECOND, 59)
      set(Calendar.MILLISECOND, 999)
    }
    return cal.timeInMillis
  }

  fun isSameDay(timeMillis1: Long, timeMillis2: Long): Boolean {
    val cal1 = Calendar.getInstance().apply { timeInMillis = timeMillis1 }
    val cal2 = Calendar.getInstance().apply { timeInMillis = timeMillis2 }
    return cal1.get(Calendar.YEAR) == cal2.get(Calendar.YEAR) &&
        cal1.get(Calendar.DAY_OF_YEAR) == cal2.get(Calendar.DAY_OF_YEAR)
  }

  fun getDaysInMonth(year: Int, monthIndex: Int): Int {
    val cal = Calendar.getInstance().apply {
      set(Calendar.YEAR, year)
      set(Calendar.MONTH, monthIndex)
      set(Calendar.DAY_OF_MONTH, 1)
    }
    return cal.getActualMaximum(Calendar.DAY_OF_MONTH)
  }

  fun getFirstDayOfWeekInMonth(year: Int, monthIndex: Int): Int {
    val cal = Calendar.getInstance().apply {
      set(Calendar.YEAR, year)
      set(Calendar.MONTH, monthIndex)
      set(Calendar.DAY_OF_MONTH, 1)
    }
    return cal.get(Calendar.DAY_OF_WEEK) // 1=Sun, 2=Mon...
  }
}

object FormatUtils {
  fun formatRupiah(amount: Double): String {
    val formatter = NumberFormat.getNumberInstance(Locale("id", "ID"))
    return "Rp" + formatter.format(amount.toLong())
  }

  fun formatQty(qty: Int, unit: String = "pcs"): String {
    return "$qty $unit"
  }

  fun formatPercentage(value: Double): String {
    val sign = if (value > 0) "+" else ""
    return String.format(Locale.US, "%s%.1f%%", sign, value)
  }
}
