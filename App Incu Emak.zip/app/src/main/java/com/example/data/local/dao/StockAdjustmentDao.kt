package com.example.data.local.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.data.local.entity.BusinessTargetEntity
import com.example.data.local.entity.StockAdjustmentEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface StockAdjustmentDao {
  @Query("SELECT * FROM stock_adjustments ORDER BY dateMillis DESC, id DESC")
  fun getAllAdjustments(): Flow<List<StockAdjustmentEntity>>

  @Query("SELECT * FROM stock_adjustments WHERE productId = :productId ORDER BY dateMillis DESC")
  fun getAdjustmentsByProduct(productId: Long): Flow<List<StockAdjustmentEntity>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insert(adjustment: StockAdjustmentEntity): Long

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertAll(adjustments: List<StockAdjustmentEntity>)

  @Delete
  suspend fun delete(adjustment: StockAdjustmentEntity)

  @Query("DELETE FROM stock_adjustments")
  suspend fun deleteAll()
}

@Dao
interface BusinessTargetDao {
  @Query("SELECT * FROM business_targets WHERE id = 1 LIMIT 1")
  fun getTarget(): Flow<BusinessTargetEntity?>

  @Query("SELECT * FROM business_targets WHERE id = 1 LIMIT 1")
  suspend fun getTargetOnce(): BusinessTargetEntity?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun saveTarget(target: BusinessTargetEntity)
}
