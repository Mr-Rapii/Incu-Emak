package com.example.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.ExpenseRed
import com.example.ui.theme.PrimaryWarm
import com.example.ui.theme.ProfitGreen
import com.example.ui.theme.RevenueBlue
import com.example.ui.theme.SecondaryGolden
import com.example.ui.util.FormatUtils
import com.example.ui.viewmodel.DailyStat

@Composable
fun TrendLineChart(
  stats: List<DailyStat>,
  modifier: Modifier = Modifier,
  selectedMetric: String = "Omzet" // "Omzet", "Keuntungan", "Pengeluaran"
) {
  var selectedIndex by remember { mutableStateOf<Int?>(null) }

  val metricValues = stats.map { stat ->
    when (selectedMetric) {
      "Keuntungan" -> stat.profit
      "Pengeluaran" -> stat.expense
      else -> stat.revenue
    }
  }

  val primaryColor = when (selectedMetric) {
    "Keuntungan" -> ProfitGreen
    "Pengeluaran" -> ExpenseRed
    else -> PrimaryWarm
  }

  val maxVal = (metricValues.maxOrNull() ?: 1.0).coerceAtLeast(10000.0)

  Card(
    modifier = modifier.fillMaxWidth(),
    shape = RoundedCornerShape(20.dp),
    colors = CardDefaults.cardColors(
      containerColor = MaterialTheme.colorScheme.surface
    ),
    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
  ) {
    Column(modifier = Modifier.padding(16.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text(
            text = "Grafik Perkembangan $selectedMetric",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold
          )
          Text(
            text = "Pergerakan 7 hari terakhir",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }

        if (selectedIndex != null && selectedIndex!! in stats.indices) {
          val sel = stats[selectedIndex!!]
          val valAmount = when (selectedMetric) {
            "Keuntungan" -> sel.profit
            "Pengeluaran" -> sel.expense
            else -> sel.revenue
          }
          Surface(
            color = primaryColor.copy(alpha = 0.12f),
            shape = RoundedCornerShape(12.dp)
          ) {
            Text(
              text = "${sel.dayName}: ${FormatUtils.formatRupiah(valAmount)}",
              style = MaterialTheme.typography.labelMedium,
              color = primaryColor,
              fontWeight = FontWeight.SemiBold,
              modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(16.dp))

      Box(
        modifier = Modifier
          .fillMaxWidth()
          .height(160.dp)
      ) {
        Canvas(
          modifier = Modifier
            .fillMaxSize()
            .pointerInput(stats) {
              detectTapGestures { offset ->
                val widthPerPoint = size.width / (stats.size.coerceAtLeast(1))
                val index = (offset.x / widthPerPoint).toInt().coerceIn(0, stats.size - 1)
                selectedIndex = index
              }
            }
        ) {
          val canvasWidth = size.width
          val canvasHeight = size.height
          val paddingBottom = 20.dp.toPx()
          val chartHeight = canvasHeight - paddingBottom

          if (stats.isEmpty()) return@Canvas

          // Draw horizontal grid lines
          val gridCount = 3
          for (g in 0..gridCount) {
            val y = chartHeight * (g.toFloat() / gridCount)
            drawLine(
              color = Color.LightGray.copy(alpha = 0.35f),
              start = Offset(0f, y),
              end = Offset(canvasWidth, y),
              strokeWidth = 1.dp.toPx()
            )
          }

          val stepX = canvasWidth / (stats.size - 1).coerceAtLeast(1)
          val points = mutableListOf<Offset>()

          for (i in stats.indices) {
            val normalized = (metricValues[i] / maxVal).coerceIn(0.0, 1.0).toFloat()
            val x = i * stepX
            val y = chartHeight - (normalized * (chartHeight - 16.dp.toPx())) - 8.dp.toPx()
            points.add(Offset(x, y))
          }

          // Build filled gradient path
          val fillPath = Path().apply {
            moveTo(points.first().x, chartHeight)
            lineTo(points.first().x, points.first().y)
            for (i in 0 until points.size - 1) {
              val p0 = points[i]
              val p1 = points[i + 1]
              val controlX = (p0.x + p1.x) / 2
              cubicTo(controlX, p0.y, controlX, p1.y, p1.x, p1.y)
            }
            lineTo(points.last().x, chartHeight)
            close()
          }

          drawPath(
            path = fillPath,
            brush = Brush.verticalGradient(
              colors = listOf(
                primaryColor.copy(alpha = 0.35f),
                primaryColor.copy(alpha = 0.02f)
              ),
              startY = 0f,
              endY = chartHeight
            )
          )

          // Build line stroke path
          val strokePath = Path().apply {
            moveTo(points.first().x, points.first().y)
            for (i in 0 until points.size - 1) {
              val p0 = points[i]
              val p1 = points[i + 1]
              val controlX = (p0.x + p1.x) / 2
              cubicTo(controlX, p0.y, controlX, p1.y, p1.x, p1.y)
            }
          }

          drawPath(
            path = strokePath,
            color = primaryColor,
            style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round)
          )

          // Draw Point dots
          points.forEachIndexed { idx, point ->
            val isSelected = selectedIndex == idx
            val radius = if (isSelected) 7.dp.toPx() else 4.dp.toPx()

            drawCircle(
              color = Color.White,
              radius = radius + 2.dp.toPx(),
              center = point
            )
            drawCircle(
              color = if (isSelected) primaryColor else primaryColor.copy(alpha = 0.8f),
              radius = radius,
              center = point
            )
          }
        }
      }

      // X-Axis Day Labels
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        stats.forEachIndexed { idx, stat ->
          val isSelected = selectedIndex == idx
          Text(
            text = stat.dayName.take(3),
            fontSize = 11.sp,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
            color = if (isSelected) primaryColor else MaterialTheme.colorScheme.onSurfaceVariant
          )
        }
      }
    }
  }
}

@Composable
fun MultiMetricBarChart(
  stats: List<DailyStat>,
  modifier: Modifier = Modifier
) {
  Card(
    modifier = modifier.fillMaxWidth(),
    shape = RoundedCornerShape(20.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
  ) {
    Column(modifier = Modifier.padding(16.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text(
            text = "Perbandingan Keuangan Mingguan",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold
          )
          Text(
            text = "Omzet, Pengeluaran & Keuntungan",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }
      }

      Spacer(modifier = Modifier.height(12.dp))

      // Legend
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(16.dp)
      ) {
        LegendItem(color = RevenueBlue, label = "Omzet")
        LegendItem(color = ExpenseRed, label = "Pengeluaran")
        LegendItem(color = ProfitGreen, label = "Keuntungan")
      }

      Spacer(modifier = Modifier.height(16.dp))

      val maxVal = stats.flatMap { listOf(it.revenue, it.expense, it.profit) }
        .maxOrNull()?.coerceAtLeast(10000.0) ?: 10000.0

      Row(
        modifier = Modifier
          .fillMaxWidth()
          .height(140.dp),
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.Bottom
      ) {
        stats.takeLast(7).forEach { stat ->
          Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.weight(1f)
          ) {
            Row(
              horizontalArrangement = Arrangement.spacedBy(2.dp),
              verticalAlignment = Alignment.Bottom,
              modifier = Modifier
                .height(110.dp)
                .padding(horizontal = 2.dp)
            ) {
              // Bar 1: Omzet
              val revRatio = (stat.revenue / maxVal).coerceIn(0.05, 1.0).toFloat()
              Box(
                modifier = Modifier
                  .weight(1f)
                  .fillMaxHeight(revRatio)
                  .background(RevenueBlue, RoundedCornerShape(topStart = 4.dp, topEnd = 4.dp))
              )

              // Bar 2: Pengeluaran
              val expRatio = (stat.expense / maxVal).coerceIn(0.05, 1.0).toFloat()
              Box(
                modifier = Modifier
                  .weight(1f)
                  .fillMaxHeight(expRatio)
                  .background(ExpenseRed, RoundedCornerShape(topStart = 4.dp, topEnd = 4.dp))
              )

              // Bar 3: Keuntungan
              val profitRatio = (stat.profit.coerceAtLeast(0.0) / maxVal).coerceIn(0.05, 1.0).toFloat()
              Box(
                modifier = Modifier
                  .weight(1f)
                  .fillMaxHeight(profitRatio)
                  .background(ProfitGreen, RoundedCornerShape(topStart = 4.dp, topEnd = 4.dp))
              )
            }

            Spacer(modifier = Modifier.height(6.dp))
            Text(
              text = stat.dayName.take(3),
              style = MaterialTheme.typography.labelSmall,
              fontSize = 10.sp,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }
        }
      }
    }
  }
}

@Composable
private fun LegendItem(color: Color, label: String) {
  Row(verticalAlignment = Alignment.CenterVertically) {
    Box(
      modifier = Modifier
        .size(10.dp)
        .background(color, CircleShape)
    )
    Spacer(modifier = Modifier.width(4.dp))
    Text(
      text = label,
      style = MaterialTheme.typography.labelSmall,
      color = MaterialTheme.colorScheme.onSurfaceVariant
    )
  }
}
