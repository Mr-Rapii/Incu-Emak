package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.example.data.local.entity.ProductEntity
import com.example.data.local.entity.ProductionEntity
import com.example.ui.components.ConfirmationDialog
import com.example.ui.components.ImageViewerDialog
import com.example.ui.components.PhotoAttachmentSelector
import com.example.ui.theme.ExpenseRed
import com.example.ui.theme.PrimaryWarm
import com.example.ui.theme.ProfitGreen
import com.example.ui.theme.SecondaryGolden
import com.example.ui.util.DateUtils
import com.example.ui.util.FormatUtils
import com.example.ui.viewmodel.MainViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProductionScreen(
  viewModel: MainViewModel,
  modifier: Modifier = Modifier
) {
  val productions by viewModel.productions.collectAsStateWithLifecycle()
  val products by viewModel.products.collectAsStateWithLifecycle()

  var searchQuery by remember { mutableStateOf("") }
  var showAddDialog by remember { mutableStateOf(false) }
  var selectedImageDialog by remember { mutableStateOf<ProductionEntity?>(null) }
  var itemToDelete by remember { mutableStateOf<ProductionEntity?>(null) }

  val filteredProductions = productions.filter {
    it.productName.contains(searchQuery, ignoreCase = true) ||
        it.dayName.contains(searchQuery, ignoreCase = true) ||
        it.formattedDate.contains(searchQuery, ignoreCase = true) ||
        it.notes.contains(searchQuery, ignoreCase = true)
  }

  val totalQtyCreated = filteredProductions.sumOf { it.qty }
  val totalPotentialRevenue = filteredProductions.sumOf { it.potentialRevenue }
  val totalCostSum = filteredProductions.sumOf { it.totalCost }

  Scaffold(
    modifier = modifier.fillMaxSize().testTag("production_screen"),
    floatingActionButton = {
      FloatingActionButton(
        onClick = { showAddDialog = true },
        containerColor = PrimaryWarm,
        contentColor = Color.White,
        modifier = Modifier.testTag("add_production_fab")
      ) {
        Icon(Icons.Default.Add, contentDescription = "Tambah Produksi")
      }
    }
  ) { innerPadding ->
    LazyColumn(
      modifier = Modifier
        .fillMaxSize()
        .padding(innerPadding)
        .background(MaterialTheme.colorScheme.background),
      contentPadding = PaddingValues(16.dp),
      verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
      // 1. Header Summary Card
      item {
        Card(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(20.dp),
          colors = CardDefaults.cardColors(containerColor = PrimaryWarm.copy(alpha = 0.1f))
        ) {
          Column(modifier = Modifier.padding(16.dp)) {
            Text(
              text = "Data & Catatan Produksi",
              style = MaterialTheme.typography.titleMedium,
              fontWeight = FontWeight.ExtraBold,
              color = PrimaryWarm
            )
            Text(
              text = "Setiap produksi otomatis menambah stok dan menghitung potensi omzet",
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(14.dp))

            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Column {
                Text("Total Dibuat", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text("$totalQtyCreated pcs", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = PrimaryWarm)
              }
              Column(horizontalAlignment = Alignment.End) {
                Text("Potensi Omzet", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(FormatUtils.formatRupiah(totalPotentialRevenue), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = ProfitGreen)
              }
            }
          }
        }
      }

      // 2. Search Bar
      item {
        OutlinedTextField(
          value = searchQuery,
          onValueChange = { searchQuery = it },
          modifier = Modifier
            .fillMaxWidth()
            .testTag("production_search_input"),
          placeholder = { Text("Cari produk, tanggal, catatan...") },
          leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
          shape = RoundedCornerShape(14.dp),
          singleLine = true
        )
      }

      // 3. Production List
      if (filteredProductions.isEmpty()) {
        item {
          Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
          ) {
            Column(
              modifier = Modifier
                .fillMaxWidth()
                .padding(32.dp),
              horizontalAlignment = Alignment.CenterHorizontally
            ) {
              Icon(Icons.Default.Inventory2, contentDescription = null, modifier = Modifier.size(48.dp), tint = PrimaryWarm.copy(alpha = 0.4f))
              Spacer(modifier = Modifier.height(8.dp))
              Text("Belum ada data produksi", fontWeight = FontWeight.Bold)
              Text("Tekan tombol + di bawah untuk mencatat produksi baru", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
          }
        }
      } else {
        items(filteredProductions, key = { it.id }) { prod ->
          ProductionCard(
            production = prod,
            onImageClick = { selectedImageDialog = prod },
            onDeleteClick = { itemToDelete = prod }
          )
        }
      }
    }
  }

  // Add Production Dialog
  if (showAddDialog) {
    AddProductionDialog(
      products = products,
      onDismiss = { showAddDialog = false },
      onSave = { prodId, prodName, qty, price, cost, dateMillis, notes, photoUri ->
        viewModel.addProduction(prodId, prodName, qty, price, cost, dateMillis, notes, photoUri)
        showAddDialog = false
      }
    )
  }

  // Delete Confirmation Dialog
  itemToDelete?.let { prod ->
    ConfirmationDialog(
      title = "Hapus Data Produksi?",
      message = "Menghapus produksi ${prod.productName} (${prod.qty} pcs) akan otomatis mengurangi stok produk kembali.",
      onConfirm = {
        viewModel.deleteProduction(prod)
        itemToDelete = null
      },
      onDismiss = { itemToDelete = null }
    )
  }

  // Image Viewer Dialog
  selectedImageDialog?.let { prod ->
    ImageViewerDialog(
      photoUri = prod.photoUri ?: "",
      title = "Foto Produksi ${prod.productName}",
      subtitle = "${prod.formattedDate} • ${prod.qty} pcs",
      onDismiss = { selectedImageDialog = null }
    )
  }
}

@Composable
private fun ProductionCard(
  production: ProductionEntity,
  onImageClick: () -> Unit,
  onDeleteClick: () -> Unit
) {
  Card(
    modifier = Modifier.fillMaxWidth(),
    shape = RoundedCornerShape(18.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
  ) {
    Column(modifier = Modifier.padding(16.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Box(
            modifier = Modifier
              .size(40.dp)
              .background(PrimaryWarm.copy(alpha = 0.12f), CircleShape),
            contentAlignment = Alignment.Center
          ) {
            Icon(Icons.Default.Inventory2, contentDescription = null, tint = PrimaryWarm, modifier = Modifier.size(20.dp))
          }
          Spacer(modifier = Modifier.width(12.dp))
          Column {
            Text(
              text = production.productName,
              style = MaterialTheme.typography.titleMedium,
              fontWeight = FontWeight.Bold
            )
            Text(
              text = "${production.dayName}, ${production.formattedDate} • ${production.formattedTime}",
              style = MaterialTheme.typography.labelSmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }
        }

        IconButton(onClick = onDeleteClick) {
          Icon(Icons.Default.Delete, contentDescription = "Hapus", tint = ExpenseRed.copy(alpha = 0.7f), modifier = Modifier.size(20.dp))
        }
      }

      Spacer(modifier = Modifier.height(12.dp))

      // Calculation breakdown: 30 × Rp5.000 = Rp150.000
      Surface(
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(12.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Text(
              text = "${production.qty} pcs × ${FormatUtils.formatRupiah(production.pricePerUnit)}",
              style = MaterialTheme.typography.bodyMedium,
              fontWeight = FontWeight.SemiBold
            )
            Text(
              text = "Potensi: ${FormatUtils.formatRupiah(production.potentialRevenue)}",
              style = MaterialTheme.typography.bodyMedium,
              fontWeight = FontWeight.Bold,
              color = ProfitGreen
            )
          }

          if (production.costPerUnit > 0) {
            Spacer(modifier = Modifier.height(4.dp))
            Text(
              text = "Modal Produksi: ${FormatUtils.formatRupiah(production.totalCost)} (${FormatUtils.formatRupiah(production.costPerUnit)}/pcs)",
              style = MaterialTheme.typography.labelSmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }
        }
      }

      if (production.notes.isNotBlank()) {
        Spacer(modifier = Modifier.height(8.dp))
        Text(
          text = "Catatan: ${production.notes}",
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
      }

      if (!production.photoUri.isNullOrBlank()) {
        Spacer(modifier = Modifier.height(10.dp))
        Row(
          modifier = Modifier
            .clip(RoundedCornerShape(10.dp))
            .clickable { onImageClick() }
            .background(SecondaryGolden.copy(alpha = 0.1f))
            .padding(horizontal = 10.dp, vertical = 6.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Icon(Icons.Default.Image, contentDescription = null, tint = SecondaryGolden, modifier = Modifier.size(16.dp))
          Spacer(modifier = Modifier.width(6.dp))
          Text("Lihat Foto Produksi", style = MaterialTheme.typography.labelSmall, color = SecondaryGolden, fontWeight = FontWeight.Bold)
        }
      }
    }
  }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AddProductionDialog(
  products: List<ProductEntity>,
  onDismiss: () -> Unit,
  onSave: (Long, String, Int, Double, Double, Long, String, String?) -> Unit
) {
  var selectedProduct by remember { mutableStateOf(products.firstOrNull()) }
  var qtyText by remember { mutableStateOf("30") }
  var priceText by remember { mutableStateOf(selectedProduct?.defaultPrice?.toInt()?.toString() ?: "5000") }
  var costText by remember { mutableStateOf(selectedProduct?.defaultCost?.toInt()?.toString() ?: "2500") }
  var notes by remember { mutableStateOf("Produksi pagi") }
  var photoUri by remember { mutableStateOf<String?>(null) }
  var expanded by remember { mutableStateOf(false) }

  val dateMillis = System.currentTimeMillis()
  val dayName = DateUtils.getDayName(dateMillis)
  val formattedDate = DateUtils.getFormattedDate(dateMillis)

  val qty = qtyText.toIntOrNull() ?: 0
  val price = priceText.toDoubleOrNull() ?: 0.0
  val cost = costText.toDoubleOrNull() ?: 0.0
  val potentialRevenue = qty * price
  val totalCost = qty * cost

  AlertDialog(
    onDismissRequest = onDismiss,
    title = {
      Column {
        Text("Catat Produksi Baru", fontWeight = FontWeight.Bold)
        Text("$dayName, $formattedDate", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
      }
    },
    text = {
      Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        // Product Dropdown
        ExposedDropdownMenuBox(
          expanded = expanded,
          onExpandedChange = { expanded = !expanded }
        ) {
          OutlinedTextField(
            value = selectedProduct?.name ?: "Pilih Produk",
            onValueChange = {},
            readOnly = true,
            label = { Text("Produk") },
            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
            modifier = Modifier
              .menuAnchor()
              .fillMaxWidth()
          )
          ExposedDropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false }
          ) {
            products.forEach { prod ->
              DropdownMenuItem(
                text = { Text("${prod.name} (Stok: ${prod.currentStock})") },
                onClick = {
                  selectedProduct = prod
                  priceText = prod.defaultPrice.toInt().toString()
                  costText = prod.defaultCost.toInt().toString()
                  expanded = false
                }
              )
            }
          }
        }

        // Qty Input
        OutlinedTextField(
          value = qtyText,
          onValueChange = { qtyText = it },
          label = { Text("Jumlah Dibuat (pcs)") },
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
          modifier = Modifier.fillMaxWidth()
        )

        // Price per pcs
        OutlinedTextField(
          value = priceText,
          onValueChange = { priceText = it },
          label = { Text("Harga Jual per pcs (Rp)") },
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
          modifier = Modifier.fillMaxWidth()
        )

        // Cost / HPP per pcs
        OutlinedTextField(
          value = costText,
          onValueChange = { costText = it },
          label = { Text("Modal / HPP per pcs (Rp)") },
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
          modifier = Modifier.fillMaxWidth()
        )

        // Live Calculated Revenue Card
        Surface(
          color = PrimaryWarm.copy(alpha = 0.1f),
          shape = RoundedCornerShape(12.dp),
          modifier = Modifier.fillMaxWidth()
        ) {
          Column(modifier = Modifier.padding(10.dp)) {
            Text(
              text = "Potensi Omzet: $qty × ${FormatUtils.formatRupiah(price)}",
              style = MaterialTheme.typography.bodySmall
            )
            Text(
              text = FormatUtils.formatRupiah(potentialRevenue),
              style = MaterialTheme.typography.titleMedium,
              fontWeight = FontWeight.ExtraBold,
              color = ProfitGreen
            )
          }
        }

        // Notes
        OutlinedTextField(
          value = notes,
          onValueChange = { notes = it },
          label = { Text("Catatan Produksi") },
          modifier = Modifier.fillMaxWidth(),
          singleLine = true
        )

        // Photo Attachment
        PhotoAttachmentSelector(
          selectedPhotoUri = photoUri,
          onPhotoSelected = { photoUri = it }
        )
      }
    },
    confirmButton = {
      Button(
        onClick = {
          selectedProduct?.let { prod ->
            if (qty > 0) {
              onSave(prod.id, prod.name, qty, price, cost, dateMillis, notes, photoUri)
            }
          }
        },
        enabled = selectedProduct != null && qty > 0,
        colors = ButtonDefaults.buttonColors(containerColor = PrimaryWarm)
      ) {
        Text("Simpan & Tambah Stok", color = Color.White)
      }
    },
    dismissButton = {
      TextButton(onClick = onDismiss) {
        Text("Batal")
      }
    }
  )
}
