package com.example.data.local.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.local.entity.ProductEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface ProductDao {
  @Query("SELECT * FROM products ORDER BY name ASC")
  fun getAllProducts(): Flow<List<ProductEntity>>

  @Query("SELECT * FROM products ORDER BY name ASC")
  suspend fun getAllProductsList(): List<ProductEntity>

  @Query("SELECT * FROM products WHERE id = :id LIMIT 1")
  suspend fun getProductById(id: Long): ProductEntity?

  @Query("SELECT * FROM products WHERE id = :id LIMIT 1")
  fun getProductByIdFlow(id: Long): Flow<ProductEntity?>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertProduct(product: ProductEntity): Long

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertAll(products: List<ProductEntity>)

  @Update
  suspend fun updateProduct(product: ProductEntity)

  @Query("UPDATE products SET currentStock = currentStock + :delta WHERE id = :id")
  suspend fun updateStock(id: Long, delta: Int)

  @Delete
  suspend fun deleteProduct(product: ProductEntity)

  @Query("DELETE FROM products")
  suspend fun deleteAll()
}
