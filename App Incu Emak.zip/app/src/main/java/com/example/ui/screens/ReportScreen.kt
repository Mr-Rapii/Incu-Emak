package com.example.ui.screens

import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.components.StatCard
import com.example.ui.theme.ExpenseRed
import com.example.ui.theme.PrimaryWarm
import com.example.ui.theme.ProfitGreen
import com.example.ui.theme.RevenueBlue
import com.example.ui.theme.SecondaryGolden
import com.example.ui.util.DateUtils
import com.example.ui.util.FormatUtils
import com.example.ui.viewmodel.MainViewModel
import kotlinx.coroutines.launch
import java.util.Calendar

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReportScreen(
  viewModel: MainViewModel,
  modifier: Modifier = Modifier
) {
  val context = LocalContext.current
  val coroutineScope = rememberCoroutineScope()

  val productions by viewModel.productions.collectAsStateWithLifecycle()
  val sales by viewModel.sales.collectAsStateWithLifecycle()
  val expenses by viewModel.expenses.collectAsStateWithLifecycle()
  val products by viewModel.products.collectAsStateWithLifecycle()

  var selectedTab by remember { mutableStateOf(0) } // 0 = Harian, 1 = Mingguan, 2 = Bulanan
  var selectedDateMillis by remember { mutableStateOf(System.currentTimeMillis()) }

  val tabTitles = listOf("Laporan Harian", "Laporan Mingguan", "Laporan Bulanan")

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .background(MaterialTheme.colorScheme.background)
      .testTag("report_screen"),
    contentPadding = PaddingValues(16.dp),
    verticalArrangement = Arrangement.spacedBy(14.dp)
  ) {
    // 1. Tab Selector
    item {
      TabRow(
        selectedTabIndex = selectedTab,
        containerColor = MaterialTheme.colorScheme.surface,
        modifier = Modifier.clip(RoundedCornerShape(14.dp))
      ) {
        tabTitles.forEachIndexed { index, title ->
          Tab(
            selected = selectedTab == index,
            onClick = { selectedTab = index },
            text = {
              Text(
                title.replace("Laporan ", ""),
                fontWeight = if (selectedTab == index) FontWeight.Bold else FontWeight.Normal,
                fontSize = 13.sp
              )
            }
          )
        }
      }
    }

    // 2. Date Navigation Header
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(8.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          IconButton(
            onClick = {
              val cal = Calendar.getInstance().apply { timeInMillis = selectedDateMillis }
              when (selectedTab) {
                0 -> cal.add(Calendar.DAY_OF_YEAR, -1)
                1 -> cal.add(Calendar.WEEK_OF_YEAR, -1)
                2 -> cal.add(Calendar.MONTH, -1)
              }
              selectedDateMillis = cal.timeInMillis
            }
          ) {
            Icon(Icons.Default.ChevronLeft, contentDescription = "Sebelumnya")
          }

          val labelText = when (selectedTab) {
            0 -> DateUtils.getFullFormattedDateWithDay(selectedDateMillis)
            1 -> {
              val start = DateUtils.getStartOfWeek(selectedDateMillis)
              val end = DateUtils.getEndOfWeek(selectedDateMillis)
              "${DateUtils.getFormattedDate(start)} – ${DateUtils.getFormattedDate(end)}"
            }
            2 -> {
              val cal = Calendar.getInstance().apply { timeInMillis = selectedDateMillis }
              "${DateUtils.monthNames[cal.get(Calendar.MONTH)]} ${cal.get(Calendar.YEAR)}"
            }
            else -> ""
          }

          Text(
            text = labelText,
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.Bold
          )

          IconButton(
            onClick = {
              val cal = Calendar.getInstance().apply { timeInMillis = selectedDateMillis }
              when (selectedTab) {
                0 -> cal.add(Calendar.DAY_OF_YEAR, 1)
                1 -> cal.add(Calendar.WEEK_OF_YEAR, 1)
                2 -> cal.add(Calendar.MONTH, 1)
              }
              selectedDateMillis = cal.timeInMillis
            }
          ) {
            Icon(Icons.Default.ChevronRight, contentDescription = "Berikutnya")
          }
        }
      }
    }

    // 3. Render Selected Report Content
    when (selectedTab) {
      0 -> {
        // Daily Report Content
        item {
          val dayStart = DateUtils.getStartOfDay(selectedDateMillis)
          val dayEnd = DateUtils.getEndOfDay(selectedDateMillis)

          val dayProds = productions.filter { it.dateMillis in dayStart..dayEnd }
          val daySales = sales.filter { it.dateMillis in dayStart..dayEnd }
          val dayExpenses = expenses.filter { it.dateMillis in dayStart..dayEnd }

          val totalProdQty = dayProds.sumOf { it.qty }
          val potRev = dayProds.sumOf { it.potentialRevenue }
          val actRev = daySales.sumOf { it.totalAmount }
          val expAmount = dayExpenses.sumOf { it.totalAmount }
          val profitAmount = actRev - expAmount

          DailyReportBreakdownCard(
            prods = dayProds,
            sales = daySales,
            expenses = dayExpenses,
            products = products,
            totalProdQty = totalProdQty,
            potentialRevenue = potRev,
            actualRevenue = actRev,
            totalExpense = expAmount,
            netProfit = profitAmount
          )
        }
      }

      1 -> {
        // Weekly Report Content
        item {
          val weekStart = DateUtils.getStartOfWeek(selectedDateMillis)
          val weekEnd = DateUtils.getEndOfWeek(selectedDateMillis)

          val weekProds = productions.filter { it.dateMillis in weekStart..weekEnd }
          val weekSales = sales.filter { it.dateMillis in weekStart..weekEnd }
          val weekExpenses = expenses.filter { it.dateMillis in weekStart..weekEnd }

          val totalProdQty = weekProds.sumOf { it.qty }
          val totalSoldQty = weekSales.sumOf { it.totalQty }
          val actRev = weekSales.sumOf { it.totalAmount }
          val expAmount = weekExpenses.sumOf { it.totalAmount }
          val profitAmount = actRev - expAmount

          WeeklyReportCard(
            totalProd = totalProdQty,
            totalSold = totalSoldQty,
            totalRevenue = actRev,
            totalExpense = expAmount,
            totalProfit = profitAmount
          )
        }
      }

      2 -> {
        // Monthly Report Content
        item {
          val monthStart = DateUtils.getStartOfMonth(selectedDateMillis)
          val monthEnd = DateUtils.getEndOfMonth(selectedDateMillis)

          val mProds = productions.filter { it.dateMillis in monthStart..monthEnd }
          val mSales = sales.filter { it.dateMillis in monthStart..monthEnd }
          val mExpenses = expenses.filter { it.dateMillis in monthStart..monthEnd }

          val totalProdQty = mProds.sumOf { it.qty }
          val totalSoldQty = mSales.sumOf { it.totalQty }
          val actRev = mSales.sumOf { it.totalAmount }
          val expAmount = mExpenses.sumOf { it.totalAmount }
          val totalCost = mSales.sumOf { it.totalCost }
          val profitAmount = actRev - expAmount

          MonthlyReportCard(
            totalProd = totalProdQty,
            totalSold = totalSoldQty,
            totalRevenue = actRev,
            totalExpense = expAmount,
            totalCost = totalCost,
            totalProfit = profitAmount,
            topSeller = products.maxByOrNull { p ->
              mSales.filter { it.itemsSummary.contains(p.name, ignoreCase = true) }.sumOf { it.totalQty }
            }?.name ?: "-"
          )
        }
      }
    }

    // 4. Export & Share Button Actions
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        Button(
          onClick = {
            coroutineScope.launch {
              val csv = viewModel.getCsvExport()
              val sendIntent = Intent().apply {
                action = Intent.ACTION_SEND
                putExtra(Intent.EXTRA_TEXT, csv)
                type = "text/plain"
              }
              val shareIntent = Intent.createChooser(sendIntent, "Bagikan Laporan Incu Emak")
              context.startActivity(shareIntent)
            }
          },
          modifier = Modifier.weight(1f),
          colors = ButtonDefaults.buttonColors(containerColor = PrimaryWarm),
          shape = RoundedCornerShape(12.dp)
        ) {
          Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
          Spacer(modifier = Modifier.width(6.dp))
          Text("Bagikan Laporan", fontSize = 12.sp)
        }
      }
    }
  }
}

@Composable
private fun DailyReportBreakdownCard(
  prods: List<com.example.data.local.entity.ProductionEntity>,
  sales: List<com.example.data.local.entity.SaleEntity>,
  expenses: List<com.example.data.local.entity.ExpenseEntity>,
  products: List<com.example.data.local.entity.ProductEntity>,
  totalProdQty: Int,
  potentialRevenue: Double,
  actualRevenue: Double,
  totalExpense: Double,
  netProfit: Double
) {
  Card(
    modifier = Modifier.fillMaxWidth(),
    shape = RoundedCornerShape(20.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
  ) {
    Column(modifier = Modifier.padding(16.dp)) {
      Text(
        text = "Ringkasan Harian",
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.Bold
      )
      Spacer(modifier = Modifier.height(12.dp))

      // Producing breakdown
      Text("Produksi Hari Ini", style = MaterialTheme.typography.labelMedium, color = PrimaryWarm, fontWeight = FontWeight.Bold)
      if (prods.isEmpty()) {
        Text("Tidak ada produksi pada tanggal ini", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
      } else {
        prods.forEach { p ->
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Text("• ${p.productName}: ${p.qty} pcs", fontSize = 13.sp)
            Text(FormatUtils.formatRupiah(p.potentialRevenue), fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
          }
        }
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Text("Total Produksi: $totalProdQty pcs", fontWeight = FontWeight.Bold, fontSize = 13.sp)
          Text("Potensi Omzet: ${FormatUtils.formatRupiah(potentialRevenue)}", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = PrimaryWarm)
        }
      }

      Spacer(modifier = Modifier.height(10.dp))
      HorizontalDivider()
      Spacer(modifier = Modifier.height(10.dp))

      // Sales breakdown
      Text("Penjualan Hari Ini", style = MaterialTheme.typography.labelMedium, color = RevenueBlue, fontWeight = FontWeight.Bold)
      if (sales.isEmpty()) {
        Text("Tidak ada penjualan pada tanggal ini", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
      } else {
        sales.forEach { s ->
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Text("• ${s.itemsSummary} (${s.customerName.ifBlank { "Pelanggan" }})", fontSize = 13.sp, modifier = Modifier.weight(1f))
            Text(FormatUtils.formatRupiah(s.totalAmount), fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
          }
        }
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Text("Omzet Aktual:", fontWeight = FontWeight.Bold, fontSize = 13.sp)
          Text(FormatUtils.formatRupiah(actualRevenue), fontWeight = FontWeight.ExtraBold, fontSize = 13.sp, color = ProfitGreen)
        }
      }

      Spacer(modifier = Modifier.height(10.dp))
      HorizontalDivider()
      Spacer(modifier = Modifier.height(10.dp))

      // Expenses breakdown
      Text("Pengeluaran Belanja", style = MaterialTheme.typography.labelMedium, color = ExpenseRed, fontWeight = FontWeight.Bold)
      if (expenses.isEmpty()) {
        Text("Tidak ada belanja pada tanggal ini", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
      } else {
        expenses.forEach { e ->
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Text("• ${e.itemName} (${e.qty} ${e.unit})", fontSize = 13.sp)
            Text(FormatUtils.formatRupiah(e.totalAmount), fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
          }
        }
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Text("Total Belanja:", fontWeight = FontWeight.Bold, fontSize = 13.sp)
          Text(FormatUtils.formatRupiah(totalExpense), fontWeight = FontWeight.ExtraBold, fontSize = 13.sp, color = ExpenseRed)
        }
      }

      Spacer(modifier = Modifier.height(12.dp))

      // Net result banner
      Surface(
        color = (if (netProfit >= 0) ProfitGreen else ExpenseRed).copy(alpha = 0.12f),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier.fillMaxWidth()
      ) {
        Row(
          modifier = Modifier.padding(14.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text("Keuntungan Bersih Hari Ini:", fontWeight = FontWeight.Bold)
          Text(
            text = FormatUtils.formatRupiah(netProfit),
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.ExtraBold,
            color = if (netProfit >= 0) ProfitGreen else ExpenseRed
          )
        }
      }

      Spacer(modifier = Modifier.height(12.dp))

      // Stock position
      Text("Stok Akhir Produk", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
      products.forEach { p ->
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Text(p.name, fontSize = 12.sp)
          Text("${p.currentStock} ${p.unit}", fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }
      }
    }
  }
}

@Composable
private fun WeeklyReportCard(
  totalProd: Int,
  totalSold: Int,
  totalRevenue: Double,
  totalExpense: Double,
  totalProfit: Double
) {
  Card(
    modifier = Modifier.fillMaxWidth(),
    shape = RoundedCornerShape(20.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
  ) {
    Column(modifier = Modifier.padding(16.dp)) {
      Text(
        text = "Laporan Mingguan",
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.Bold
      )
      Spacer(modifier = Modifier.height(14.dp))

      ReportRowItem("Total Produksi", "$totalProd pcs", PrimaryWarm)
      ReportRowItem("Total Terjual", "$totalSold pcs", RevenueBlue)
      ReportRowItem("Total Omzet", FormatUtils.formatRupiah(totalRevenue), ProfitGreen)
      ReportRowItem("Total Belanja", FormatUtils.formatRupiah(totalExpense), ExpenseRed)
      ReportRowItem("Total Keuntungan", FormatUtils.formatRupiah(totalProfit), ProfitGreen)
    }
  }
}

@Composable
private fun MonthlyReportCard(
  totalProd: Int,
  totalSold: Int,
  totalRevenue: Double,
  totalExpense: Double,
  totalCost: Double,
  totalProfit: Double,
  topSeller: String
) {
  Card(
    modifier = Modifier.fillMaxWidth(),
    shape = RoundedCornerShape(20.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
  ) {
    Column(modifier = Modifier.padding(16.dp)) {
      Text(
        text = "Laporan Bulanan",
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.Bold
      )
      Spacer(modifier = Modifier.height(14.dp))

      ReportRowItem("Total Produksi", "$totalProd pcs", PrimaryWarm)
      ReportRowItem("Total Penjualan", "$totalSold pcs", RevenueBlue)
      ReportRowItem("Total Omzet", FormatUtils.formatRupiah(totalRevenue), ProfitGreen)
      ReportRowItem("Total Belanja & Operasional", FormatUtils.formatRupiah(totalExpense), ExpenseRed)
      ReportRowItem("Total Modal HPP", FormatUtils.formatRupiah(totalCost), SecondaryGolden)
      ReportRowItem("Total Keuntungan", FormatUtils.formatRupiah(totalProfit), ProfitGreen)
      ReportRowItem("Produk Terlaris", topSeller, SecondaryGolden)
    }
  }
}

@Composable
private fun ReportRowItem(label: String, value: String, color: Color) {
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .padding(vertical = 6.dp),
    horizontalArrangement = Arrangement.SpaceBetween,
    verticalAlignment = Alignment.CenterVertically
  ) {
    Text(label, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
    Text(value, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold, color = color)
  }
}
