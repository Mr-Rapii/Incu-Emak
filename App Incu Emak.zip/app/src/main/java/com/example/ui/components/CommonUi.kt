package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import coil.compose.AsyncImage
import com.example.data.local.entity.ProductEntity
import com.example.ui.theme.ExpenseRed
import com.example.ui.theme.PrimaryWarm
import com.example.ui.theme.ProfitGreen
import com.example.ui.theme.RevenueBlue
import com.example.ui.theme.SecondaryGolden
import com.example.ui.theme.WarningAmber
import com.example.ui.util.FormatUtils

@Composable
fun StatCard(
  title: String,
  value: String,
  subtitle: String? = null,
  icon: ImageVector,
  accentColor: Color,
  modifier: Modifier = Modifier,
  badgeText: String? = null,
  isPositiveBadge: Boolean = true,
  isSolidVibrant: Boolean = false,
  onClick: (() -> Unit)? = null
) {
  val cardBackground = if (isSolidVibrant) accentColor else MaterialTheme.colorScheme.surface
  val titleColor = if (isSolidVibrant) Color.White.copy(alpha = 0.9f) else MaterialTheme.colorScheme.onSurfaceVariant
  val valueColor = if (isSolidVibrant) Color.White else MaterialTheme.colorScheme.onSurface
  val subtitleColor = if (isSolidVibrant) Color.White.copy(alpha = 0.8f) else MaterialTheme.colorScheme.onSurfaceVariant

  Card(
    modifier = modifier
      .clip(RoundedCornerShape(24.dp))
      .then(if (onClick != null) Modifier.clickable { onClick() } else Modifier),
    shape = RoundedCornerShape(24.dp),
    colors = CardDefaults.cardColors(containerColor = cardBackground),
    elevation = CardDefaults.cardElevation(defaultElevation = if (isSolidVibrant) 4.dp else 2.dp)
  ) {
    Column(modifier = Modifier.padding(16.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Box(
          modifier = Modifier
            .size(40.dp)
            .background(
              if (isSolidVibrant) Color.White.copy(alpha = 0.22f) else accentColor.copy(alpha = 0.12f),
              CircleShape
            ),
          contentAlignment = Alignment.Center
        ) {
          Icon(
            imageVector = icon,
            contentDescription = title,
            tint = if (isSolidVibrant) Color.White else accentColor,
            modifier = Modifier.size(20.dp)
          )
        }

        if (!badgeText.isNullOrBlank()) {
          Surface(
            color = if (isSolidVibrant) Color.White.copy(alpha = 0.22f)
            else if (isPositiveBadge) ProfitGreen.copy(alpha = 0.12f)
            else ExpenseRed.copy(alpha = 0.12f),
            shape = RoundedCornerShape(12.dp)
          ) {
            Row(
              modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Icon(
                imageVector = if (isPositiveBadge) Icons.Default.ArrowUpward else Icons.Default.ArrowDownward,
                contentDescription = null,
                tint = if (isSolidVibrant) Color.White else if (isPositiveBadge) ProfitGreen else ExpenseRed,
                modifier = Modifier.size(12.dp)
              )
              Spacer(modifier = Modifier.width(2.dp))
              Text(
                text = badgeText,
                style = MaterialTheme.typography.labelSmall,
                color = if (isSolidVibrant) Color.White else if (isPositiveBadge) ProfitGreen else ExpenseRed,
                fontWeight = FontWeight.Bold
              )
            }
          }
        }
      }

      Spacer(modifier = Modifier.height(14.dp))

      Text(
        text = title,
        style = MaterialTheme.typography.bodySmall,
        color = titleColor,
        fontWeight = FontWeight.SemiBold,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis
      )

      Spacer(modifier = Modifier.height(4.dp))

      Text(
        text = value,
        style = MaterialTheme.typography.titleLarge,
        fontWeight = FontWeight.ExtraBold,
        color = valueColor,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis
      )

      if (!subtitle.isNullOrBlank()) {
        Spacer(modifier = Modifier.height(4.dp))
        Text(
          text = subtitle,
          style = MaterialTheme.typography.labelSmall,
          color = subtitleColor,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis
        )
      }
    }
  }
}

@Composable
fun LowStockAlertBanner(
  lowStockProducts: List<ProductEntity>,
  onAddProductionClick: (ProductEntity) -> Unit,
  modifier: Modifier = Modifier
) {
  if (lowStockProducts.isEmpty()) return

  Card(
    modifier = modifier.fillMaxWidth(),
    shape = RoundedCornerShape(20.dp),
    colors = CardDefaults.cardColors(containerColor = Color(0xFFFEF2F2)),
    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
  ) {
    Row(
      modifier = Modifier.padding(14.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      Box(
        modifier = Modifier
          .size(40.dp)
          .background(Color(0xFFFEE2E2), RoundedCornerShape(12.dp)),
        contentAlignment = Alignment.Center
      ) {
        Icon(
          imageVector = Icons.Default.Warning,
          contentDescription = "Peringatan Stok",
          tint = Color(0xFFDC2626),
          modifier = Modifier.size(22.dp)
        )
      }

      Spacer(modifier = Modifier.width(12.dp))

      Column(modifier = Modifier.weight(1f)) {
        Text(
          text = "Stok Makaroni / Produk Menipis!",
          style = MaterialTheme.typography.titleSmall,
          fontWeight = FontWeight.Bold,
          color = Color(0xFF991B1B)
        )
        Text(
          text = "${lowStockProducts.size} produk di bawah batas aman (${lowStockProducts.joinToString { "${it.name}: ${it.currentStock}" }}). Segera produksi baru!",
          style = MaterialTheme.typography.bodySmall,
          color = Color(0xFFDC2626)
        )
      }

      Spacer(modifier = Modifier.width(8.dp))

      Button(
        onClick = { onAddProductionClick(lowStockProducts.first()) },
        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEF4444)),
        shape = RoundedCornerShape(12.dp),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 12.dp, vertical = 8.dp)
      ) {
        Text("PRODUKSI", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.White)
      }
    }
  }
}

@Composable
fun TargetProgressCard(
  title: String,
  current: Double,
  target: Double,
  modifier: Modifier = Modifier
) {
  val progress = if (target > 0) (current / target).coerceIn(0.0, 1.0).toFloat() else 0f
  val percent = (progress * 100).toInt()

  Card(
    modifier = modifier.fillMaxWidth(),
    shape = RoundedCornerShape(22.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
  ) {
    Column(modifier = Modifier.padding(18.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Box(
            modifier = Modifier
              .size(28.dp)
              .background(PrimaryWarm.copy(alpha = 0.12f), CircleShape),
            contentAlignment = Alignment.Center
          ) {
            Icon(
              imageVector = Icons.Default.CheckCircle,
              contentDescription = null,
              tint = PrimaryWarm,
              modifier = Modifier.size(16.dp)
            )
          }
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = title,
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.Bold
          )
        }
        Text(
          text = "$percent%",
          style = MaterialTheme.typography.titleMedium,
          fontWeight = FontWeight.ExtraBold,
          color = PrimaryWarm
        )
      }

      Spacer(modifier = Modifier.height(12.dp))

      LinearProgressIndicator(
        progress = { progress },
        modifier = Modifier
          .fillMaxWidth()
          .height(10.dp)
          .clip(RoundedCornerShape(6.dp)),
        color = PrimaryWarm,
        trackColor = Color(0xFFF1F5F9)
      )

      Spacer(modifier = Modifier.height(10.dp))

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        Text(
          text = FormatUtils.formatRupiah(current),
          style = MaterialTheme.typography.bodySmall,
          fontWeight = FontWeight.Bold,
          color = MaterialTheme.colorScheme.onSurface
        )
        Text(
          text = "Target: ${FormatUtils.formatRupiah(target)}",
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
      }
    }
  }
}

@Composable
fun ConfirmationDialog(
  title: String,
  message: String,
  confirmButtonText: String = "Hapus",
  onConfirm: () -> Unit,
  onDismiss: () -> Unit
) {
  AlertDialog(
    onDismissRequest = onDismiss,
    title = { Text(title, fontWeight = FontWeight.Bold) },
    text = { Text(message) },
    confirmButton = {
      Button(
        onClick = onConfirm,
        colors = ButtonDefaults.buttonColors(containerColor = ExpenseRed)
      ) {
        Text(confirmButtonText, color = Color.White)
      }
    },
    dismissButton = {
      OutlinedButton(onClick = onDismiss) {
        Text("Batal")
      }
    }
  )
}

@Composable
fun ImageViewerDialog(
  photoUri: String,
  title: String,
  subtitle: String,
  onDismiss: () -> Unit
) {
  Dialog(onDismissRequest = onDismiss) {
    Card(
      shape = RoundedCornerShape(20.dp),
      colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
      modifier = Modifier.fillMaxWidth()
    ) {
      Column(modifier = Modifier.padding(16.dp)) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Column(modifier = Modifier.weight(1f)) {
            Text(
              text = title,
              style = MaterialTheme.typography.titleMedium,
              fontWeight = FontWeight.Bold
            )
            Text(
              text = subtitle,
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }
          IconButton(onClick = onDismiss) {
            Icon(Icons.Default.Close, contentDescription = "Tutup")
          }
        }

        Spacer(modifier = Modifier.height(12.dp))

        Box(
          modifier = Modifier
            .fillMaxWidth()
            .height(280.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant),
          contentAlignment = Alignment.Center
        ) {
          if (photoUri.startsWith("http") || photoUri.startsWith("content") || photoUri.startsWith("file")) {
            AsyncImage(
              model = photoUri,
              contentDescription = title,
              modifier = Modifier.fillMaxWidth(),
              contentScale = ContentScale.Crop
            )
          } else {
            // Simulated decorative snack visual placeholder with culinary badge
            Box(
              modifier = Modifier
                .fillMaxSize()
                .background(
                  Brush.linearGradient(
                    listOf(PrimaryWarm.copy(alpha = 0.2f), SecondaryGolden.copy(alpha = 0.3f))
                  )
                ),
              contentAlignment = Alignment.Center
            ) {
              Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(
                  imageVector = Icons.Default.Image,
                  contentDescription = null,
                  modifier = Modifier.size(54.dp),
                  tint = PrimaryWarm
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                  text = "Dokumentasi Foto Incu Emak",
                  style = MaterialTheme.typography.bodyMedium,
                  fontWeight = FontWeight.SemiBold,
                  color = PrimaryWarm
                )
              }
            }
          }
        }
      }
    }
  }
}

// Preset photo options selector helper for easy photo assignment
@Composable
fun PhotoAttachmentSelector(
  selectedPhotoUri: String?,
  onPhotoSelected: (String?) -> Unit,
  label: String = "Foto Dokumentasi (Opsional)"
) {
  var showPicker by remember { mutableStateOf(false) }

  // Sample culinary stock URLs for delicious presentation
  val presets = listOf(
    "https://images.unsplash.com/photo-1599488615731-7e5c2823ff28?w=400&q=80" to "Makaroni Renyah",
    "https://images.unsplash.com/photo-1541592106381-b31e9677c0e5?w=400&q=80" to "Basreng Pedas",
    "https://images.unsplash.com/photo-1568729243763-7eb92b8d00ec?w=400&q=80" to "Kerupuk Seblak",
    "https://images.unsplash.com/photo-1554415707-9e49fe74853d?w=400&q=80" to "Nota / Belanja",
    "https://images.unsplash.com/photo-1556742049-0a67e557b669?w=400&q=80" to "Bukti Transaksi"
  )

  Column(modifier = Modifier.fillMaxWidth()) {
    Text(
      text = label,
      style = MaterialTheme.typography.labelMedium,
      color = MaterialTheme.colorScheme.onSurfaceVariant
    )
    Spacer(modifier = Modifier.height(6.dp))

    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(8.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      if (selectedPhotoUri != null) {
        Box(
          modifier = Modifier
            .size(54.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant),
          contentAlignment = Alignment.Center
        ) {
          AsyncImage(
            model = selectedPhotoUri,
            contentDescription = "Selected Photo",
            modifier = Modifier.size(54.dp),
            contentScale = ContentScale.Crop
          )
        }
        TextButton(
          onClick = { onPhotoSelected(null) },
          colors = ButtonDefaults.textButtonColors(contentColor = ExpenseRed)
        ) {
          Text("Hapus Foto")
        }
      }

      OutlinedButton(
        onClick = { showPicker = true },
        shape = RoundedCornerShape(12.dp)
      ) {
        Icon(Icons.Default.Image, contentDescription = null, modifier = Modifier.size(16.dp))
        Spacer(modifier = Modifier.width(6.dp))
        Text(if (selectedPhotoUri == null) "Pilih / Tambah Foto" else "Ganti Foto")
      }
    }

    if (showPicker) {
      Dialog(onDismissRequest = { showPicker = false }) {
        Card(
          shape = RoundedCornerShape(20.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
          modifier = Modifier.padding(16.dp)
        ) {
          Column(modifier = Modifier.padding(16.dp)) {
            Text(
              text = "Pilih Contoh Foto Dokumentasi",
              style = MaterialTheme.typography.titleMedium,
              fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(12.dp))

            presets.forEach { (url, name) ->
              Row(
                modifier = Modifier
                  .fillMaxWidth()
                  .clip(RoundedCornerShape(10.dp))
                  .clickable {
                    onPhotoSelected(url)
                    showPicker = false
                  }
                  .padding(8.dp),
                verticalAlignment = Alignment.CenterVertically
              ) {
                Box(
                  modifier = Modifier
                    .size(44.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant)
                ) {
                  AsyncImage(
                    model = url,
                    contentDescription = name,
                    modifier = Modifier.size(44.dp),
                    contentScale = ContentScale.Crop
                  )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Text(
                  text = name,
                  style = MaterialTheme.typography.bodyMedium,
                  fontWeight = FontWeight.Medium
                )
              }
            }

            Spacer(modifier = Modifier.height(8.dp))
            TextButton(
              onClick = { showPicker = false },
              modifier = Modifier.align(Alignment.End)
            ) {
              Text("Tutup")
            }
          }
        }
      }
    }
  }
}
