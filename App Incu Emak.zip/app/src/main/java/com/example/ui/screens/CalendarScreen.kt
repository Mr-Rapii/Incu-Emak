package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.theme.ExpenseRed
import com.example.ui.theme.PrimaryWarm
import com.example.ui.theme.ProfitGreen
import com.example.ui.theme.RevenueBlue
import com.example.ui.util.DateUtils
import com.example.ui.util.FormatUtils
import com.example.ui.viewmodel.MainViewModel
import java.util.Calendar

@Composable
fun CalendarScreen(
  viewModel: MainViewModel,
  modifier: Modifier = Modifier
) {
  val productions by viewModel.productions.collectAsStateWithLifecycle()
  val sales by viewModel.sales.collectAsStateWithLifecycle()
  val expenses by viewModel.expenses.collectAsStateWithLifecycle()

  var selectedDateMillis by remember { mutableStateOf(System.currentTimeMillis()) }
  var displayedCalendar by remember {
    mutableStateOf(Calendar.getInstance().apply { timeInMillis = selectedDateMillis })
  }

  val displayedYear = displayedCalendar.get(Calendar.YEAR)
  val displayedMonth = displayedCalendar.get(Calendar.MONTH)

  // Calculate calendar grid
  val cal = Calendar.getInstance().apply {
    set(Calendar.YEAR, displayedYear)
    set(Calendar.MONTH, displayedMonth)
    set(Calendar.DAY_OF_MONTH, 1)
  }

  val firstDayOfWeek = cal.get(Calendar.DAY_OF_WEEK) // 1=Sunday, 2=Monday...
  val daysInMonth = cal.getActualMaximum(Calendar.DAY_OF_MONTH)
  // We align start to Monday (Indonesian standard)
  val offsetDays = (firstDayOfWeek - Calendar.MONDAY + 7) % 7

  val startOfSelectedDay = DateUtils.getStartOfDay(selectedDateMillis)
  val endOfSelectedDay = DateUtils.getEndOfDay(selectedDateMillis)

  val selectedDayProds = productions.filter { it.dateMillis in startOfSelectedDay..endOfSelectedDay }
  val selectedDaySales = sales.filter { it.dateMillis in startOfSelectedDay..endOfSelectedDay }
  val selectedDayExpenses = expenses.filter { it.dateMillis in startOfSelectedDay..endOfSelectedDay }

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .background(MaterialTheme.colorScheme.background)
      .testTag("calendar_screen"),
    contentPadding = PaddingValues(16.dp),
    verticalArrangement = Arrangement.spacedBy(14.dp)
  ) {
    // 1. Month Header Navigation
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
      ) {
        Column(modifier = Modifier.padding(14.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            IconButton(
              onClick = {
                displayedCalendar = (displayedCalendar.clone() as Calendar).apply {
                  add(Calendar.MONTH, -1)
                }
              }
            ) {
              Icon(Icons.Default.ChevronLeft, contentDescription = "Bulan Lalu")
            }

            Text(
              text = "${DateUtils.monthNames[displayedMonth]} $displayedYear",
              style = MaterialTheme.typography.titleMedium,
              fontWeight = FontWeight.Bold
            )

            IconButton(
              onClick = {
                displayedCalendar = (displayedCalendar.clone() as Calendar).apply {
                  add(Calendar.MONTH, 1)
                }
              }
            ) {
              Icon(Icons.Default.ChevronRight, contentDescription = "Bulan Depan")
            }
          }

          Spacer(modifier = Modifier.height(10.dp))

          // Day Names Row (Sen, Sel, Rab, Kam, Jum, Sab, Min)
          val dayHeaders = listOf("Sen", "Sel", "Rab", "Kam", "Jum", "Sab", "Min")
          Row(modifier = Modifier.fillMaxWidth()) {
            dayHeaders.forEach { name ->
              Text(
                text = name,
                modifier = Modifier.weight(1f),
                textAlign = TextAlign.Center,
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }
          }

          Spacer(modifier = Modifier.height(8.dp))

          // 2. Calendar Grid Dates
          val totalCells = offsetDays + daysInMonth
          val totalRows = (totalCells + 6) / 7

          for (row in 0 until totalRows) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceEvenly
            ) {
              for (col in 0 until 7) {
                val cellIndex = row * 7 + col
                val dayNum = cellIndex - offsetDays + 1

                if (dayNum in 1..daysInMonth) {
                  val cellCal = Calendar.getInstance().apply {
                    set(Calendar.YEAR, displayedYear)
                    set(Calendar.MONTH, displayedMonth)
                    set(Calendar.DAY_OF_MONTH, dayNum)
                  }
                  val cellMillis = cellCal.timeInMillis
                  val cStart = DateUtils.getStartOfDay(cellMillis)
                  val cEnd = DateUtils.getEndOfDay(cellMillis)

                  val hasProd = productions.any { it.dateMillis in cStart..cEnd }
                  val hasSale = sales.any { it.dateMillis in cStart..cEnd }
                  val hasExpense = expenses.any { it.dateMillis in cStart..cEnd }

                  val isSelected = DateUtils.getFormattedDate(cellMillis) == DateUtils.getFormattedDate(selectedDateMillis)

                  Box(
                    modifier = Modifier
                      .weight(1f)
                      .aspectRatio(1f)
                      .padding(2.dp)
                      .clip(RoundedCornerShape(10.dp))
                      .background(
                        if (isSelected) PrimaryWarm
                        else Color.Transparent
                      )
                      .clickable { selectedDateMillis = cellMillis },
                    contentAlignment = Alignment.Center
                  ) {
                    Column(
                      horizontalAlignment = Alignment.CenterHorizontally,
                      verticalArrangement = Arrangement.Center
                    ) {
                      Text(
                        text = "$dayNum",
                        fontSize = 13.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                        color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface
                      )

                      // Dots for activities
                      Row(
                        horizontalArrangement = Arrangement.spacedBy(2.dp),
                        modifier = Modifier.padding(top = 2.dp)
                      ) {
                        if (hasProd) {
                          Box(modifier = Modifier.size(4.dp).background(if (isSelected) Color.White else PrimaryWarm, CircleShape))
                        }
                        if (hasSale) {
                          Box(modifier = Modifier.size(4.dp).background(if (isSelected) Color.White else ProfitGreen, CircleShape))
                        }
                        if (hasExpense) {
                          Box(modifier = Modifier.size(4.dp).background(if (isSelected) Color.White else ExpenseRed, CircleShape))
                        }
                      }
                    }
                  }
                } else {
                  Spacer(modifier = Modifier.weight(1f).aspectRatio(1f))
                }
              }
            }
          }

          Spacer(modifier = Modifier.height(8.dp))

          // Legend
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Box(modifier = Modifier.size(8.dp).background(PrimaryWarm, CircleShape))
            Spacer(modifier = Modifier.width(4.dp))
            Text("Produksi", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(modifier = Modifier.width(12.dp))

            Box(modifier = Modifier.size(8.dp).background(ProfitGreen, CircleShape))
            Spacer(modifier = Modifier.width(4.dp))
            Text("Penjualan", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(modifier = Modifier.width(12.dp))

            Box(modifier = Modifier.size(8.dp).background(ExpenseRed, CircleShape))
            Spacer(modifier = Modifier.width(4.dp))
            Text("Belanja", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
          }
        }
      }
    }

    // 3. Selected Date Detail Header
    item {
      Text(
        text = "Aktivitas: ${DateUtils.getFullFormattedDateWithDay(selectedDateMillis)}",
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.Bold
      )
    }

    // 4. Activity Lists for Selected Day
    if (selectedDayProds.isEmpty() && selectedDaySales.isEmpty() && selectedDayExpenses.isEmpty()) {
      item {
        Card(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(14.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
          Box(modifier = Modifier.fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) {
            Text("Tidak ada aktivitas bisnis pada tanggal ini", color = MaterialTheme.colorScheme.onSurfaceVariant)
          }
        }
      }
    } else {
      // Produksi items
      items(selectedDayProds) { p ->
        DayActivityCard(
          icon = Icons.Default.Inventory2,
          color = PrimaryWarm,
          title = "Produksi ${p.productName} (${p.qty} pcs)",
          subtitle = "Potensi: ${FormatUtils.formatRupiah(p.potentialRevenue)} • ${p.formattedTime}",
          notes = p.notes
        )
      }

      // Penjualan items
      items(selectedDaySales) { s ->
        DayActivityCard(
          icon = Icons.Default.ShoppingCart,
          color = ProfitGreen,
          title = "Penjualan: ${s.itemsSummary}",
          subtitle = "${FormatUtils.formatRupiah(s.totalAmount)} • ${s.paymentMethod} • ${s.formattedTime}",
          notes = s.notes
        )
      }

      // Belanja items
      items(selectedDayExpenses) { e ->
        DayActivityCard(
          icon = Icons.Default.ReceiptLong,
          color = ExpenseRed,
          title = "Belanja: ${e.itemName}",
          subtitle = "${FormatUtils.formatRupiah(e.totalAmount)} • ${e.placeOrStore} • ${e.formattedTime}",
          notes = e.notes
        )
      }
    }
  }
}

@Composable
private fun DayActivityCard(
  icon: androidx.compose.ui.graphics.vector.ImageVector,
  color: Color,
  title: String,
  subtitle: String,
  notes: String
) {
  Card(
    modifier = Modifier.fillMaxWidth(),
    shape = RoundedCornerShape(14.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
  ) {
    Row(
      modifier = Modifier.padding(12.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      Box(
        modifier = Modifier
          .size(36.dp)
          .background(color.copy(alpha = 0.12f), CircleShape),
        contentAlignment = Alignment.Center
      ) {
        Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(18.dp))
      }

      Spacer(modifier = Modifier.width(12.dp))

      Column(modifier = Modifier.weight(1f)) {
        Text(title, fontWeight = FontWeight.Bold, fontSize = 13.sp)
        Text(subtitle, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        if (notes.isNotBlank()) {
          Text("Catatan: $notes", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
      }
    }
  }
}
