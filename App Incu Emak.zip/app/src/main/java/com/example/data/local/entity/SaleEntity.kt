package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "sales")
data class SaleEntity(
  @PrimaryKey(autoGenerate = true)
  val id: Long = 0,
  val dateMillis: Long,
  val dayName: String,
  val formattedDate: String,
  val formattedTime: String,
  val customerName: String = "",
  val paymentMethod: String = "Tunai", // Tunai, QRIS, Transfer, Utang/Kasbon
  val totalAmount: Double,
  val totalCost: Double = 0.0,
  val netProfit: Double = 0.0,
  val notes: String = "",
  val photoUri: String? = null,
  val itemsSummary: String = "",
  val totalQty: Int = 0,
  val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "sale_items")
data class SaleItemEntity(
  @PrimaryKey(autoGenerate = true)
  val id: Long = 0,
  val saleId: Long,
  val productId: Long,
  val productName: String,
  val qty: Int,
  val pricePerUnit: Double,
  val costPerUnit: Double,
  val subtotal: Double
)
