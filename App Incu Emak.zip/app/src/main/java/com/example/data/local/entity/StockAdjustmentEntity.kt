package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "stock_adjustments")
data class StockAdjustmentEntity(
  @PrimaryKey(autoGenerate = true)
  val id: Long = 0,
  val productId: Long,
  val productName: String,
  val dateMillis: Long,
  val dayName: String,
  val formattedDate: String,
  val adjustmentType: String, // "PRODUKSI", "PENJUALAN", "RUSAK", "KOREKSI"
  val qtyChange: Int, // e.g. +30 or -5
  val reason: String = "",
  val notes: String = "",
  val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "business_targets")
data class BusinessTargetEntity(
  @PrimaryKey
  val id: Int = 1,
  val dailyTarget: Double = 100000.0,
  val weeklyTarget: Double = 700000.0,
  val monthlyTarget: Double = 3000000.0,
  val updatedAt: Long = System.currentTimeMillis()
)
