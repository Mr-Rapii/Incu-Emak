package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Vibrant Palette - High-energy Culinary Brand Palette
val PrimaryVibrantOrange = Color(0xFFF97316) // Vibrant Orange 500
val PrimaryDarkOrange = Color(0xFFEA580C)    // Vibrant Orange 600
val OnPrimaryLight = Color(0xFFFFFFFF)
val PrimaryContainerVibrant = Color(0xFFFFEDD5) // Orange 100
val OnPrimaryContainerVibrant = Color(0xFF9A3412) // Orange 800

val SecondaryAmber = Color(0xFFF59E0B) // Amber 500
val OnSecondaryLight = Color(0xFFFFFFFF)
val SecondaryContainerAmber = Color(0xFFFEF3C7) // Amber 100
val OnSecondaryContainerAmber = Color(0xFF78350F) // Amber 900

val TertiaryEmerald = Color(0xFF10B981) // Emerald 500
val OnTertiaryLight = Color(0xFFFFFFFF)
val TertiaryContainerEmerald = Color(0xFFD1FAE5) // Emerald 100
val OnTertiaryContainerEmerald = Color(0xFF065F46) // Emerald 800

// Background & Surface
val BackgroundVibrant = Color(0xFFFDFCFB) // Off-white warm canvas
val SurfaceVibrant = Color(0xFFFFFFFF)    // Pure White card
val SurfaceVariantVibrant = Color(0xFFF1F5F9) // Slate 100
val OnSurfaceVibrant = Color(0xFF0F172A)  // Slate 900
val OnSurfaceVariantVibrant = Color(0xFF64748B) // Slate 500
val OutlineVibrant = Color(0xFFE2E8F0)    // Slate 200

// Legacy / alias references for smooth theme mapping
val PrimaryWarm = PrimaryVibrantOrange
val OnPrimaryWarm = OnPrimaryLight
val PrimaryContainerWarm = PrimaryContainerVibrant
val OnPrimaryContainerWarm = OnPrimaryContainerVibrant

val SecondaryGolden = SecondaryAmber
val OnSecondaryGolden = OnSecondaryLight
val SecondaryContainerGolden = SecondaryContainerAmber
val OnSecondaryContainerGolden = OnSecondaryContainerAmber

val TertiaryGreen = TertiaryEmerald
val OnTertiaryGreen = OnTertiaryLight
val TertiaryContainerGreen = TertiaryContainerEmerald
val OnTertiaryContainerGreen = OnTertiaryContainerEmerald

val BackgroundLight = BackgroundVibrant
val SurfaceLight = SurfaceVibrant
val SurfaceVariantLight = SurfaceVariantVibrant
val OnSurfaceLight = OnSurfaceVibrant
val OnSurfaceVariantLight = OnSurfaceVariantVibrant
val OutlineLight = OutlineVibrant

// Dark Theme Variants
val PrimaryDark = Color(0xFFFB923C)
val OnPrimaryDark = Color(0xFF431407)
val PrimaryContainerDark = Color(0xFF7C2D12)
val OnPrimaryContainerDark = Color(0xFFFFEDD5)

val SecondaryDark = Color(0xFFFBBF24)
val OnSecondaryDark = Color(0xFF451A03)
val SecondaryContainerDark = Color(0xFF78350F)
val OnSecondaryContainerDark = Color(0xFFFEF3C7)

val TertiaryDark = Color(0xFF34D399)
val OnTertiaryDark = Color(0xFF064E3B)
val TertiaryContainerDark = Color(0xFF065F46)
val OnTertiaryContainerDark = Color(0xFFD1FAE5)

val BackgroundDark = Color(0xFF0F172A)
val SurfaceDark = Color(0xFF1E293B)
val SurfaceVariantDark = Color(0xFF334155)
val OnSurfaceDark = Color(0xFFF8FAFC)
val OnSurfaceVariantDark = Color(0xFF94A3B8)
val OutlineDark = Color(0xFF475569)

// Custom vibrant semantic status colors
val ProfitGreen = Color(0xFF10B981)   // Vibrant Emerald 500
val ExpenseRed = Color(0xFFEF4444)    // Vibrant Red 500
val RevenueBlue = Color(0xFF3B82F6)   // Vibrant Blue 500
val WarningAmber = Color(0xFFF59E0B)  // Vibrant Amber 500
val StockPurple = Color(0xFF8B5CF6)   // Vibrant Violet 500

