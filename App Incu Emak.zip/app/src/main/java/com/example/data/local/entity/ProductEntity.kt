package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "products")
data class ProductEntity(
  @PrimaryKey(autoGenerate = true)
  val id: Long = 0,
  val name: String,
  val category: String = "Makanan Ringan",
  val defaultPrice: Double = 5000.0,
  val defaultCost: Double = 2500.0, // Modal / HPP per pcs
  val currentStock: Int = 0,
  val minStockAlert: Int = 10,
  val unit: String = "pcs",
  val photoUri: String? = null,
  val description: String = "",
  val createdAt: Long = System.currentTimeMillis()
)
