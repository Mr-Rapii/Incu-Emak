package com.example.data.repository

import com.example.data.local.AppDatabase
import com.example.data.local.entity.BusinessTargetEntity
import com.example.data.local.entity.ExpenseEntity
import com.example.data.local.entity.ProductEntity
import com.example.data.local.entity.ProductionEntity
import com.example.data.local.entity.SaleEntity
import com.example.data.local.entity.SaleItemEntity
import com.example.data.local.entity.StockAdjustmentEntity
import com.example.ui.util.DateUtils
import com.example.ui.util.FormatUtils
import kotlinx.coroutines.flow.Flow
import org.json.JSONArray
import org.json.JSONObject

class BusinessRepository(private val database: AppDatabase) {
  private val productDao = database.productDao()
  private val productionDao = database.productionDao()
  private val saleDao = database.saleDao()
  private val expenseDao = database.expenseDao()
  private val stockAdjustmentDao = database.stockAdjustmentDao()
  private val targetDao = database.businessTargetDao()

  // Products
  val allProducts: Flow<List<ProductEntity>> = productDao.getAllProducts()
  suspend fun insertProduct(product: ProductEntity): Long = productDao.insertProduct(product)
  suspend fun updateProduct(product: ProductEntity) = productDao.updateProduct(product)
  suspend fun deleteProduct(product: ProductEntity) = productDao.deleteProduct(product)
  suspend fun getProductById(id: Long): ProductEntity? = productDao.getProductById(id)

  // Productions
  val allProductions: Flow<List<ProductionEntity>> = productionDao.getAllProductions()
  fun getProductionsByDateRange(start: Long, end: Long): Flow<List<ProductionEntity>> =
    productionDao.getProductionsByDateRange(start, end)

  suspend fun addProduction(production: ProductionEntity): Long {
    val id = productionDao.insertProduction(production)
    // Automatically increment product stock
    productDao.updateStock(production.productId, production.qty)
    // Log stock adjustment
    stockAdjustmentDao.insert(
      StockAdjustmentEntity(
        productId = production.productId,
        productName = production.productName,
        dateMillis = production.dateMillis,
        dayName = production.dayName,
        formattedDate = production.formattedDate,
        adjustmentType = "PRODUKSI",
        qtyChange = production.qty,
        reason = "Produksi masuk: ${production.notes.ifBlank { "Batch produksi" }}"
      )
    )
    return id
  }

  suspend fun deleteProduction(production: ProductionEntity) {
    productionDao.deleteProduction(production)
    // Revert stock
    productDao.updateStock(production.productId, -production.qty)
    stockAdjustmentDao.insert(
      StockAdjustmentEntity(
        productId = production.productId,
        productName = production.productName,
        dateMillis = System.currentTimeMillis(),
        dayName = DateUtils.getDayName(System.currentTimeMillis()),
        formattedDate = DateUtils.getFormattedDate(System.currentTimeMillis()),
        adjustmentType = "KOREKSI",
        qtyChange = -production.qty,
        reason = "Hapus catatan produksi"
      )
    )
  }

  // Sales
  val allSales: Flow<List<SaleEntity>> = saleDao.getAllSales()
  val allSaleItems: Flow<List<SaleItemEntity>> = saleDao.getAllSaleItems()

  fun getSalesByDateRange(start: Long, end: Long): Flow<List<SaleEntity>> =
    saleDao.getSalesByDateRange(start, end)

  suspend fun getSaleItems(saleId: Long): List<SaleItemEntity> = saleDao.getSaleItems(saleId)

  suspend fun addSale(sale: SaleEntity, items: List<SaleItemEntity>): Long {
    val saleId = saleDao.insertSale(sale)
    val itemsWithSaleId = items.map { it.copy(saleId = saleId) }
    saleDao.insertSaleItems(itemsWithSaleId)

    // Deduct stock for each sold item
    for (item in itemsWithSaleId) {
      productDao.updateStock(item.productId, -item.qty)
      stockAdjustmentDao.insert(
        StockAdjustmentEntity(
          productId = item.productId,
          productName = item.productName,
          dateMillis = sale.dateMillis,
          dayName = sale.dayName,
          formattedDate = sale.formattedDate,
          adjustmentType = "PENJUALAN",
          qtyChange = -item.qty,
          reason = "Penjualan #${saleId} ke ${sale.customerName.ifBlank { "Pelanggan" }}"
        )
      )
    }
    return saleId
  }

  suspend fun deleteSale(sale: SaleEntity) {
    val items = saleDao.getSaleItems(sale.id)
    // Restore stock
    for (item in items) {
      productDao.updateStock(item.productId, item.qty)
      stockAdjustmentDao.insert(
        StockAdjustmentEntity(
          productId = item.productId,
          productName = item.productName,
          dateMillis = System.currentTimeMillis(),
          dayName = DateUtils.getDayName(System.currentTimeMillis()),
          formattedDate = DateUtils.getFormattedDate(System.currentTimeMillis()),
          adjustmentType = "KOREKSI",
          qtyChange = item.qty,
          reason = "Pembatalan penjualan #${sale.id}"
        )
      )
    }
    saleDao.deleteSaleWithItems(sale)
  }

  // Expenses
  val allExpenses: Flow<List<ExpenseEntity>> = expenseDao.getAllExpenses()
  fun getExpensesByDateRange(start: Long, end: Long): Flow<List<ExpenseEntity>> =
    expenseDao.getExpensesByDateRange(start, end)

  suspend fun addExpense(expense: ExpenseEntity): Long = expenseDao.insertExpense(expense)
  suspend fun updateExpense(expense: ExpenseEntity) = expenseDao.updateExpense(expense)
  suspend fun deleteExpense(expense: ExpenseEntity) = expenseDao.deleteExpense(expense)

  // Stock Adjustments
  val allStockAdjustments: Flow<List<StockAdjustmentEntity>> = stockAdjustmentDao.getAllAdjustments()

  suspend fun recordManualAdjustment(
    productId: Long,
    productName: String,
    qtyDelta: Int,
    adjustmentType: String,
    reason: String
  ) {
    productDao.updateStock(productId, qtyDelta)
    val now = System.currentTimeMillis()
    stockAdjustmentDao.insert(
      StockAdjustmentEntity(
        productId = productId,
        productName = productName,
        dateMillis = now,
        dayName = DateUtils.getDayName(now),
        formattedDate = DateUtils.getFormattedDate(now),
        adjustmentType = adjustmentType,
        qtyChange = qtyDelta,
        reason = reason
      )
    )
  }

  // Targets
  val businessTarget: Flow<BusinessTargetEntity?> = targetDao.getTarget()
  suspend fun saveTarget(target: BusinessTargetEntity) = targetDao.saveTarget(target)

  // Reset database with fresh sample data
  suspend fun resetToSampleData() {
    productDao.deleteAll()
    productionDao.deleteAll()
    saleDao.deleteAll()
    saleDao.deleteAllItems()
    expenseDao.deleteAll()
    stockAdjustmentDao.deleteAll()
    AppDatabase.populateInitialData(database)
  }

  // Export full CSV report
  suspend fun generateCsvExport(
    productions: List<ProductionEntity>,
    sales: List<SaleEntity>,
    expenses: List<ExpenseEntity>,
    products: List<ProductEntity>
  ): String {
    val sb = StringBuilder()
    sb.append("=== LAPORAN USAHA INCU EMAK ===\n\n")

    sb.append("--- DATA PRODUK & STOK ---\n")
    sb.append("ID,Nama Produk,Kategori,Harga Jual,Modal/HPP,Stok Saat Ini,Status Stok\n")
    for (p in products) {
      val status = if (p.currentStock <= p.minStockAlert) "Hampir Habis" else "Aman"
      sb.append("${p.id},\"${p.name}\",\"${p.category}\",${p.defaultPrice},${p.defaultCost},${p.currentStock},\"$status\"\n")
    }
    sb.append("\n")

    sb.append("--- RIWAYAT PRODUKSI ---\n")
    sb.append("ID,Tanggal,Hari,Waktu,Produk,Jumlah Dibuat,Harga Jual,Potensi Omzet,Modal,Catatan\n")
    for (prod in productions) {
      sb.append("${prod.id},\"${prod.formattedDate}\",\"${prod.dayName}\",\"${prod.formattedTime}\",\"${prod.productName}\",${prod.qty},${prod.pricePerUnit},${prod.potentialRevenue},${prod.totalCost},\"${prod.notes}\"\n")
    }
    sb.append("\n")

    sb.append("--- RIWAYAT PENJUALAN ---\n")
    sb.append("ID,Tanggal,Hari,Waktu,Pelanggan,Metode Bayar,Ringkasan Item,Total Qty,Total Omzet,Modal HPP,Keuntungan,Catatan\n")
    for (s in sales) {
      sb.append("${s.id},\"${s.formattedDate}\",\"${s.dayName}\",\"${s.formattedTime}\",\"${s.customerName}\",\"${s.paymentMethod}\",\"${s.itemsSummary}\",${s.totalQty},${s.totalAmount},${s.totalCost},${s.netProfit},\"${s.notes}\"\n")
    }
    sb.append("\n")

    sb.append("--- RIWAYAT PENGELUARAN & BELANJA ---\n")
    sb.append("ID,Tanggal,Hari,Waktu,Nama Barang,Kategori,Jumlah,Satuan,Harga Satuan,Total Belanja,Tempat Beli,Catatan\n")
    for (e in expenses) {
      sb.append("${e.id},\"${e.formattedDate}\",\"${e.dayName}\",\"${e.formattedTime}\",\"${e.itemName}\",\"${e.category}\",${e.qty},\"${e.unit}\",${e.unitPrice},${e.totalAmount},\"${e.placeOrStore}\",\"${e.notes}\"\n")
    }

    return sb.toString()
  }

  // Backup data to JSON
  suspend fun exportBackupJson(
    products: List<ProductEntity>,
    productions: List<ProductionEntity>,
    sales: List<SaleEntity>,
    expenses: List<ExpenseEntity>
  ): String {
    val root = JSONObject()
    root.put("version", 1)
    root.put("appName", "Incu Emak")
    root.put("exportTime", System.currentTimeMillis())

    val productsArray = JSONArray()
    for (p in products) {
      val obj = JSONObject().apply {
        put("name", p.name)
        put("category", p.category)
        put("defaultPrice", p.defaultPrice)
        put("defaultCost", p.defaultCost)
        put("currentStock", p.currentStock)
        put("minStockAlert", p.minStockAlert)
        put("unit", p.unit)
        put("description", p.description)
      }
      productsArray.put(obj)
    }
    root.put("products", productsArray)

    val prodArray = JSONArray()
    for (p in productions) {
      val obj = JSONObject().apply {
        put("productName", p.productName)
        put("dateMillis", p.dateMillis)
        put("dayName", p.dayName)
        put("formattedDate", p.formattedDate)
        put("formattedTime", p.formattedTime)
        put("qty", p.qty)
        put("pricePerUnit", p.pricePerUnit)
        put("costPerUnit", p.costPerUnit)
        put("potentialRevenue", p.potentialRevenue)
        put("totalCost", p.totalCost)
        put("notes", p.notes)
      }
      prodArray.put(obj)
    }
    root.put("productions", prodArray)

    val expArray = JSONArray()
    for (e in expenses) {
      val obj = JSONObject().apply {
        put("itemName", e.itemName)
        put("category", e.category)
        put("dateMillis", e.dateMillis)
        put("dayName", e.dayName)
        put("formattedDate", e.formattedDate)
        put("formattedTime", e.formattedTime)
        put("qty", e.qty)
        put("unit", e.unit)
        put("unitPrice", e.unitPrice)
        put("totalAmount", e.totalAmount)
        put("placeOrStore", e.placeOrStore)
        put("notes", e.notes)
      }
      expArray.put(obj)
    }
    root.put("expenses", expArray)

    return root.toString(2)
  }
}
