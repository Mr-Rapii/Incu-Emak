package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.PointOfSale
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.local.entity.ProductEntity
import com.example.data.local.entity.SaleEntity
import com.example.data.local.entity.SaleItemEntity
import com.example.ui.components.ConfirmationDialog
import com.example.ui.components.ImageViewerDialog
import com.example.ui.components.PhotoAttachmentSelector
import com.example.ui.theme.ExpenseRed
import com.example.ui.theme.PrimaryWarm
import com.example.ui.theme.ProfitGreen
import com.example.ui.theme.RevenueBlue
import com.example.ui.theme.SecondaryGolden
import com.example.ui.util.DateUtils
import com.example.ui.util.FormatUtils
import com.example.ui.viewmodel.MainViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SalesScreen(
  viewModel: MainViewModel,
  modifier: Modifier = Modifier
) {
  val sales by viewModel.sales.collectAsStateWithLifecycle()
  val products by viewModel.products.collectAsStateWithLifecycle()
  val cart by viewModel.posCart.collectAsStateWithLifecycle()

  var searchQuery by remember { mutableStateOf("") }
  var showCheckoutDialog by remember { mutableStateOf(false) }
  var showQuickAddDialog by remember { mutableStateOf(false) }
  var selectedImageDialog by remember { mutableStateOf<SaleEntity?>(null) }
  var itemToDelete by remember { mutableStateOf<SaleEntity?>(null) }

  val filteredSales = sales.filter {
    it.customerName.contains(searchQuery, ignoreCase = true) ||
        it.itemsSummary.contains(searchQuery, ignoreCase = true) ||
        it.formattedDate.contains(searchQuery, ignoreCase = true) ||
        it.notes.contains(searchQuery, ignoreCase = true)
  }

  val totalOmzet = filteredSales.sumOf { it.totalAmount }
  val totalSoldPcs = filteredSales.sumOf { it.totalQty }
  val totalProfit = filteredSales.sumOf { it.netProfit }

  val cartTotalItems = cart.values.sum()
  val cartTotalAmount = cart.entries.sumOf { (productId, count) ->
    val prod = products.find { it.id == productId }
    (prod?.defaultPrice ?: 5000.0) * count
  }

  Scaffold(
    modifier = modifier.fillMaxSize().testTag("sales_screen"),
    floatingActionButton = {
      FloatingActionButton(
        onClick = { showQuickAddDialog = true },
        containerColor = RevenueBlue,
        contentColor = Color.White,
        modifier = Modifier.testTag("add_sale_fab")
      ) {
        Icon(Icons.Default.Add, contentDescription = "Catat Penjualan")
      }
    }
  ) { innerPadding ->
    LazyColumn(
      modifier = Modifier
        .fillMaxSize()
        .padding(innerPadding)
        .background(MaterialTheme.colorScheme.background),
      contentPadding = PaddingValues(16.dp),
      verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
      // 1. Header Summary Card
      item {
        Card(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(20.dp),
          colors = CardDefaults.cardColors(containerColor = RevenueBlue.copy(alpha = 0.1f))
        ) {
          Column(modifier = Modifier.padding(16.dp)) {
            Text(
              text = "Data Penjualan & Kasir",
              style = MaterialTheme.typography.titleMedium,
              fontWeight = FontWeight.ExtraBold,
              color = RevenueBlue
            )
            Text(
              text = "Pencatatan transaksi otomatis mengurangi stok dan menambah omzet",
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(14.dp))

            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Column {
                Text("Total Terjual", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text("$totalSoldPcs pcs", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = RevenueBlue)
              }
              Column {
                Text("Total Omzet", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(FormatUtils.formatRupiah(totalOmzet), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = ProfitGreen)
              }
              Column(horizontalAlignment = Alignment.End) {
                Text("Estimasi Laba", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(FormatUtils.formatRupiah(totalProfit), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = SecondaryGolden)
              }
            }
          }
        }
      }

      // 2. Fast POS Snack Tap Counter / Cart Bar
      item {
        Card(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(18.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
          elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
          Column(modifier = Modifier.padding(14.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.PointOfSale, contentDescription = null, tint = PrimaryWarm, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Kasir Cepat (Tap Snack)", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
              }
              if (cartTotalItems > 0) {
                TextButton(onClick = { viewModel.clearCart() }) {
                  Text("Reset Keranjang", color = ExpenseRed, fontSize = 11.sp)
                }
              }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Product Cards for Quick POS Tap
            LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
              items(products) { prod ->
                val inCartCount = cart.getOrDefault(prod.id, 0)
                Surface(
                  modifier = Modifier
                    .clip(RoundedCornerShape(14.dp))
                    .clickable { viewModel.addToCart(prod.id) },
                  color = if (inCartCount > 0) PrimaryWarm.copy(alpha = 0.15f) else MaterialTheme.colorScheme.surfaceVariant,
                  shape = RoundedCornerShape(14.dp)
                ) {
                  Column(modifier = Modifier.padding(12.dp)) {
                    Text(prod.name, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                    Text("${FormatUtils.formatRupiah(prod.defaultPrice)} • Stok: ${prod.currentStock}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)

                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                      verticalAlignment = Alignment.CenterVertically,
                      horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                      if (inCartCount > 0) {
                        IconButton(
                          onClick = { viewModel.removeFromCart(prod.id) },
                          modifier = Modifier.size(24.dp)
                        ) {
                          Icon(Icons.Default.Remove, contentDescription = "Kurang", modifier = Modifier.size(16.dp))
                        }
                        Text(
                          "$inCartCount pcs",
                          fontWeight = FontWeight.ExtraBold,
                          color = PrimaryWarm,
                          fontSize = 13.sp
                        )
                      }
                      IconButton(
                        onClick = { viewModel.addToCart(prod.id) },
                        modifier = Modifier.size(24.dp)
                      ) {
                        Icon(Icons.Default.Add, contentDescription = "Tambah", modifier = Modifier.size(16.dp))
                      }
                    }
                  }
                }
              }
            }

            // Checkout Bar if items in cart
            if (cartTotalItems > 0) {
              Spacer(modifier = Modifier.height(12.dp))
              Button(
                onClick = { showCheckoutDialog = true },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = ProfitGreen),
                shape = RoundedCornerShape(12.dp)
              ) {
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.SpaceBetween,
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  Text("$cartTotalItems pcs di Keranjang", color = Color.White, fontWeight = FontWeight.Bold)
                  Text("Checkout ${FormatUtils.formatRupiah(cartTotalAmount)} →", color = Color.White, fontWeight = FontWeight.ExtraBold)
                }
              }
            }
          }
        }
      }

      // 3. Search Bar
      item {
        OutlinedTextField(
          value = searchQuery,
          onValueChange = { searchQuery = it },
          modifier = Modifier.fillMaxWidth(),
          placeholder = { Text("Cari pelanggan, produk terjual, tanggal...") },
          leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
          shape = RoundedCornerShape(14.dp),
          singleLine = true
        )
      }

      // 4. Sales Log List
      if (filteredSales.isEmpty()) {
        item {
          Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
          ) {
            Column(
              modifier = Modifier
                .fillMaxWidth()
                .padding(32.dp),
              horizontalAlignment = Alignment.CenterHorizontally
            ) {
              Icon(Icons.Default.ShoppingCart, contentDescription = null, modifier = Modifier.size(48.dp), tint = RevenueBlue.copy(alpha = 0.4f))
              Spacer(modifier = Modifier.height(8.dp))
              Text("Belum ada data penjualan", fontWeight = FontWeight.Bold)
              Text("Gunakan kasir cepat atau tekan tombol + di bawah", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
          }
        }
      } else {
        items(filteredSales, key = { it.id }) { sale ->
          SaleCard(
            sale = sale,
            onImageClick = { selectedImageDialog = sale },
            onDeleteClick = { itemToDelete = sale }
          )
        }
      }
    }
  }

  // Checkout Dialog for POS Cart
  if (showCheckoutDialog) {
    CheckoutCartDialog(
      cart = cart,
      products = products,
      onDismiss = { showCheckoutDialog = false },
      onConfirm = { custName, payMethod, notes, photoUri ->
        val items = cart.mapNotNull { (prodId, count) ->
          val prod = products.find { it.id == prodId } ?: return@mapNotNull null
          SaleItemEntity(
            saleId = 0,
            productId = prod.id,
            productName = prod.name,
            qty = count,
            pricePerUnit = prod.defaultPrice,
            costPerUnit = prod.defaultCost,
            subtotal = prod.defaultPrice * count
          )
        }
        viewModel.addSale(custName, payMethod, System.currentTimeMillis(), notes, items, photoUri)
        showCheckoutDialog = false
      }
    )
  }

  // Quick Add Custom Sale Dialog
  if (showQuickAddDialog) {
    AddCustomSaleDialog(
      products = products,
      onDismiss = { showQuickAddDialog = false },
      onSave = { custName, payMethod, dateMillis, notes, items, photoUri ->
        viewModel.addSale(custName, payMethod, dateMillis, notes, items, photoUri)
        showQuickAddDialog = false
      }
    )
  }

  // Delete Confirmation Dialog
  itemToDelete?.let { sale ->
    ConfirmationDialog(
      title = "Hapus Penjualan #${sale.id}?",
      message = "Menghapus penjualan ${sale.itemsSummary} senilai ${FormatUtils.formatRupiah(sale.totalAmount)} akan mengembalikan stok produk yang telah terjual.",
      onConfirm = {
        viewModel.deleteSale(sale)
        itemToDelete = null
      },
      onDismiss = { itemToDelete = null }
    )
  }

  // Image Viewer Dialog
  selectedImageDialog?.let { sale ->
    ImageViewerDialog(
      photoUri = sale.photoUri ?: "",
      title = "Bukti Penjualan #${sale.id}",
      subtitle = "${sale.customerName.ifBlank { "Pelanggan" }} • ${sale.formattedDate}",
      onDismiss = { selectedImageDialog = null }
    )
  }
}

@Composable
private fun SaleCard(
  sale: SaleEntity,
  onImageClick: () -> Unit,
  onDeleteClick: () -> Unit
) {
  Card(
    modifier = Modifier.fillMaxWidth(),
    shape = RoundedCornerShape(18.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
  ) {
    Column(modifier = Modifier.padding(16.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Box(
            modifier = Modifier
              .size(40.dp)
              .background(RevenueBlue.copy(alpha = 0.12f), CircleShape),
            contentAlignment = Alignment.Center
          ) {
            Icon(Icons.Default.ShoppingCart, contentDescription = null, tint = RevenueBlue, modifier = Modifier.size(20.dp))
          }
          Spacer(modifier = Modifier.width(12.dp))
          Column {
            Text(
              text = if (sale.customerName.isNotBlank()) sale.customerName else "Penjualan #${sale.id}",
              style = MaterialTheme.typography.titleMedium,
              fontWeight = FontWeight.Bold
            )
            Text(
              text = "${sale.dayName}, ${sale.formattedDate} • ${sale.formattedTime}",
              style = MaterialTheme.typography.labelSmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
          Surface(
            color = MaterialTheme.colorScheme.surfaceVariant,
            shape = RoundedCornerShape(8.dp)
          ) {
            Text(
              text = sale.paymentMethod,
              style = MaterialTheme.typography.labelSmall,
              fontWeight = FontWeight.SemiBold,
              modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
            )
          }
          IconButton(onClick = onDeleteClick) {
            Icon(Icons.Default.Delete, contentDescription = "Hapus", tint = ExpenseRed.copy(alpha = 0.7f), modifier = Modifier.size(20.dp))
          }
        }
      }

      Spacer(modifier = Modifier.height(12.dp))

      // Item Summary Breakdown
      Surface(
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(12.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Text(
              text = sale.itemsSummary,
              style = MaterialTheme.typography.bodyMedium,
              fontWeight = FontWeight.SemiBold,
              modifier = Modifier.weight(1f)
            )
            Text(
              text = FormatUtils.formatRupiah(sale.totalAmount),
              style = MaterialTheme.typography.titleMedium,
              fontWeight = FontWeight.ExtraBold,
              color = ProfitGreen
            )
          }

          if (sale.netProfit > 0) {
            Spacer(modifier = Modifier.height(4.dp))
            Text(
              text = "Estimasi Laba Bersih: ${FormatUtils.formatRupiah(sale.netProfit)}",
              style = MaterialTheme.typography.labelSmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }
        }
      }

      if (sale.notes.isNotBlank()) {
        Spacer(modifier = Modifier.height(8.dp))
        Text(
          text = "Catatan: ${sale.notes}",
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
      }

      if (!sale.photoUri.isNullOrBlank()) {
        Spacer(modifier = Modifier.height(10.dp))
        Row(
          modifier = Modifier
            .clip(RoundedCornerShape(10.dp))
            .clickable { onImageClick() }
            .background(SecondaryGolden.copy(alpha = 0.1f))
            .padding(horizontal = 10.dp, vertical = 6.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Icon(Icons.Default.Image, contentDescription = null, tint = SecondaryGolden, modifier = Modifier.size(16.dp))
          Spacer(modifier = Modifier.width(6.dp))
          Text("Lihat Bukti Transaksi", style = MaterialTheme.typography.labelSmall, color = SecondaryGolden, fontWeight = FontWeight.Bold)
        }
      }
    }
  }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun CheckoutCartDialog(
  cart: Map<Long, Int>,
  products: List<ProductEntity>,
  onDismiss: () -> Unit,
  onConfirm: (String, String, String, String?) -> Unit
) {
  var customerName by remember { mutableStateOf("") }
  var paymentMethod by remember { mutableStateOf("Tunai") }
  var notes by remember { mutableStateOf("") }
  var photoUri by remember { mutableStateOf<String?>(null) }

  val paymentOptions = listOf("Tunai", "QRIS", "Transfer", "Utang/Kasbon")

  val totalAmount = cart.entries.sumOf { (prodId, count) ->
    val p = products.find { it.id == prodId }
    (p?.defaultPrice ?: 5000.0) * count
  }

  AlertDialog(
    onDismissRequest = onDismiss,
    title = { Text("Checkout Penjualan Kasir", fontWeight = FontWeight.Bold) },
    text = {
      Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        // Items list
        Surface(
          color = MaterialTheme.colorScheme.surfaceVariant,
          shape = RoundedCornerShape(12.dp),
          modifier = Modifier.fillMaxWidth()
        ) {
          Column(modifier = Modifier.padding(12.dp)) {
            cart.forEach { (prodId, count) ->
              val p = products.find { it.id == prodId }
              if (p != null) {
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.SpaceBetween
                ) {
                  Text("${count}x ${p.name}", fontSize = 13.sp)
                  Text(FormatUtils.formatRupiah(p.defaultPrice * count), fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                }
              }
            }
            Spacer(modifier = Modifier.height(6.dp))
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Text("Total Transaksi", fontWeight = FontWeight.Bold)
              Text(FormatUtils.formatRupiah(totalAmount), fontWeight = FontWeight.ExtraBold, color = ProfitGreen)
            }
          }
        }

        OutlinedTextField(
          value = customerName,
          onValueChange = { customerName = it },
          label = { Text("Nama Pelanggan (Opsional)") },
          modifier = Modifier.fillMaxWidth(),
          singleLine = true
        )

        // Payment Method Chips
        Column {
          Text("Metode Pembayaran", style = MaterialTheme.typography.labelSmall)
          Spacer(modifier = Modifier.height(4.dp))
          Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            paymentOptions.forEach { opt ->
              FilterChip(
                selected = paymentMethod == opt,
                onClick = { paymentMethod = opt },
                label = { Text(opt, fontSize = 11.sp) },
                colors = FilterChipDefaults.filterChipColors(
                  selectedContainerColor = ProfitGreen.copy(alpha = 0.15f),
                  selectedLabelColor = ProfitGreen
                )
              )
            }
          }
        }

        OutlinedTextField(
          value = notes,
          onValueChange = { notes = it },
          label = { Text("Catatan Penjualan (Opsional)") },
          modifier = Modifier.fillMaxWidth(),
          singleLine = true
        )

        PhotoAttachmentSelector(
          selectedPhotoUri = photoUri,
          onPhotoSelected = { photoUri = it },
          label = "Foto Bukti / Struk (Opsional)"
        )
      }
    },
    confirmButton = {
      Button(
        onClick = { onConfirm(customerName, paymentMethod, notes, photoUri) },
        colors = ButtonDefaults.buttonColors(containerColor = ProfitGreen)
      ) {
        Text("Proses Penjualan (${FormatUtils.formatRupiah(totalAmount)})", color = Color.White)
      }
    },
    dismissButton = {
      TextButton(onClick = onDismiss) { Text("Batal") }
    }
  )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AddCustomSaleDialog(
  products: List<ProductEntity>,
  onDismiss: () -> Unit,
  onSave: (String, String, Long, String, List<SaleItemEntity>, String?) -> Unit
) {
  var selectedProduct by remember { mutableStateOf(products.firstOrNull()) }
  var qtyText by remember { mutableStateOf("5") }
  var priceText by remember { mutableStateOf(selectedProduct?.defaultPrice?.toInt()?.toString() ?: "5000") }
  var customerName by remember { mutableStateOf("") }
  var paymentMethod by remember { mutableStateOf("Tunai") }
  var notes by remember { mutableStateOf("") }
  var photoUri by remember { mutableStateOf<String?>(null) }
  var expanded by remember { mutableStateOf(false) }

  val dateMillis = System.currentTimeMillis()
  val qty = qtyText.toIntOrNull() ?: 0
  val price = priceText.toDoubleOrNull() ?: 0.0
  val total = qty * price

  AlertDialog(
    onDismissRequest = onDismiss,
    title = { Text("Catat Penjualan Manual", fontWeight = FontWeight.Bold) },
    text = {
      Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        ExposedDropdownMenuBox(
          expanded = expanded,
          onExpandedChange = { expanded = !expanded }
        ) {
          OutlinedTextField(
            value = selectedProduct?.name ?: "Pilih Produk",
            onValueChange = {},
            readOnly = true,
            label = { Text("Produk Terjual") },
            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
            modifier = Modifier.menuAnchor().fillMaxWidth()
          )
          ExposedDropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false }
          ) {
            products.forEach { prod ->
              DropdownMenuItem(
                text = { Text("${prod.name} (Stok: ${prod.currentStock})") },
                onClick = {
                  selectedProduct = prod
                  priceText = prod.defaultPrice.toInt().toString()
                  expanded = false
                }
              )
            }
          }
        }

        OutlinedTextField(
          value = qtyText,
          onValueChange = { qtyText = it },
          label = { Text("Jumlah Terjual (pcs)") },
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
          modifier = Modifier.fillMaxWidth()
        )

        OutlinedTextField(
          value = priceText,
          onValueChange = { priceText = it },
          label = { Text("Harga per pcs (Rp)") },
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
          modifier = Modifier.fillMaxWidth()
        )

        Surface(
          color = RevenueBlue.copy(alpha = 0.1f),
          shape = RoundedCornerShape(12.dp),
          modifier = Modifier.fillMaxWidth()
        ) {
          Row(
            modifier = Modifier.padding(10.dp),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Text("Total Penjualan: $qty × ${FormatUtils.formatRupiah(price)}", fontSize = 12.sp)
            Text(FormatUtils.formatRupiah(total), fontWeight = FontWeight.ExtraBold, color = ProfitGreen)
          }
        }

        OutlinedTextField(
          value = customerName,
          onValueChange = { customerName = it },
          label = { Text("Nama Pelanggan (Opsional)") },
          modifier = Modifier.fillMaxWidth(),
          singleLine = true
        )

        OutlinedTextField(
          value = notes,
          onValueChange = { notes = it },
          label = { Text("Catatan") },
          modifier = Modifier.fillMaxWidth(),
          singleLine = true
        )

        PhotoAttachmentSelector(
          selectedPhotoUri = photoUri,
          onPhotoSelected = { photoUri = it }
        )
      }
    },
    confirmButton = {
      Button(
        onClick = {
          selectedProduct?.let { prod ->
            if (qty > 0) {
              val item = SaleItemEntity(
                saleId = 0,
                productId = prod.id,
                productName = prod.name,
                qty = qty,
                pricePerUnit = price,
                costPerUnit = prod.defaultCost,
                subtotal = total
              )
              onSave(customerName, paymentMethod, dateMillis, notes, listOf(item), photoUri)
            }
          }
        },
        enabled = selectedProduct != null && qty > 0,
        colors = ButtonDefaults.buttonColors(containerColor = RevenueBlue)
      ) {
        Text("Simpan & Kurangi Stok", color = Color.White)
      }
    },
    dismissButton = {
      TextButton(onClick = onDismiss) { Text("Batal") }
    }
  )
}
