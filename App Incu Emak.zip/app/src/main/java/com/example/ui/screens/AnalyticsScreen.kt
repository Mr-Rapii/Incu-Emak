package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Insights
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.TrendingDown
import androidx.compose.material.icons.filled.TrendingFlat
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.components.MultiMetricBarChart
import com.example.ui.components.TrendLineChart
import com.example.ui.theme.ExpenseRed
import com.example.ui.theme.PrimaryWarm
import com.example.ui.theme.ProfitGreen
import com.example.ui.theme.RevenueBlue
import com.example.ui.theme.SecondaryGolden
import com.example.ui.theme.WarningAmber
import com.example.ui.util.FormatUtils
import com.example.ui.viewmodel.MainViewModel

@Composable
fun AnalyticsScreen(
  viewModel: MainViewModel,
  modifier: Modifier = Modifier
) {
  val dashboardState by viewModel.dashboardState.collectAsStateWithLifecycle()
  val expenses by viewModel.expenses.collectAsStateWithLifecycle()

  val expenseByCategory = expenses.groupBy { it.category }
    .mapValues { entry -> entry.value.sumOf { it.totalAmount } }
    .toList()
    .sortedByDescending { it.second }

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .background(MaterialTheme.colorScheme.background)
      .testTag("analytics_screen"),
    contentPadding = PaddingValues(16.dp),
    verticalArrangement = Arrangement.spacedBy(14.dp)
  ) {
    // 1. Growth Intelligence Banner (e.g. Penghasilan minggu ini naik 25% dibanding minggu sebelumnya)
    item {
      val isWeeklyUp = dashboardState.weeklyRevenueDeltaPercent >= 0
      val isMonthlyUp = dashboardState.monthlyRevenueDeltaPercent >= 0

      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
          containerColor = if (isWeeklyUp) ProfitGreen.copy(alpha = 0.12f) else ExpenseRed.copy(alpha = 0.12f)
        )
      ) {
        Row(
          modifier = Modifier.padding(18.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Box(
            modifier = Modifier
              .size(46.dp)
              .background(if (isWeeklyUp) ProfitGreen else ExpenseRed, CircleShape),
            contentAlignment = Alignment.Center
          ) {
            Icon(
              imageVector = if (isWeeklyUp) Icons.Default.TrendingUp else Icons.Default.TrendingDown,
              contentDescription = null,
              tint = Color.White,
              modifier = Modifier.size(24.dp)
            )
          }

          Spacer(modifier = Modifier.width(14.dp))

          Column {
            Text(
              text = if (isWeeklyUp) "Pertumbuhan Positif!" else "Evaluasi Tren Usaha",
              style = MaterialTheme.typography.titleMedium,
              fontWeight = FontWeight.ExtraBold,
              color = if (isWeeklyUp) ProfitGreen else ExpenseRed
            )
            Text(
              text = "Penghasilan minggu ini ${if (isWeeklyUp) "naik" else "turun"} ${FormatUtils.formatPercentage(dashboardState.weeklyRevenueDeltaPercent)} dibanding minggu sebelumnya.",
              style = MaterialTheme.typography.bodyMedium,
              color = MaterialTheme.colorScheme.onSurface
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
              text = "Bulan ini: ${if (isMonthlyUp) "Naik" else "Turun"} ${FormatUtils.formatPercentage(dashboardState.monthlyRevenueDeltaPercent)} vs bulan lalu",
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }
        }
      }
    }

    // 2. Average KPIs
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
      ) {
        InsightMetricCard(
          title = "Rata-rata Omzet/Hari",
          value = FormatUtils.formatRupiah(dashboardState.averageDailyRevenue),
          subtitle = "7 hari terakhir",
          icon = Icons.Default.Insights,
          color = RevenueBlue,
          modifier = Modifier.weight(1f)
        )
        InsightMetricCard(
          title = "Rata-rata Terjual/Hari",
          value = "${dashboardState.averageDailySoldQty} pcs",
          subtitle = "7 hari terakhir",
          icon = Icons.Default.Star,
          color = PrimaryWarm,
          modifier = Modifier.weight(1f)
        )
      }
    }

    // 3. Peak Days Analysis (Hari Paling Ramai & Hari Paling Sepi)
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Text(
            text = "Analisis Pola Hari Penjualan",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold
          )
          Spacer(modifier = Modifier.height(12.dp))

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
          ) {
            Surface(
              modifier = Modifier.weight(1f),
              color = ProfitGreen.copy(alpha = 0.1f),
              shape = RoundedCornerShape(14.dp)
            ) {
              Column(modifier = Modifier.padding(12.dp)) {
                Text("🔥 Hari Paling Ramai", fontWeight = FontWeight.Bold, color = ProfitGreen, fontSize = 12.sp)
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                  text = dashboardState.busiestDay,
                  style = MaterialTheme.typography.titleMedium,
                  fontWeight = FontWeight.ExtraBold
                )
              }
            }

            Surface(
              modifier = Modifier.weight(1f),
              color = WarningAmber.copy(alpha = 0.1f),
              shape = RoundedCornerShape(14.dp)
            ) {
              Column(modifier = Modifier.padding(12.dp)) {
                Text("💤 Hari Paling Sepi", fontWeight = FontWeight.Bold, color = WarningAmber, fontSize = 12.sp)
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                  text = dashboardState.quietestDay,
                  style = MaterialTheme.typography.titleMedium,
                  fontWeight = FontWeight.ExtraBold
                )
              }
            }
          }
        }
      }
    }

    // 4. Trend Charts
    item {
      TrendLineChart(stats = dashboardState.last7DaysStats, selectedMetric = "Keuntungan")
    }

    item {
      MultiMetricBarChart(stats = dashboardState.last7DaysStats)
    }

    // 5. Expense Breakdown by Category
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Text(
            text = "Kategori Pengeluaran Terbesar",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold
          )
          Spacer(modifier = Modifier.height(12.dp))

          if (expenseByCategory.isEmpty()) {
            Text("Belum ada data pengeluaran.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
          } else {
            val totalAllExp = expenseByCategory.sumOf { it.second }.coerceAtLeast(1.0)
            expenseByCategory.forEach { (cat, amount) ->
              val pct = ((amount / totalAllExp) * 100).toInt()
              Column(modifier = Modifier.padding(vertical = 4.dp)) {
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.SpaceBetween
                ) {
                  Text(cat, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                  Text("${FormatUtils.formatRupiah(amount)} ($pct%)", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = ExpenseRed)
                }
              }
            }
          }
        }
      }
    }
  }
}

@Composable
private fun InsightMetricCard(
  title: String,
  value: String,
  subtitle: String,
  icon: androidx.compose.ui.graphics.vector.ImageVector,
  color: Color,
  modifier: Modifier = Modifier
) {
  Card(
    modifier = modifier,
    shape = RoundedCornerShape(18.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
  ) {
    Column(modifier = Modifier.padding(14.dp)) {
      Box(
        modifier = Modifier
          .size(36.dp)
          .background(color.copy(alpha = 0.12f), CircleShape),
        contentAlignment = Alignment.Center
      ) {
        Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(18.dp))
      }
      Spacer(modifier = Modifier.height(8.dp))
      Text(title, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
      Spacer(modifier = Modifier.height(2.dp))
      Text(value, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.ExtraBold)
      Text(subtitle, style = MaterialTheme.typography.labelSmall, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
  }
}
