package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.local.entity.BusinessTargetEntity
import com.example.data.local.entity.ExpenseEntity
import com.example.data.local.entity.ProductEntity
import com.example.data.local.entity.ProductionEntity
import com.example.data.local.entity.SaleEntity
import com.example.data.local.entity.SaleItemEntity
import com.example.data.local.entity.StockAdjustmentEntity
import com.example.data.repository.BusinessRepository
import com.example.ui.util.DateUtils
import com.example.ui.util.FormatUtils
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.Calendar

// Data Classes for UI State & Analytics
data class DailyStat(
  val dayName: String,
  val formattedDate: String,
  val dateMillis: Long,
  val revenue: Double,
  val expense: Double,
  val profit: Double,
  val productionQty: Int,
  val soldQty: Int
)

data class ProductPerformance(
  val product: ProductEntity,
  val totalProduced: Int,
  val totalSold: Int,
  val totalRevenue: Double,
  val totalProfit: Double,
  val stockStatus: String // "Aman", "Hampir Habis", "Habis"
)

data class CategoryExpense(
  val category: String,
  val total: Double,
  val percentage: Double
)

data class BusinessInsights(
  val topSellingProduct: String,
  val topSellingQty: Int,
  val leastSellingProduct: String,
  val leastSellingQty: Int,
  val mostProducedProduct: String,
  val mostProducedQty: Int,
  val busiestDay: String,
  val slowestDay: String,
  val avgDailyRevenue: Double,
  val avgDailySalesQty: Double,
  val weeklyTrendPercent: Double,
  val weeklyTrendStatus: String, // "NAIK", "TURUN", "STABIL"
  val dailyTrendPercent: Double,
  val monthlyTrendPercent: Double,
  val dominantExpenseCategory: String,
  val lowStockProductsCount: Int
)

data class DashboardUiState(
  val totalProducedAllTime: Int = 0,
  val totalSoldAllTime: Int = 0,
  val totalRevenueAllTime: Double = 0.0,
  val totalExpenseAllTime: Double = 0.0,
  val totalNetProfitAllTime: Double = 0.0,
  // Today's Stats
  val todayProduced: Int = 0,
  val todaySold: Int = 0,
  val todayRevenue: Double = 0.0,
  val todayExpense: Double = 0.0,
  val todayProfit: Double = 0.0,
  val todayPotentialRevenue: Double = 0.0,
  // Yesterday's Stats
  val yesterdayRevenue: Double = 0.0,
  val dailyRevenueDeltaPercent: Double = 0.0,
  // This Week Stats
  val thisWeekRevenue: Double = 0.0,
  val lastWeekRevenue: Double = 0.0,
  val weeklyRevenueDeltaPercent: Double = 0.0,
  // This Month Stats
  val thisMonthRevenue: Double = 0.0,
  val lastMonthRevenue: Double = 0.0,
  val monthlyRevenueDeltaPercent: Double = 0.0,
  // Target Progress
  val dailyTarget: Double = 100000.0,
  val weeklyTarget: Double = 700000.0,
  val monthlyTarget: Double = 3000000.0,
  val monthlyTargetProgressPercent: Double = 0.0,
  // Chart Series (Last 7 Days)
  val last7DaysStats: List<DailyStat> = emptyList(),
  // Top Ranked Products
  val topProducedProduct: String = "-",
  val topSoldProduct: String = "-",
  // Low Stock Warnings
  val lowStockList: List<ProductEntity> = emptyList(),
  // Full Insights
  val insights: BusinessInsights? = null,
  val averageDailyRevenue: Double = 0.0,
  val averageDailySoldQty: Int = 0,
  val busiestDay: String = "Sabtu",
  val quietestDay: String = "Senin"
)

data class GalleryItem(
  val id: Long,
  val type: String, // "PRODUKSI", "PENJUALAN", "BELANJA", "PRODUK"
  val title: String,
  val subtitle: String,
  val dateFormatted: String,
  val photoUri: String
)

class MainViewModel(application: Application) : AndroidViewModel(application) {
  private val repository: BusinessRepository

  init {
    val db = AppDatabase.getDatabase(application, viewModelScope)
    repository = BusinessRepository(db)
  }

  // Raw Data Flows
  val products: StateFlow<List<ProductEntity>> = repository.allProducts
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val productions: StateFlow<List<ProductionEntity>> = repository.allProductions
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val sales: StateFlow<List<SaleEntity>> = repository.allSales
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val saleItems: StateFlow<List<SaleItemEntity>> = repository.allSaleItems
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val expenses: StateFlow<List<ExpenseEntity>> = repository.allExpenses
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val stockAdjustments: StateFlow<List<StockAdjustmentEntity>> = repository.allStockAdjustments
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val businessTarget: StateFlow<BusinessTargetEntity?> = repository.businessTarget
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

  // Selected Filter State
  val selectedDateMillis = MutableStateFlow(System.currentTimeMillis())
  val searchQuery = MutableStateFlow("")

  // Quick POS Cart State: Map of ProductId -> Quantity
  val posCart = MutableStateFlow<Map<Long, Int>>(emptyMap())

  // Dashboard Aggregated UI State
  val dashboardState: StateFlow<DashboardUiState> = combine(
    products,
    productions,
    sales,
    expenses,
    businessTarget
  ) { prods, prodList, saleList, expList, target ->
    computeDashboardState(prods, prodList, saleList, expList, target)
  }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), DashboardUiState())

  // Photos Gallery Combined Flow
  val galleryItems: StateFlow<List<GalleryItem>> = combine(
    products,
    productions,
    sales,
    expenses
  ) { prods, prodList, saleList, expList ->
    val list = mutableListOf<GalleryItem>()
    for (p in prods) {
      if (!p.photoUri.isNullOrBlank()) {
        list.add(GalleryItem(p.id, "PRODUK", p.name, "Foto Produk", "Katalog", p.photoUri))
      }
    }
    for (prod in prodList) {
      if (!prod.photoUri.isNullOrBlank()) {
        list.add(GalleryItem(prod.id, "PRODUKSI", prod.productName, "${prod.qty} pcs - ${prod.notes}", prod.formattedDate, prod.photoUri))
      }
    }
    for (s in saleList) {
      if (!s.photoUri.isNullOrBlank()) {
        list.add(GalleryItem(s.id, "PENJUALAN", "Penjualan #${s.id}", s.customerName.ifBlank { s.itemsSummary }, s.formattedDate, s.photoUri))
      }
    }
    for (e in expList) {
      if (!e.receiptPhotoUri.isNullOrBlank()) {
        list.add(GalleryItem(e.id, "BELANJA", e.itemName, "${e.category} - ${FormatUtils.formatRupiah(e.totalAmount)}", e.formattedDate, e.receiptPhotoUri))
      }
    }
    list
  }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  private fun computeDashboardState(
    prods: List<ProductEntity>,
    prodList: List<ProductionEntity>,
    saleList: List<SaleEntity>,
    expList: List<ExpenseEntity>,
    target: BusinessTargetEntity?
  ): DashboardUiState {
    val totalProducedAll = prodList.sumOf { it.qty }
    val totalSoldAll = saleList.sumOf { it.totalQty }
    val totalRevAll = saleList.sumOf { it.totalAmount }
    val totalExpAll = expList.sumOf { it.totalAmount }
    val totalProfitAll = totalRevAll - totalExpAll

    val now = System.currentTimeMillis()
    val todayStart = DateUtils.getStartOfDay(now)
    val todayEnd = DateUtils.getEndOfDay(now)

    val yesterdayMillis = now - 86400000L
    val yestStart = DateUtils.getStartOfDay(yesterdayMillis)
    val yestEnd = DateUtils.getEndOfDay(yesterdayMillis)

    val weekStart = DateUtils.getStartOfWeek(now)
    val weekEnd = DateUtils.getEndOfWeek(now)
    val lastWeekStart = weekStart - (7 * 86400000L)
    val lastWeekEnd = weekStart - 1

    val monthStart = DateUtils.getStartOfMonth(now)
    val monthEnd = DateUtils.getEndOfMonth(now)

    val cal = Calendar.getInstance().apply { timeInMillis = now }
    cal.add(Calendar.MONTH, -1)
    val lastMonthStart = DateUtils.getStartOfMonth(cal.timeInMillis)
    val lastMonthEnd = DateUtils.getEndOfMonth(cal.timeInMillis)

    // Today's numbers
    val todayProds = prodList.filter { it.dateMillis in todayStart..todayEnd }
    val todaySales = saleList.filter { it.dateMillis in todayStart..todayEnd }
    val todayExpenses = expList.filter { it.dateMillis in todayStart..todayEnd }

    val todayProducedQty = todayProds.sumOf { it.qty }
    val todaySoldQty = todaySales.sumOf { it.totalQty }
    val todayRev = todaySales.sumOf { it.totalAmount }
    val todayExp = todayExpenses.sumOf { it.totalAmount }
    val todayNetProfit = todayRev - todayExp
    val todayPotentialRev = todayProds.sumOf { it.potentialRevenue }

    // Yesterday's numbers
    val yestSales = saleList.filter { it.dateMillis in yestStart..yestEnd }
    val yestRev = yestSales.sumOf { it.totalAmount }
    val dailyDeltaPercent = if (yestRev > 0) ((todayRev - yestRev) / yestRev) * 100.0 else if (todayRev > 0) 100.0 else 0.0

    // Week numbers
    val thisWeekSales = saleList.filter { it.dateMillis in weekStart..weekEnd }
    val lastWeekSales = saleList.filter { it.dateMillis in lastWeekStart..lastWeekEnd }
    val thisWeekRev = thisWeekSales.sumOf { it.totalAmount }
    val lastWeekRev = lastWeekSales.sumOf { it.totalAmount }
    val weeklyDeltaPercent = if (lastWeekRev > 0) ((thisWeekRev - lastWeekRev) / lastWeekRev) * 100.0 else if (thisWeekRev > 0) 100.0 else 0.0

    // Month numbers
    val thisMonthSales = saleList.filter { it.dateMillis in monthStart..monthEnd }
    val lastMonthSales = saleList.filter { it.dateMillis in lastMonthStart..lastMonthEnd }
    val thisMonthRev = thisMonthSales.sumOf { it.totalAmount }
    val lastMonthRev = lastMonthSales.sumOf { it.totalAmount }
    val monthlyDeltaPercent = if (lastMonthRev > 0) ((thisMonthRev - lastMonthRev) / lastMonthRev) * 100.0 else if (thisMonthRev > 0) 100.0 else 0.0

    // Targets
    val dTarget = target?.dailyTarget ?: 100000.0
    val wTarget = target?.weeklyTarget ?: 700000.0
    val mTarget = target?.monthlyTarget ?: 3000000.0
    val monthProgress = if (mTarget > 0) (thisMonthRev / mTarget) * 100.0 else 0.0

    // Last 7 days stats for Charts
    val last7Days = mutableListOf<DailyStat>()
    for (i in 6 downTo 0) {
      val dayMillis = now - (i * 86400000L)
      val dStart = DateUtils.getStartOfDay(dayMillis)
      val dEnd = DateUtils.getEndOfDay(dayMillis)

      val dSales = saleList.filter { it.dateMillis in dStart..dEnd }
      val dExp = expList.filter { it.dateMillis in dStart..dEnd }
      val dProds = prodList.filter { it.dateMillis in dStart..dEnd }

      val dRev = dSales.sumOf { it.totalAmount }
      val dCost = dExp.sumOf { it.totalAmount }

      last7Days.add(
        DailyStat(
          dayName = DateUtils.getDayName(dayMillis),
          formattedDate = DateUtils.getFormattedDate(dayMillis),
          dateMillis = dayMillis,
          revenue = dRev,
          expense = dCost,
          profit = dRev - dCost,
          productionQty = dProds.sumOf { it.qty },
          soldQty = dSales.sumOf { it.totalQty }
        )
      )
    }

    // Top produced product
    val prodGroup = prodList.groupBy { it.productName }
    val topProduced = prodGroup.maxByOrNull { it.value.sumOf { p -> p.qty } }?.key ?: "-"

    // Top sold product
    val saleGroup = saleList.flatMap { s ->
      // approximation from itemsSummary or raw sale
      listOf(Pair(s.itemsSummary, s.totalQty))
    }
    val topSold = prods.maxByOrNull { p ->
      // count qty sold from sales
      saleList.filter { it.itemsSummary.contains(p.name, ignoreCase = true) }.sumOf { it.totalQty }
    }?.name ?: "-"

    // Low stock products
    val lowStock = prods.filter { it.currentStock <= it.minStockAlert }

    // Insights computation
    val busiestDayStat = last7Days.maxByOrNull { it.revenue }
    val slowestDayStat = last7Days.minByOrNull { it.revenue }

    val expCategories = expList.groupBy { it.category }
    val domExpCat = expCategories.maxByOrNull { it.value.sumOf { e -> e.totalAmount } }?.key ?: "Bahan Baku"

    val weeklyTrendStatus = when {
      weeklyDeltaPercent > 5.0 -> "NAIK"
      weeklyDeltaPercent < -5.0 -> "TURUN"
      else -> "STABIL"
    }

    val insights = BusinessInsights(
      topSellingProduct = topSold,
      topSellingQty = totalSoldAll,
      leastSellingProduct = prods.minByOrNull { it.currentStock }?.name ?: "-",
      leastSellingQty = 0,
      mostProducedProduct = topProduced,
      mostProducedQty = totalProducedAll,
      busiestDay = busiestDayStat?.dayName ?: "Minggu",
      slowestDay = slowestDayStat?.dayName ?: "Senin",
      avgDailyRevenue = if (last7Days.isNotEmpty()) last7Days.map { it.revenue }.average() else 0.0,
      avgDailySalesQty = if (last7Days.isNotEmpty()) last7Days.map { it.soldQty }.average() else 0.0,
      weeklyTrendPercent = weeklyDeltaPercent,
      weeklyTrendStatus = weeklyTrendStatus,
      dailyTrendPercent = dailyDeltaPercent,
      monthlyTrendPercent = monthlyDeltaPercent,
      dominantExpenseCategory = domExpCat,
      lowStockProductsCount = lowStock.size
    )

    return DashboardUiState(
      totalProducedAllTime = totalProducedAll,
      totalSoldAllTime = totalSoldAll,
      totalRevenueAllTime = totalRevAll,
      totalExpenseAllTime = totalExpAll,
      totalNetProfitAllTime = totalProfitAll,
      todayProduced = todayProducedQty,
      todaySold = todaySoldQty,
      todayRevenue = todayRev,
      todayExpense = todayExp,
      todayProfit = todayNetProfit,
      todayPotentialRevenue = todayPotentialRev,
      yesterdayRevenue = yestRev,
      dailyRevenueDeltaPercent = dailyDeltaPercent,
      thisWeekRevenue = thisWeekRev,
      lastWeekRevenue = lastWeekRev,
      weeklyRevenueDeltaPercent = weeklyDeltaPercent,
      thisMonthRevenue = thisMonthRev,
      lastMonthRevenue = lastMonthRev,
      monthlyRevenueDeltaPercent = monthlyDeltaPercent,
      dailyTarget = dTarget,
      weeklyTarget = wTarget,
      monthlyTarget = mTarget,
      monthlyTargetProgressPercent = monthProgress,
      last7DaysStats = last7Days,
      topProducedProduct = topProduced,
      topSoldProduct = topSold,
      lowStockList = lowStock,
      insights = insights
    )
  }

  // Actions
  fun addProduct(
    name: String,
    category: String,
    price: Double,
    cost: Double,
    initialStock: Int,
    minStock: Int,
    unit: String,
    desc: String,
    photoUri: String? = null
  ) {
    viewModelScope.launch {
      repository.insertProduct(
        ProductEntity(
          name = name.trim(),
          category = category.trim().ifBlank { "Makanan Ringan" },
          defaultPrice = price,
          defaultCost = cost,
          currentStock = initialStock,
          minStockAlert = minStock,
          unit = unit.trim().ifBlank { "pcs" },
          description = desc.trim(),
          photoUri = photoUri
        )
      )
    }
  }

  fun updateProduct(product: ProductEntity) {
    viewModelScope.launch {
      repository.updateProduct(product)
    }
  }

  fun deleteProduct(product: ProductEntity) {
    viewModelScope.launch {
      repository.deleteProduct(product)
    }
  }

  fun addProduction(
    productId: Long,
    productName: String,
    qty: Int,
    pricePerUnit: Double,
    costPerUnit: Double,
    dateMillis: Long,
    notes: String,
    photoUri: String? = null
  ) {
    viewModelScope.launch {
      val potRev = qty * pricePerUnit
      val totCost = qty * costPerUnit
      val day = DateUtils.getDayName(dateMillis)
      val formattedDate = DateUtils.getFormattedDate(dateMillis)
      val formattedTime = DateUtils.getFormattedTime(System.currentTimeMillis())

      repository.addProduction(
        ProductionEntity(
          productId = productId,
          productName = productName,
          dateMillis = dateMillis,
          dayName = day,
          formattedDate = formattedDate,
          formattedTime = formattedTime,
          qty = qty,
          pricePerUnit = pricePerUnit,
          costPerUnit = costPerUnit,
          potentialRevenue = potRev,
          totalCost = totCost,
          notes = notes.trim(),
          photoUri = photoUri
        )
      )
    }
  }

  fun deleteProduction(production: ProductionEntity) {
    viewModelScope.launch {
      repository.deleteProduction(production)
    }
  }

  fun addSale(
    customerName: String,
    paymentMethod: String,
    dateMillis: Long,
    notes: String,
    items: List<SaleItemEntity>,
    photoUri: String? = null
  ) {
    viewModelScope.launch {
      val totalAmount = items.sumOf { it.subtotal }
      val totalCost = items.sumOf { it.costPerUnit * it.qty }
      val netProfit = totalAmount - totalCost
      val totalQty = items.sumOf { it.qty }
      val itemsSummary = items.joinToString(", ") { "${it.qty}x ${it.productName}" }

      val day = DateUtils.getDayName(dateMillis)
      val formattedDate = DateUtils.getFormattedDate(dateMillis)
      val formattedTime = DateUtils.getFormattedTime(System.currentTimeMillis())

      val sale = SaleEntity(
        dateMillis = dateMillis,
        dayName = day,
        formattedDate = formattedDate,
        formattedTime = formattedTime,
        customerName = customerName.trim(),
        paymentMethod = paymentMethod,
        totalAmount = totalAmount,
        totalCost = totalCost,
        netProfit = netProfit,
        notes = notes.trim(),
        photoUri = photoUri,
        itemsSummary = itemsSummary,
        totalQty = totalQty
      )

      repository.addSale(sale, items)
      // Clear cart
      posCart.value = emptyMap()
    }
  }

  fun deleteSale(sale: SaleEntity) {
    viewModelScope.launch {
      repository.deleteSale(sale)
    }
  }

  fun addExpense(
    itemName: String,
    category: String,
    qty: Double,
    unit: String,
    unitPrice: Double,
    dateMillis: Long,
    placeOrStore: String,
    notes: String,
    receiptPhotoUri: String? = null
  ) {
    viewModelScope.launch {
      val total = qty * unitPrice
      val day = DateUtils.getDayName(dateMillis)
      val formattedDate = DateUtils.getFormattedDate(dateMillis)
      val formattedTime = DateUtils.getFormattedTime(System.currentTimeMillis())

      repository.addExpense(
        ExpenseEntity(
          dateMillis = dateMillis,
          dayName = day,
          formattedDate = formattedDate,
          formattedTime = formattedTime,
          itemName = itemName.trim(),
          category = category.trim().ifBlank { "Bahan Baku" },
          qty = qty,
          unit = unit.trim().ifBlank { "pack" },
          unitPrice = unitPrice,
          totalAmount = total,
          placeOrStore = placeOrStore.trim(),
          notes = notes.trim(),
          receiptPhotoUri = receiptPhotoUri
        )
      )
    }
  }

  fun deleteExpense(expense: ExpenseEntity) {
    viewModelScope.launch {
      repository.deleteExpense(expense)
    }
  }

  fun adjustStockManual(
    productId: Long,
    productName: String,
    qtyDelta: Int,
    type: String, // "RUSAK", "KOREKSI"
    reason: String
  ) {
    viewModelScope.launch {
      repository.recordManualAdjustment(productId, productName, qtyDelta, type, reason)
    }
  }

  fun updateTargets(daily: Double, weekly: Double, monthly: Double) {
    viewModelScope.launch {
      repository.saveTarget(
        BusinessTargetEntity(
          id = 1,
          dailyTarget = daily,
          weeklyTarget = weekly,
          monthlyTarget = monthly,
          updatedAt = System.currentTimeMillis()
        )
      )
    }
  }

  fun setMonthlyTarget(monthly: Double) {
    updateTargets(monthly / 30.0, monthly / 4.0, monthly)
  }

  // POS Cart Helper Actions
  fun addToCart(productId: Long) {
    val current = posCart.value.toMutableMap()
    val count = current.getOrDefault(productId, 0)
    current[productId] = count + 1
    posCart.value = current
  }

  fun removeFromCart(productId: Long) {
    val current = posCart.value.toMutableMap()
    val count = current.getOrDefault(productId, 0)
    if (count > 1) {
      current[productId] = count - 1
    } else {
      current.remove(productId)
    }
    posCart.value = current
  }

  fun clearCart() {
    posCart.value = emptyMap()
  }

  fun resetToSampleData() {
    viewModelScope.launch {
      repository.resetToSampleData()
    }
  }

  suspend fun getCsvExport(): String {
    return repository.generateCsvExport(
      productions = productions.value,
      sales = sales.value,
      expenses = expenses.value,
      products = products.value
    )
  }

  suspend fun getJsonBackup(): String {
    return repository.exportBackupJson(
      products = products.value,
      productions = productions.value,
      sales = sales.value,
      expenses = expenses.value
    )
  }
}
