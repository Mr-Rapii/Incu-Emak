package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Collections
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.PointOfSale
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material.icons.filled.Warehouse
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.local.AppDatabase
import com.example.data.repository.BusinessRepository
import com.example.ui.screens.AnalyticsScreen
import com.example.ui.screens.CalendarScreen
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.ExpenseScreen
import com.example.ui.screens.GalleryScreen
import com.example.ui.screens.ProductionScreen
import com.example.ui.screens.ReportScreen
import com.example.ui.screens.SalesScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.StockScreen
import com.example.ui.theme.ExpenseRed
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.PrimaryWarm
import com.example.ui.theme.ProfitGreen
import com.example.ui.theme.RevenueBlue
import com.example.ui.theme.SecondaryGolden
import com.example.ui.viewmodel.MainViewModel

enum class Screen(val title: String, val icon: ImageVector) {
  DASHBOARD("Dashboard", Icons.Default.Dashboard),
  PRODUCTION("Produksi", Icons.Default.Inventory2),
  SALES("Penjualan", Icons.Default.ShoppingCart),
  EXPENSE("Belanja", Icons.Default.ReceiptLong),
  STOCK("Stok Produk", Icons.Default.Warehouse),
  REPORTS("Laporan", Icons.Default.TrendingUp),
  ANALYTICS("Analisis Usaha", Icons.Default.Analytics),
  CALENDAR("Kalender", Icons.Default.CalendarMonth),
  GALLERY("Galeri Foto", Icons.Default.Collections),
  SETTINGS("Pengaturan", Icons.Default.Settings)
}

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()

    setContent {
      MyApplicationTheme {
        val viewModel: MainViewModel = viewModel()
        IncuEmakApp(viewModel = viewModel)
      }
    }
  }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun IncuEmakApp(viewModel: MainViewModel) {
  var currentScreen by remember { mutableStateOf(Screen.DASHBOARD) }
  var showMenuSheet by remember { mutableStateOf(false) }
  val sheetState = rememberModalBottomSheetState()

  Scaffold(
    topBar = {
      CenterAlignedTopAppBar(
        title = {
          Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
              text = if (currentScreen == Screen.DASHBOARD) "Incu Emak" else currentScreen.title,
              style = MaterialTheme.typography.titleMedium,
              fontWeight = FontWeight.Bold,
              color = MaterialTheme.colorScheme.onSurface
            )
            if (currentScreen == Screen.DASHBOARD) {
              Text(
                text = "Makaroni • Basreng • Kerupuk Seblak",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }
          }
        },
        actions = {
          IconButton(
            onClick = { showMenuSheet = true },
            modifier = Modifier.testTag("open_menu_button")
          ) {
            Icon(
              imageVector = Icons.Default.Menu,
              contentDescription = "Menu Fitur",
              tint = PrimaryWarm
            )
          }
        },
        colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
          containerColor = MaterialTheme.colorScheme.surface
        )
      )
    },
    bottomBar = {
      NavigationBar(
        containerColor = MaterialTheme.colorScheme.surface,
        tonalElevation = 6.dp
      ) {
        val bottomNavItems = listOf(
          Screen.DASHBOARD,
          Screen.PRODUCTION,
          Screen.SALES,
          Screen.EXPENSE,
          Screen.STOCK
        )

        bottomNavItems.forEach { screen ->
          val isSelected = currentScreen == screen
          NavigationBarItem(
            selected = isSelected,
            onClick = { currentScreen = screen },
            icon = {
              Icon(
                imageVector = screen.icon,
                contentDescription = screen.title
              )
            },
            label = {
              Text(
                text = screen.title,
                fontSize = 11.sp,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
              )
            },
            colors = NavigationBarItemDefaults.colors(
              selectedIconColor = PrimaryWarm,
              selectedTextColor = PrimaryWarm,
              indicatorColor = PrimaryWarm.copy(alpha = 0.12f)
            )
          )
        }
      }
    }
  ) { innerPadding ->
    Box(
      modifier = Modifier
        .fillMaxSize()
        .padding(innerPadding)
    ) {
      when (currentScreen) {
        Screen.DASHBOARD -> DashboardScreen(
          viewModel = viewModel,
          onNavigateToProduction = { currentScreen = Screen.PRODUCTION },
          onNavigateToSales = { currentScreen = Screen.SALES },
          onNavigateToExpense = { currentScreen = Screen.EXPENSE },
          onNavigateToStock = { currentScreen = Screen.STOCK },
          onNavigateToReports = { currentScreen = Screen.REPORTS },
          onNavigateToAnalytics = { currentScreen = Screen.ANALYTICS }
        )
        Screen.PRODUCTION -> ProductionScreen(viewModel = viewModel)
        Screen.SALES -> SalesScreen(viewModel = viewModel)
        Screen.EXPENSE -> ExpenseScreen(viewModel = viewModel)
        Screen.STOCK -> StockScreen(
          viewModel = viewModel,
          onNavigateToProduction = { currentScreen = Screen.PRODUCTION }
        )
        Screen.REPORTS -> ReportScreen(viewModel = viewModel)
        Screen.ANALYTICS -> AnalyticsScreen(viewModel = viewModel)
        Screen.CALENDAR -> CalendarScreen(viewModel = viewModel)
        Screen.GALLERY -> GalleryScreen(viewModel = viewModel)
        Screen.SETTINGS -> SettingsScreen(viewModel = viewModel)
      }
    }
  }

  // All Features Menu Bottom Sheet
  if (showMenuSheet) {
    ModalBottomSheet(
      onDismissRequest = { showMenuSheet = false },
      sheetState = sheetState,
      containerColor = MaterialTheme.colorScheme.surface
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 20.dp, vertical = 12.dp)
      ) {
        Text(
          text = "Menu Lengkap Incu Emak",
          style = MaterialTheme.typography.titleMedium,
          fontWeight = FontWeight.Bold
        )
        Text(
          text = "Pilih modul untuk mengelola seluruh data usaha",
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(modifier = Modifier.height(16.dp))

        val menuItems = listOf(
          MenuItemData(Screen.DASHBOARD, PrimaryWarm, "Ringkasan data usaha & grafik"),
          MenuItemData(Screen.PRODUCTION, PrimaryWarm, "Catat produksi & potensi omzet"),
          MenuItemData(Screen.SALES, RevenueBlue, "Catat transaksi & kasir cepat"),
          MenuItemData(Screen.EXPENSE, ExpenseRed, "Catat nota belanja bahan baku"),
          MenuItemData(Screen.STOCK, SecondaryGolden, "Kontrol stok fisik & produk rusak"),
          MenuItemData(Screen.REPORTS, ProfitGreen, "Laporan harian, mingguan, bulanan"),
          MenuItemData(Screen.ANALYTICS, RevenueBlue, "Tren laba rugi & produk terlaris"),
          MenuItemData(Screen.CALENDAR, PrimaryWarm, "Aktivitas usaha berbasis tanggal"),
          MenuItemData(Screen.GALLERY, SecondaryGolden, "Dokumentasi foto produk & nota"),
          MenuItemData(Screen.SETTINGS, Color.Gray, "Target omzet & ekspor data")
        )

        LazyVerticalGrid(
          columns = GridCells.Fixed(2),
          horizontalArrangement = Arrangement.spacedBy(10.dp),
          verticalArrangement = Arrangement.spacedBy(10.dp),
          modifier = Modifier.padding(bottom = 24.dp)
        ) {
          items(menuItems) { item ->
            Card(
              modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .clickable {
                  currentScreen = item.screen
                  showMenuSheet = false
                },
              shape = RoundedCornerShape(14.dp),
              colors = CardDefaults.cardColors(
                containerColor = if (currentScreen == item.screen) item.color.copy(alpha = 0.15f) else MaterialTheme.colorScheme.surfaceVariant
              )
            ) {
              Row(
                modifier = Modifier.padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
              ) {
                Box(
                  modifier = Modifier
                    .size(36.dp)
                    .background(item.color.copy(alpha = 0.15f), CircleShape),
                  contentAlignment = Alignment.Center
                ) {
                  Icon(
                    imageVector = item.screen.icon,
                    contentDescription = null,
                    tint = item.color,
                    modifier = Modifier.size(20.dp)
                  )
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                  Text(
                    text = item.screen.title,
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Bold
                  )
                  Text(
                    text = item.description,
                    style = MaterialTheme.typography.labelSmall,
                    fontSize = 10.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1
                  )
                }
              }
            }
          }
        }
      }
    }
  }
}

private data class MenuItemData(
  val screen: Screen,
  val color: Color,
  val description: String
)

