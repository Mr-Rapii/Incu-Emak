package com.example.data.local.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Update
import com.example.data.local.entity.SaleEntity
import com.example.data.local.entity.SaleItemEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface SaleDao {
  @Query("SELECT * FROM sales ORDER BY dateMillis DESC, id DESC")
  fun getAllSales(): Flow<List<SaleEntity>>

  @Query("SELECT * FROM sales WHERE dateMillis >= :startMillis AND dateMillis <= :endMillis ORDER BY dateMillis DESC")
  fun getSalesByDateRange(startMillis: Long, endMillis: Long): Flow<List<SaleEntity>>

  @Query("SELECT * FROM sale_items WHERE saleId = :saleId")
  suspend fun getSaleItems(saleId: Long): List<SaleItemEntity>

  @Query("SELECT * FROM sale_items")
  fun getAllSaleItems(): Flow<List<SaleItemEntity>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertSale(sale: SaleEntity): Long

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertSaleItems(items: List<SaleItemEntity>)

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertAll(sales: List<SaleEntity>)

  @Update
  suspend fun updateSale(sale: SaleEntity)

  @Delete
  suspend fun deleteSale(sale: SaleEntity)

  @Query("DELETE FROM sale_items WHERE saleId = :saleId")
  suspend fun deleteSaleItems(saleId: Long)

  @Transaction
  suspend fun deleteSaleWithItems(sale: SaleEntity) {
    deleteSaleItems(sale.id)
    deleteSale(sale)
  }

  @Query("DELETE FROM sales")
  suspend fun deleteAll()

  @Query("DELETE FROM sale_items")
  suspend fun deleteAllItems()
}
