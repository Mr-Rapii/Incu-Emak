package com.example.data.local.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.local.entity.ProductionEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface ProductionDao {
  @Query("SELECT * FROM productions ORDER BY dateMillis DESC, id DESC")
  fun getAllProductions(): Flow<List<ProductionEntity>>

  @Query("SELECT * FROM productions WHERE dateMillis >= :startMillis AND dateMillis <= :endMillis ORDER BY dateMillis DESC")
  fun getProductionsByDateRange(startMillis: Long, endMillis: Long): Flow<List<ProductionEntity>>

  @Query("SELECT * FROM productions WHERE productId = :productId ORDER BY dateMillis DESC")
  fun getProductionsByProduct(productId: Long): Flow<List<ProductionEntity>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertProduction(production: ProductionEntity): Long

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertAll(productions: List<ProductionEntity>)

  @Update
  suspend fun updateProduction(production: ProductionEntity)

  @Delete
  suspend fun deleteProduction(production: ProductionEntity)

  @Query("DELETE FROM productions WHERE id = :id")
  suspend fun deleteById(id: Long)

  @Query("DELETE FROM productions")
  suspend fun deleteAll()
}
