package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AddShoppingCart
import androidx.compose.material.icons.filled.AttachMoney
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.LocalAtm
import androidx.compose.material.icons.filled.PointOfSale
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material.icons.filled.ShowChart
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.local.entity.ProductEntity
import com.example.ui.components.LowStockAlertBanner
import com.example.ui.components.MultiMetricBarChart
import com.example.ui.components.StatCard
import com.example.ui.components.TargetProgressCard
import com.example.ui.components.TrendLineChart
import com.example.ui.theme.ExpenseRed
import com.example.ui.theme.PrimaryWarm
import com.example.ui.theme.ProfitGreen
import com.example.ui.theme.RevenueBlue
import com.example.ui.theme.SecondaryGolden
import com.example.ui.theme.WarningAmber
import com.example.ui.util.DateUtils
import com.example.ui.util.FormatUtils
import com.example.ui.viewmodel.MainViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(
  viewModel: MainViewModel,
  onNavigateToProduction: () -> Unit,
  onNavigateToSales: () -> Unit,
  onNavigateToExpense: () -> Unit,
  onNavigateToStock: () -> Unit,
  onNavigateToReports: () -> Unit,
  onNavigateToAnalytics: () -> Unit,
  modifier: Modifier = Modifier
) {
  val dashboardState by viewModel.dashboardState.collectAsStateWithLifecycle()
  val products by viewModel.products.collectAsStateWithLifecycle()
  var chartMetric by remember { mutableStateOf("Omzet") }

  val now = System.currentTimeMillis()
  val todayFormatted = DateUtils.getFullFormattedDateWithDay(now)

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .background(MaterialTheme.colorScheme.background)
      .testTag("dashboard_screen"),
    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 16.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp)
  ) {
    // 1. Hero Welcome & Today Status
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
      ) {
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .background(
              Brush.horizontalGradient(
                colors = listOf(
                  PrimaryWarm.copy(alpha = 0.95f),
                  SecondaryGolden.copy(alpha = 0.90f)
                )
              )
            )
            .padding(18.dp)
        ) {
          Column {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Column {
                Text(
                  text = "Incu Emak Business Manager",
                  style = MaterialTheme.typography.titleMedium,
                  fontWeight = FontWeight.ExtraBold,
                  color = Color.White
                )
                Text(
                  text = "Makaroni • Basreng • Kerupuk Seblak",
                  style = MaterialTheme.typography.bodySmall,
                  color = Color.White.copy(alpha = 0.9f)
                )
              }
              Surface(
                color = Color.White.copy(alpha = 0.2f),
                shape = RoundedCornerShape(12.dp)
              ) {
                Text(
                  text = todayFormatted,
                  style = MaterialTheme.typography.labelSmall,
                  color = Color.White,
                  fontWeight = FontWeight.SemiBold,
                  modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                )
              }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Today's Quick Snapshot in Hero
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Column {
                Text(
                  text = "Omzet Hari Ini",
                  style = MaterialTheme.typography.labelMedium,
                  color = Color.White.copy(alpha = 0.85f)
                )
                Text(
                  text = FormatUtils.formatRupiah(dashboardState.todayRevenue),
                  style = MaterialTheme.typography.titleLarge,
                  fontWeight = FontWeight.Bold,
                  color = Color.White
                )
              }
              Column(horizontalAlignment = Alignment.End) {
                Text(
                  text = "Keuntungan Hari Ini",
                  style = MaterialTheme.typography.labelMedium,
                  color = Color.White.copy(alpha = 0.85f)
                )
                Text(
                  text = FormatUtils.formatRupiah(dashboardState.todayProfit),
                  style = MaterialTheme.typography.titleLarge,
                  fontWeight = FontWeight.Bold,
                  color = Color.White
                )
              }
            }
          }
        }
      }
    }

    // 2. Low Stock Alert (if any)
    item {
      LowStockAlertBanner(
        lowStockProducts = dashboardState.lowStockList,
        onAddProductionClick = { onNavigateToProduction() }
      )
    }

    // 3. Quick Action Buttons
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        QuickActionButton(
          icon = Icons.Default.Inventory2,
          label = "+ Produksi",
          color = PrimaryWarm,
          modifier = Modifier.weight(1f),
          onClick = onNavigateToProduction
        )
        QuickActionButton(
          icon = Icons.Default.ShoppingCart,
          label = "+ Penjualan",
          color = RevenueBlue,
          modifier = Modifier.weight(1f),
          onClick = onNavigateToSales
        )
        QuickActionButton(
          icon = Icons.Default.ReceiptLong,
          label = "+ Belanja",
          color = ExpenseRed,
          modifier = Modifier.weight(1f),
          onClick = onNavigateToExpense
        )
      }
    }

    // 4. Main Stats KPI Grid
    item {
      Text(
        text = "Ringkasan Finansial & Operasional",
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.onBackground
      )
    }

    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
      ) {
        StatCard(
          title = "Total Omzet",
          value = FormatUtils.formatRupiah(dashboardState.totalRevenueAllTime),
          subtitle = "Hari ini: ${FormatUtils.formatRupiah(dashboardState.todayRevenue)}",
          icon = Icons.Default.LocalAtm,
          accentColor = PrimaryWarm,
          isSolidVibrant = true,
          modifier = Modifier.weight(1f),
          badgeText = FormatUtils.formatPercentage(dashboardState.dailyRevenueDeltaPercent),
          isPositiveBadge = dashboardState.dailyRevenueDeltaPercent >= 0
        )
        StatCard(
          title = "Total Keuntungan",
          value = FormatUtils.formatRupiah(dashboardState.totalNetProfitAllTime),
          subtitle = "Hari ini: ${FormatUtils.formatRupiah(dashboardState.todayProfit)}",
          icon = Icons.Default.TrendingUp,
          accentColor = ProfitGreen,
          isSolidVibrant = true,
          modifier = Modifier.weight(1f),
          badgeText = if (dashboardState.totalRevenueAllTime > 0)
            "${((dashboardState.totalNetProfitAllTime / dashboardState.totalRevenueAllTime) * 100).toInt()}% margin"
          else null,
          isPositiveBadge = true
        )
      }
    }

    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
      ) {
        StatCard(
          title = "Total Pengeluaran",
          value = FormatUtils.formatRupiah(dashboardState.totalExpenseAllTime),
          subtitle = "Hari ini: ${FormatUtils.formatRupiah(dashboardState.todayExpense)}",
          icon = Icons.Default.ReceiptLong,
          accentColor = ExpenseRed,
          modifier = Modifier.weight(1f)
        )
        StatCard(
          title = "Total Produk Dibuat",
          value = "${dashboardState.totalProducedAllTime} pcs",
          subtitle = "Terjual: ${dashboardState.totalSoldAllTime} pcs",
          icon = Icons.Default.Inventory2,
          accentColor = SecondaryGolden,
          modifier = Modifier.weight(1f)
        )
      }
    }

    // 5. Income Target Progress Card
    item {
      TargetProgressCard(
        title = "Target Omzet Bulan Ini",
        current = dashboardState.thisMonthRevenue,
        target = dashboardState.monthlyTarget
      )
    }

    // 6. Growth Comparisons (Hari, Minggu, Bulan)
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Text(
            text = "Perbandingan Pertumbuhan Omzet",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold
          )
          Spacer(modifier = Modifier.height(12.dp))

          GrowthItem(
            period = "Hari Ini vs Kemarin",
            currentVal = dashboardState.todayRevenue,
            prevVal = dashboardState.yesterdayRevenue,
            percentDelta = dashboardState.dailyRevenueDeltaPercent
          )
          Spacer(modifier = Modifier.height(10.dp))
          GrowthItem(
            period = "Minggu Ini vs Minggu Lalu",
            currentVal = dashboardState.thisWeekRevenue,
            prevVal = dashboardState.lastWeekRevenue,
            percentDelta = dashboardState.weeklyRevenueDeltaPercent
          )
          Spacer(modifier = Modifier.height(10.dp))
          GrowthItem(
            period = "Bulan Ini vs Bulan Lalu",
            currentVal = dashboardState.thisMonthRevenue,
            prevVal = dashboardState.lastMonthRevenue,
            percentDelta = dashboardState.monthlyRevenueDeltaPercent
          )
        }
      }
    }

    // 7. Interactive Chart Section with Metric Selector Tabs
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text(
          text = "Analisis Grafik & Tren",
          style = MaterialTheme.typography.titleMedium,
          fontWeight = FontWeight.Bold
        )
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
          listOf("Omzet", "Keuntungan", "Pengeluaran").forEach { metric ->
            FilterChip(
              selected = chartMetric == metric,
              onClick = { chartMetric = metric },
              label = { Text(metric, fontSize = 11.sp) },
              colors = FilterChipDefaults.filterChipColors(
                selectedContainerColor = PrimaryWarm.copy(alpha = 0.15f),
                selectedLabelColor = PrimaryWarm
              )
            )
          }
        }
      }
    }

    item {
      TrendLineChart(
        stats = dashboardState.last7DaysStats,
        selectedMetric = chartMetric
      )
    }

    item {
      MultiMetricBarChart(
        stats = dashboardState.last7DaysStats
      )
    }

    // 8. Product Rankings (Paling banyak dibuat & Terjual)
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text(
              text = "Produk Unggulan Incu Emak",
              style = MaterialTheme.typography.titleMedium,
              fontWeight = FontWeight.Bold
            )
            IconButton(onClick = onNavigateToAnalytics) {
              Icon(Icons.Default.ShowChart, contentDescription = "Analisis Lengkap", tint = PrimaryWarm)
            }
          }
          Spacer(modifier = Modifier.height(10.dp))

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
          ) {
            Surface(
              modifier = Modifier.weight(1f),
              color = SecondaryGolden.copy(alpha = 0.1f),
              shape = RoundedCornerShape(14.dp)
            ) {
              Column(modifier = Modifier.padding(12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Icon(Icons.Default.Star, contentDescription = null, tint = SecondaryGolden, modifier = Modifier.size(16.dp))
                  Spacer(modifier = Modifier.width(4.dp))
                  Text("Paling Laku", style = MaterialTheme.typography.labelSmall, color = SecondaryGolden, fontWeight = FontWeight.Bold)
                }
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                  text = dashboardState.topSoldProduct,
                  style = MaterialTheme.typography.titleSmall,
                  fontWeight = FontWeight.ExtraBold
                )
              }
            }

            Surface(
              modifier = Modifier.weight(1f),
              color = PrimaryWarm.copy(alpha = 0.1f),
              shape = RoundedCornerShape(14.dp)
            ) {
              Column(modifier = Modifier.padding(12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Icon(Icons.Default.Inventory2, contentDescription = null, tint = PrimaryWarm, modifier = Modifier.size(16.dp))
                  Spacer(modifier = Modifier.width(4.dp))
                  Text("Paling Banyak Dibuat", style = MaterialTheme.typography.labelSmall, color = PrimaryWarm, fontWeight = FontWeight.Bold)
                }
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                  text = dashboardState.topProducedProduct,
                  style = MaterialTheme.typography.titleSmall,
                  fontWeight = FontWeight.ExtraBold
                )
              }
            }
          }
        }
      }
    }

    // 9. Stock Snapshot Cards
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text(
          text = "Stok Produk Saat Ini",
          style = MaterialTheme.typography.titleMedium,
          fontWeight = FontWeight.Bold
        )
        TextButton(onClick = onNavigateToStock) {
          Text("Kelola Stok", color = PrimaryWarm)
        }
      }
    }

    item {
      LazyRow(
        horizontalArrangement = Arrangement.spacedBy(12.dp)
      ) {
        items(products) { product ->
          ProductStockMiniCard(
            product = product,
            onClick = onNavigateToStock
          )
        }
      }
    }

    item {
      Spacer(modifier = Modifier.height(16.dp))
    }
  }
}

@Composable
private fun QuickActionButton(
  icon: ImageVector,
  label: String,
  color: Color,
  modifier: Modifier = Modifier,
  onClick: () -> Unit
) {
  Surface(
    modifier = modifier
      .clip(RoundedCornerShape(14.dp))
      .clickable { onClick() },
    color = color.copy(alpha = 0.12f),
    shape = RoundedCornerShape(14.dp)
  ) {
    Column(
      modifier = Modifier.padding(vertical = 12.dp, horizontal = 8.dp),
      horizontalAlignment = Alignment.CenterHorizontally
    ) {
      Icon(imageVector = icon, contentDescription = label, tint = color, modifier = Modifier.size(22.dp))
      Spacer(modifier = Modifier.height(4.dp))
      Text(
        text = label,
        style = MaterialTheme.typography.labelMedium,
        fontWeight = FontWeight.Bold,
        color = color
      )
    }
  }
}

@Composable
private fun GrowthItem(
  period: String,
  currentVal: Double,
  prevVal: Double,
  percentDelta: Double
) {
  val isPositive = percentDelta >= 0
  val statusColor = if (isPositive) ProfitGreen else ExpenseRed

  Row(
    modifier = Modifier.fillMaxWidth(),
    horizontalArrangement = Arrangement.SpaceBetween,
    verticalAlignment = Alignment.CenterVertically
  ) {
    Column {
      Text(
        text = period,
        style = MaterialTheme.typography.bodyMedium,
        fontWeight = FontWeight.SemiBold
      )
      Text(
        text = "${FormatUtils.formatRupiah(currentVal)} vs ${FormatUtils.formatRupiah(prevVal)}",
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant
      )
    }

    Surface(
      color = statusColor.copy(alpha = 0.12f),
      shape = RoundedCornerShape(10.dp)
    ) {
      Text(
        text = "${if (isPositive) "📈 Naik " else "📉 Turun "}${FormatUtils.formatPercentage(percentDelta)}",
        style = MaterialTheme.typography.labelMedium,
        color = statusColor,
        fontWeight = FontWeight.Bold,
        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
      )
    }
  }
}

@Composable
private fun ProductStockMiniCard(
  product: ProductEntity,
  onClick: () -> Unit
) {
  val isLowStock = product.currentStock <= product.minStockAlert

  Card(
    modifier = Modifier
      .width(140.dp)
      .clip(RoundedCornerShape(16.dp))
      .clickable { onClick() },
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
  ) {
    Column(modifier = Modifier.padding(12.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text(
          text = product.name,
          style = MaterialTheme.typography.titleSmall,
          fontWeight = FontWeight.Bold,
          maxLines = 1
        )
        if (isLowStock) {
          Icon(
            Icons.Default.Warning,
            contentDescription = "Stok Sedikit",
            tint = WarningAmber,
            modifier = Modifier.size(16.dp)
          )
        }
      }

      Spacer(modifier = Modifier.height(8.dp))

      Text(
        text = "${product.currentStock} ${product.unit}",
        style = MaterialTheme.typography.titleLarge,
        fontWeight = FontWeight.ExtraBold,
        color = if (isLowStock) ExpenseRed else ProfitGreen
      )

      Text(
        text = FormatUtils.formatRupiah(product.defaultPrice),
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant
      )
    }
  }
}
